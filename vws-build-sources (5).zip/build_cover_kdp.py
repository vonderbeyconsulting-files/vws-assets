# -*- coding: utf-8 -*-
"""VWS Workbook — KDP Full-Wrap Cover (7×10", 184 S. Standard Color, weiß)
Rückseite · Rücken (10,53 mm) · Vorderseite, je 0,125" Beschnitt umlaufend."""
from reportlab.lib.units import cm, mm, inch
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import os

CR = HexColor('#8E1429'); NV = HexColor('#1A2744'); SL = HexColor('#5F7FA8')
WW = HexColor('#F0EEE8'); CH = HexColor('#3A3A3A')

for name, f in [('Lora', 'Lora-Regular.ttf'), ('Lora-It', 'Lora-Italic.ttf'),
                ('Lora-Bd', 'Lora-Bold.ttf')]:
    p = f'/home/claude/{f}'
    if os.path.exists(p) and name not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont(name, p))

BLEED = 0.125 * inch
PANEL = 7 * inch
SPINE = 184 * 0.002252 * inch          # 0.4144" = 10.53 mm
PH    = 10 * inch
W = 2 * BLEED + 2 * PANEL + SPINE
H = PH + 2 * BLEED

BAND_TOP = 12 * mm                     # Crimson oben
LINE_SL  = 2 * mm                      # Taubenblau-Linie darunter
BAND_BOT = 1.6 * cm                    # Taubenblau unten

X_BACK  = BLEED
X_SPINE = BLEED + PANEL
X_FRONT = BLEED + PANEL + SPINE


def tracked(c, x, y, text, font, size, charspace, color, alpha=1.0, center_on=None):
    w = c.stringWidth(text, font, size) + charspace * (len(text) - 1)
    if center_on is not None:
        x = center_on - w / 2
    c.saveState()                       # kapselt auch den PDF-Textzustand (Tc)
    c.setFillColor(color); c.setFillAlpha(alpha)
    t = c.beginText(); t.setFont(font, size); t.setCharSpace(charspace)
    t.setTextOrigin(x, y); t.textOut(text); c.drawText(t)
    c.restoreState()
    return w


def band_footer(c, cx, line1, line1_size):
    """Footer auf Taubenblau-Band: Haarlinie + zwei gesperrte Zeilen."""
    c.setStrokeColor(WW); c.setLineWidth(0.5); c.setStrokeAlpha(0.45)
    c.line(cx - 1.4 * cm, BLEED + 1.32 * cm, cx + 1.4 * cm, BLEED + 1.32 * cm)
    c.setStrokeAlpha(1)
    tracked(c, 0, BLEED + 0.92 * cm, line1, 'Helvetica', line1_size, 0.6, WW,
            alpha=0.85, center_on=cx)
    tracked(c, 0, BLEED + 0.42 * cm, 'WWW.VONDERBEYCONSULTING.COM',
            'Helvetica-Bold', 8, 1.8, WW, center_on=cx)


def build(path='/mnt/user-data/outputs/VWS_Cover_KDP_7x10.pdf'):
    c = rl_canvas.Canvas(path, pagesize=(W, H))
    c.setTitle('VWS Workbook — KDP Cover 7x10')

    # ── Grundflächen (durchlaufend, in den Beschnitt gezogen) ──
    c.setFillColor(WW); c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(CR); c.rect(0, H - BLEED - BAND_TOP, W, BLEED + BAND_TOP, fill=1, stroke=0)
    c.setFillColor(SL); c.rect(0, H - BLEED - BAND_TOP - LINE_SL, W, LINE_SL, fill=1, stroke=0)
    c.setFillColor(SL); c.rect(0, 0, W, BLEED + BAND_BOT, fill=1, stroke=0)

    top = H - BLEED - BAND_TOP - LINE_SL   # Unterkante der Bänder oben

    # ════ VORDERSEITE (exakt wie freigegebenes Print-Cover) ════
    fx = X_FRONT + 1.9 * cm                # linker Satzspiegel
    y = top - 3.5 * cm                     # Spacer wie im Buch (mt 2.4 + 3.5 ≈ optisch)
    y -= 0.9 * cm
    tracked(c, fx, y, 'VISION · WERTE · STRATEGIE', 'Helvetica', 9, 2, CR)
    y -= 0.25 * cm + 4 * mm
    c.setFillColor(NV); c.setFont('Lora', 44)
    y -= 44 * 1.0 / 72 * inch
    c.drawString(fx, y, 'Dein Coaching-')
    y -= 52 * 1.0 / 72 * inch
    c.drawString(fx, y, 'Workbook')
    y -= 0.55 * cm
    c.setFillColor(CR); c.rect(fx, y, PANEL * 0.20, 2.5, fill=1, stroke=0)
    y -= 0.95 * cm
    c.setFillColor(SL); c.setFont('Lora-It', 15)
    c.drawString(fx, y, '9 Kapitel · 4 Werkstätten · Das 6-Wochen-Programm')
    y -= 0.95 * cm
    c.setFillColor(CH); c.setFont('Helvetica', 10)
    c.drawString(fx, y, 'Kein Fragebogen. Keine Spielerei.')
    y -= 16
    c.drawString(fx, y, 'Ein Spiegel. Manchmal unbequem. Immer ehrlich.')

    # Kentaur (hochaufgelöst), zentriert auf Vorderseite
    img_w = 124.0
    img_h = img_w * (1968.0 / 1512.0)
    ix = X_FRONT + PANEL / 2 - img_w / 2
    iy = BLEED + BAND_BOT + 1.15 * cm
    c.drawImage('/home/claude/kentaur_vec.png', ix, iy, width=img_w, height=img_h,
                mask='auto')

    band_footer(c, X_FRONT + PANEL / 2,
                'wo@vonderbeyconsulting.com   ·   +49 152 57 66 05 01', 6.8)

    # ════ RÜCKEN ════
    c.saveState()
    c.translate(X_SPINE + SPINE / 2, H / 2)
    c.rotate(-90)
    parts = [('Dein ', 'Lora', 12.5, NV), ('Vision · Werte · Strategie', 'Lora-It', 12.5, CR),
             (' Workbook', 'Lora', 12.5, NV)]
    cs = 0.9
    total = sum(c.stringWidth(t, f, s) + cs * (len(t) - 1) for t, f, s, _ in parts)
    x = -total / 2
    for t, f, s, col in parts:
        x += tracked(c, x, -4.2, t, f, s, cs, col) + cs
    c.restoreState()

    # ════ RÜCKSEITE ════
    from reportlab.platypus import Paragraph, Frame, Spacer
    from reportlab.lib.styles import ParagraphStyle
    bx = X_BACK + 2.1 * cm
    bw = PANEL - 4.4 * cm
    st_kick = ParagraphStyle('k', fontName='Helvetica', fontSize=9, leading=14,
                             textColor=CR, spaceAfter=14)
    st_open = ParagraphStyle('o', fontName='Lora-It', fontSize=14.5, leading=21,
                             textColor=NV, spaceAfter=13)
    st_body = ParagraphStyle('b', fontName='Helvetica', fontSize=10.5, leading=16.5,
                             textColor=CH, spaceAfter=10)
    st_close = ParagraphStyle('c', fontName='Lora-It', fontSize=13.5, leading=19,
                              textColor=CR, spaceAfter=14)
    st_auth = ParagraphStyle('a', fontName='Helvetica', fontSize=9.5, leading=14,
                             textColor=CH)
    flow = [
        Paragraph('<font name="Helvetica">V&nbsp;I&nbsp;S&nbsp;I&nbsp;O&nbsp;N&nbsp;&nbsp;·'
                  '&nbsp;&nbsp;W&nbsp;E&nbsp;R&nbsp;T&nbsp;E&nbsp;&nbsp;·&nbsp;&nbsp;'
                  'S&nbsp;T&nbsp;R&nbsp;A&nbsp;T&nbsp;E&nbsp;G&nbsp;I&nbsp;E</font>', st_kick),
        Paragraph('Irgendwann kommt der Moment, in dem du dich fragst, ob das '
                  'eigentlich dein Weg ist — oder nur der, der sich ergeben hat.', st_open),
        Paragraph('Genau für diesen Moment ist dieses Buch. Es hilft dir, drei Dinge '
                  'zu klären, die zusammengehören: deine <b>Vision</b> — wohin du wirklich '
                  'willst. Deine <b>Werte</b> — woran du dich hältst, wenn es schwierig wird. '
                  'Und deine <b>Strategie</b> — wie aus beidem ein Weg wird, den du gehen '
                  'kannst.', st_body),
        Paragraph('Schritt für Schritt, mit ehrlichen Fragen, Selbsttests und Übungen, '
                  'die in den Alltag passen. Kein Quickfix, sondern ein echter Dialog '
                  'mit dir selbst.', st_body),
        Paragraph('Es ist dein Buch — am Ende steht dein Konzept darin.', st_close),
    ]
    fr = Frame(bx, BLEED + BAND_BOT + 5.4 * cm, bw, top - (BLEED + BAND_BOT + 5.4 * cm) - 1.9 * cm,
               leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
               showBoundary=0)
    fr.addFromList(flow, c)

    # Autorenlinie + Zeile (feste Position über Barcode-Zone)
    ay = BLEED + BAND_BOT + 4.6 * cm
    c.setStrokeColor(SL); c.setLineWidth(0.7); c.setStrokeAlpha(0.85)
    c.line(bx, ay, bx + bw, ay)
    c.setStrokeAlpha(1)
    c.setFillColor(CH); c.setFont('Helvetica', 9.5)
    c.drawString(bx, ay - 0.55 * cm, 'Dr. Werner von der Bey, MBA, ist Coach für Vision, Werte und Strategie.')

    # Tool-Hinweis auf dem Band (Variante A)
    cx = X_BACK + PANEL / 2
    tracked(c, 0, BLEED + 0.92 * cm, 'DAS INTERAKTIVE VWS-TOOL ZUM BUCH',
            'Helvetica', 6.8, 1.0, WW, alpha=0.88, center_on=cx)
    tracked(c, 0, BLEED + 0.42 * cm, 'WWW.VONDERBEYCONSULTING.COM',
            'Helvetica-Bold', 8, 1.8, WW, center_on=cx)
    c.setStrokeColor(WW); c.setLineWidth(0.5); c.setStrokeAlpha(0.45)
    c.line(cx - 1.4 * cm, BLEED + 1.32 * cm, cx + 1.4 * cm, BLEED + 1.32 * cm)
    c.setStrokeAlpha(1)

    c.showPage(); c.save()
    size = os.path.getsize(path)
    print(f'✅ KDP-Cover: {path}')
    print(f'   {W/inch:.4f} × {H/inch:.3f} in  ({W/inch*25.4:.1f} × {H/inch*25.4:.1f} mm), '
          f'Rücken {SPINE/inch*25.4:.2f} mm, {size//1024} KB')


if __name__ == '__main__':
    build()
