#!/usr/bin/env python3
"""VWS Coaching Workbook — Premium Edition mit Branding & Grafiken"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white, black, Color
from reportlab.platypus import (
    KeepTogether, NextPageTemplate,
    Paragraph, Spacer, PageBreak, HRFlowable,
    Table, TableStyle, Image, KeepTogether
)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import (
    Drawing, Circle, Rect, Line, String, Path, Polygon
)
from reportlab.graphics import renderPDF
import os
import wb_ext

# ── FONTS ─────────────────────────────────────────────────────────────────────
pdfmetrics.registerFont(TTFont('Lora',       '/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'))
pdfmetrics.registerFont(TTFont('Lora-It',    '/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu',     '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('Chorus', '/home/claude/Chorus.ttf'))
from reportlab.lib.fonts import addMapping
addMapping('Chorus', 0, 0, 'Chorus')
addMapping('Chorus', 0, 1, 'Chorus')
addMapping('Chorus', 1, 0, 'Chorus')

# ── COLORS ────────────────────────────────────────────────────────────────────
CR  = HexColor('#8E1429')  # Crimson
SL  = HexColor('#5F7FA8')  # Slate/Taubenblau
WW  = HexColor('#F0EEE8')  # Warmweiß
NV  = HexColor('#1A2744')  # Navy
GD  = HexColor('#C0A84A')  # Gold (sparsam)
CH  = HexColor('#3A3A3A')  # Charcoal
DG  = HexColor('#888888')  # DarkGray
RU  = HexColor('#D8D3CB')  # Rule color
CB  = HexColor('#EBF0F5')  # Card BG blue-tint
CW  = HexColor('#FAF7EE')  # Card BG warm

W, H = A4
ML=3.2*cm; MR=3.2*cm; MT=3.5*cm; MB=3*cm
TW = W - ML - MR  # text width

# ── GRAPHICS ─────────────────────────────────────────────────────────────────
def chapter_badge(num_str, theme_color=CR):
    """Circular chapter number badge"""
    d = Drawing(48, 48)
    d.add(Circle(24, 24, 22, fillColor=theme_color, strokeColor=None))
    d.add(String(24, 16, num_str, fontName='Lora', fontSize=18,
                 fillColor=white, textAnchor='middle'))
    return d

def chapter_graphic(chapter_num):
    """PNG icon-based chapter header"""
    from reportlab.graphics.shapes import Drawing, Rect, String, Line
    from reportlab.platypus import Image as RLImage
    import os

    icon_files = {
        1: '/home/claude/icons_png/01_identity.png',
        2: '/home/claude/icons_png/02_tree.png',
        3: '/home/claude/icons_png/03_compass.png',
        4: '/home/claude/icons_png/04_scale.png',
        5: '/home/claude/icons_png/05_strategy.png',
        6: '/home/claude/icons_png/06_bolt.png',
        7: '/home/claude/icons_png/07_ripple.png',
        8: '/home/claude/icons_png/08_stars.png',
    }

    captions = {
        1: 'DIE ROLLE VS. DAS ICH',
        2: 'DAS SICHTBARE VS. DER ANTRIEB',
        3: 'DEIN ENTSCHEIDUNGSFILTER',
        4: 'GELEBT VS. GENANNT',
        5: 'FOKUS DURCH VERZICHT',
        6: 'GIBT VS. KOSTET',
        7: 'DEINE WIRKUNG',
        8: 'LEISTUNG DURCH REGENERATION',
        9: 'VISION · WERTE · STRATEGIE IN AKTION',
    }

    d = Drawing(TW, 80)
    d.add(Rect(0,0,TW,80, fillColor=CW, strokeColor=RU, strokeWidth=0.5))
    d.add(Rect(0,0,4,80, fillColor=CR, strokeColor=None))

    # Caption + lines
    txt_x = 100
    cap = captions.get(chapter_num, '')
    d.add(Line(txt_x, 44, TW-24, 44, strokeColor=RU, strokeWidth=0.4))
    d.add(Line(txt_x, 36, TW-40, 36, strokeColor=RU, strokeWidth=0.3))
    d.add(String(txt_x+6, 47, cap, fontName='Helvetica', fontSize=7,
                 fillColor=DG, textAnchor='start', letterSpacing=1.0))
    return d

def chapter_symbol(chapter_num):
    """Large Unicode symbol for each chapter — rendered in Lora"""
    symbols = {
        1: ('◎', CR),   # ◎ Identität
        2: ('△', CR),   # △ Tiefe oben
        3: ('✦', CR),   # ✦ Vision
        4: ('⚖', CR),   # ⚖ Werte
        5: ('◈', CR),   # ◈ Strategie
        6: ('⚡', CR),   # ⚡ Energie
        7: ('◉', CR),   # ◉ Wirkung
        8: ('⚡', CR),   # ⚡ Olympioniken
        9: ('✧', CR),   # ✧ Visionäre
    }
    return symbols.get(chapter_num, ('◉', CR))


def quote_page(quote_text, author, s):
    """Half-page quote break between chapters — large crimson quote"""
    from reportlab.lib.styles import ParagraphStyle
    big_q = ParagraphStyle('bigq', fontName='Lora-It', fontSize=18,
        leading=28, textColor=CR, spaceAfter=16, spaceBefore=0,
        leftIndent=0, rightIndent=0, alignment=TA_LEFT)
    attr_s = ParagraphStyle('attr', fontName='Lora-It', fontSize=12.5,
        leading=17, textColor=SL, spaceAfter=0, letterSpacing=0.6)
    return [
        Spacer(1, 2.5*cm),
        HRFlowable(width='15%', thickness=2, color=CR,
                   spaceBefore=0, spaceAfter=28),
        Paragraph(f'„{quote_text}“', big_q),
        Spacer(1, 0.3*cm),
        Paragraph(f'—  {author}', attr_s),
        Spacer(1, 2.5*cm),
        HRFlowable(width='100%', thickness=0.3, color=RU,
                   spaceBefore=0, spaceAfter=0),
        PageBreak(),
    ]

def divider_ornament():
    """Small crimson ornament divider"""
    d = Drawing(TW, 16)
    cx = TW/2
    d.add(Line(0,        8, cx-20, 8, strokeColor=RU,  strokeWidth=0.4))
    d.add(Line(cx+20, 8, TW,     8, strokeColor=RU,  strokeWidth=0.4))
    d.add(Circle(cx,    8, 3, fillColor=CR,  strokeColor=None))
    d.add(Circle(cx-12, 8, 1.5, fillColor=SL, strokeColor=None))
    d.add(Circle(cx+12, 8, 1.5, fillColor=SL, strokeColor=None))
    return d

def werner_portrait():
    """Werner's portrait circle — from extracted logo file or placeholder"""
    try:
        return Image('/home/claude/werner_placeholder.png', width=44, height=44)
    except:
        return None

def logo_img(width=100):
    """Kentaur logo"""
    return Image('/home/claude/kentaur_logo.png',
                 width=width, height=width*(335/987))

# ── STYLES ────────────────────────────────────────────────────────────────────
def mk():
    s = {}
    s['body']        = ParagraphStyle('body',    fontName='Helvetica', fontSize=10.5, leading=18, textColor=CH, spaceAfter=10, alignment=TA_JUSTIFY)
    s['body_l']      = ParagraphStyle('body_l',  fontName='Helvetica', fontSize=10.5, leading=17, textColor=CH, spaceAfter=7)
    s['cover_hero']  = ParagraphStyle('chero',   fontName='Lora',      fontSize=44,  leading=52, textColor=NV, spaceAfter=8)
    s['sect_hero']   = ParagraphStyle('shero',   fontName='Lora',      fontSize=30,  leading=38, textColor=NV, spaceAfter=8)
    s['cover_sub']   = ParagraphStyle('csub',    fontName='Lora-It',   fontSize=15,  leading=23, textColor=SL, spaceAfter=18)
    s['cover_body']  = ParagraphStyle('cbody',   fontName='Helvetica', fontSize=10,  leading=16, textColor=CH, spaceAfter=6)
    s['kap_num']     = ParagraphStyle('knum',    fontName='Helvetica', fontSize=9,   leading=14, textColor=CR, spaceAfter=3, letterSpacing=2)
    s['kap_title']   = ParagraphStyle('ktit',    fontName='Lora',      fontSize=30,  leading=36, textColor=NV, spaceAfter=8)
    s['kap_sub']     = ParagraphStyle('ksub',    fontName='Lora-It',   fontSize=13,  leading=20, textColor=SL, spaceAfter=0)
    s['h2']          = ParagraphStyle('h2',      fontName='Lora',      fontSize=14,  leading=20, textColor=NV, spaceAfter=6, spaceBefore=16)
    s['label']       = ParagraphStyle('lbl',     fontName='Helvetica-Bold', fontSize=8,  leading=12, textColor=SL, spaceAfter=4, letterSpacing=1.5)
    s['label_cr']    = ParagraphStyle('lcr',     fontName='Helvetica-Bold', fontSize=8,  leading=12, textColor=CR, spaceAfter=4, letterSpacing=1.5)
    s['quote']       = ParagraphStyle('qt',      fontName='Lora-It',   fontSize=12.5, leading=21, textColor=NV, spaceAfter=4, spaceBefore=8, leftIndent=56)
    s['quote_attr']  = ParagraphStyle('qa',      fontName='Helvetica', fontSize=8,   leading=13, textColor=SL, spaceAfter=12, leftIndent=56)
    s['small']       = ParagraphStyle('sm',      fontName='Helvetica', fontSize=8,   leading=13, textColor=DG, spaceAfter=3)
    s['small_nv']    = ParagraphStyle('smnv',    fontName='Helvetica', fontSize=8,   leading=13, textColor=NV, spaceAfter=3)
    s['toc_num']     = ParagraphStyle('tn',      fontName='Lora',      fontSize=14,  leading=20, textColor=CR)
    s['toc_title']   = ParagraphStyle('tt',      fontName='Lora',      fontSize=13,  leading=20, textColor=NV)
    s['toc_sub']     = ParagraphStyle('ts',      fontName='Helvetica', fontSize=9,   leading=14, textColor=DG)
    s['commitment']  = ParagraphStyle('cmt',     fontName='Helvetica', fontSize=10.5, leading=17, textColor=NV, spaceAfter=8, leftIndent=16)
    s['quiz_q']      = ParagraphStyle('qq',      fontName='Lora',      fontSize=12,  leading=18, textColor=NV, spaceAfter=8)
    s['quiz_opt']    = ParagraphStyle('qo',      fontName='Helvetica', fontSize=10.5, leading=17, textColor=CH, spaceAfter=5, leftIndent=12)
    s['chapter_it']  = ParagraphStyle('chit',    fontName='Lora-It',   fontSize=11,  leading=19, textColor=CH, spaceAfter=10, spaceBefore=4)
    s['brief_salut'] = ParagraphStyle('bsal',    fontName='Lora',      fontSize=16,  leading=24, textColor=NV, spaceAfter=16, spaceBefore=8)
    s['sign']        = ParagraphStyle('sign',    fontName='Chorus',    fontSize=32,  leading=36, textColor=NV, spaceAfter=10)
    s['ritual_body'] = ParagraphStyle('rit',     fontName='Lora-It',   fontSize=13,  leading=22, textColor=NV, spaceAfter=12)
    return s

# ── PAGE CALLBACKS ────────────────────────────────────────────────────────────
ch_store = ['']
logo_path = '/home/claude/kentaur_logo_alpha.png'

def on_cover(c, doc):
    c.saveState()
    # Warmweiß background
    c.setFillColor(WW); c.rect(0,0,W,H,fill=1,stroke=0)
    # Taubenblau bottom band
    c.setFillColor(SL); c.rect(0,0,W,1.6*cm,fill=1,stroke=0)
    # Crimson top stripe
    c.setFillColor(CR); c.rect(0,H-12*mm,W,12*mm,fill=1,stroke=0)
    # Taubenblau accent line below crimson
    c.setFillColor(SL); c.rect(0,H-14*mm,W,2*mm,fill=1,stroke=0)

    # Kentaur placed via story flow (centered, below text)
    # Contact on bottom Taubenblau band — Haarlinie, gesperrte Versalien
    c.setStrokeColor(WW); c.setLineWidth(0.5)
    c.setStrokeAlpha(0.45)
    c.line(W/2 - 1.4*cm, 1.32*cm, W/2 + 1.4*cm, 1.32*cm)
    c.setStrokeAlpha(1)
    c.setFillColor(WW)
    c.setFillAlpha(0.85)
    t1 = c.beginText(); t1.setFont('Helvetica', 6.8); t1.setCharSpace(0.6)
    s1 = 'wo@vonderbeyconsulting.com   ·   +49 152 57 66 05 01'
    w1 = c.stringWidth(s1, 'Helvetica', 6.8) + 0.6 * (len(s1) - 1)
    t1.setTextOrigin(W/2 - w1/2, 0.92*cm); t1.textOut(s1); c.drawText(t1)
    c.setFillAlpha(1)
    t2 = c.beginText(); t2.setFont('Helvetica-Bold', 8); t2.setCharSpace(1.8)
    s2 = 'WWW.VONDERBEYCONSULTING.COM'
    w2 = c.stringWidth(s2, 'Helvetica-Bold', 8) + 1.8 * (len(s2) - 1)
    t2.setTextOrigin(W/2 - w2/2, 0.42*cm); t2.textOut(s2); c.drawText(t2)
    c.restoreState()

def on_normal(c, doc):
    c.saveState()
    # Warmweiß background
    c.setFillColor(WW); c.rect(0,0,W,H,fill=1,stroke=0)
    # Crimson top line
    c.setFillColor(CR); c.rect(0,H-3*mm,W,3*mm,fill=1,stroke=0)
    # Footer area
    c.setStrokeColor(RU); c.setLineWidth(0.4)
    c.line(ML, 2.2*cm, W-MR, 2.2*cm)
    # Page number
    c.setFont('Helvetica', 8); c.setFillColor(DG)
    c.drawCentredString(W/2, 0.9*cm, str(doc.page))
    # Chapter left
    if ch_store[0]:
        c.setFillColor(SL); c.setFont('Helvetica', 7.5)
        c.drawString(ML, 0.9*cm, ch_store[0].upper())
    # Logo oben rechts
    try:
        logo_w = 150
        logo_h = logo_w * (335/987)
        logo_y = H - MT + (MT - 3*mm - logo_h) / 2
        c.drawImage(logo_path, W-logo_w-2*mm, logo_y,
                    width=logo_w, height=logo_h, mask='auto')
    except: pass
    c.restoreState()

# ── CONTENT HELPERS ───────────────────────────────────────────────────────────
def rule(w='100%', thick=0.4, col=RU, before=6, after=10, align='CENTER'):
    return HRFlowable(width=w, thickness=thick, color=col,
                      spaceBefore=before, spaceAfter=after, hAlign=align)

def write_area(lines=3):
    out = []
    for _ in range(lines):
        out += [HRFlowable(width='100%', thickness=0.4, color=RU,
                           spaceAfter=30, spaceBefore=4)]
    return out

def werner_box(text, s):
    portrait = werner_portrait()
    # Werner quote with portrait inline
    items = [rule('100%', 0.3, RU, 8, 10)]
    if portrait:
        # Table: portrait | quote
        data = [[portrait, [Paragraph(f'\u201e{text}\u201c', s['quote']),
                             Paragraph('Dr. Werner von der Bey', s['quote_attr'])]]]
        t = Table(data, colWidths=[52, TW-52])
        t.setStyle(TableStyle([
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),0),
            ('RIGHTPADDING',(0,0),(-1,-1),0),
        ]))
        items.append(t)
    else:
        items += [Paragraph(f'\u201e{text}\u201c', s['quote']),
                  Paragraph('Dr. Werner von der Bey', s['quote_attr'])]
    items.append(rule('100%', 0.3, RU, 0, 14))
    return items

def story_box(label, text, s):
    return [KeepTogether([
        Paragraph(label, s['label_cr']),
        Paragraph(text, s['body']),
    ]),
    Spacer(1,8)]

def exercise_box(title, text, s, lines=3):
    return ([Spacer(1,6), Paragraph(title, s['label']),
             Paragraph(text, s['body_l']), Spacer(1,8)]
            + write_area(lines) + [Spacer(1,8)])

def quiz_box(question, options, s):
    return ([Paragraph('REFLEXION', s['label']),
             Paragraph(question, s['quiz_q'])]
            + [Paragraph(f'\u25cb   {o}', s['quiz_opt']) for o in options]
            + [Spacer(1,10)])

def commitment(text, s):
    return [rule('18%', 2, CR, 18, 10),
            Paragraph('MEIN COMMITMENT', s['label_cr']),
            Paragraph(text, s['commitment']),
            Spacer(1,8)]

def chapter_intro_page(num, title, subtitle, s, chapter_num_int=1):
    """Full opening page with large symbol + title"""
    sym, col = chapter_symbol(chapter_num_int)
    sym_style = ParagraphStyle('sym', fontName='DejaVu', fontSize=72,
        leading=80, textColor=col, spaceAfter=0, alignment=TA_LEFT)
    kap_lbl = ParagraphStyle('klbl', fontName='Helvetica', fontSize=9,
        textColor=CR, leading=14, spaceAfter=8, letterSpacing=2)
    return [
        Spacer(1, 1.6*cm),
        Paragraph(f'KAPITEL {num:02d}', kap_lbl),
        Spacer(1, 0.3*cm),
        Paragraph(sym, sym_style),
        Spacer(1, 0.4*cm),
        Paragraph(title, s['kap_title']),
        rule('22%', 2, CR, 4, 14),
        Paragraph(subtitle, s['kap_sub']),
        PageBreak(),
    ]

def thread(text, s):
    return [Spacer(1, 0.8*cm), rule('100%', 0.4, RU, 0, 8),
            Paragraph(f'\u2192  {text}', s['small']),
            PageBreak()]

# ── BUILD ─────────────────────────────────────────────────────────────────────
def build(path, coachee_name='', target='digital'):
    global W, H, TW
    from reportlab.lib.units import inch
    cv_sp1, cv_sp2, cv_img = (0.6*cm, 1.2*cm, 160) if target != 'print' else (0.25*cm, 0.6*cm, 124)
    if target == 'print':
        W, H = 7*inch, 10*inch          # KDP 7×10
        _ml, _mr = 1.9*cm, 1.6*cm       # Bundsteg-Reserve links
        _mt, _mb = 2.4*cm, 2.6*cm
    else:
        W, H = A4
        _ml, _mr, _mt, _mb = ML, MR, MT, MB
    TW = W - _ml - _mr
    s = mk()

    class Doc(BaseDocTemplate): pass

    doc = Doc(path, pagesize=(W, H),
              leftMargin=_ml, rightMargin=_mr, topMargin=_mt, bottomMargin=_mb,
              title='VWS Coaching Workbook — Dr. Werner von der Bey',
              author='Dr. Werner von der Bey, MBA')

    frame = Frame(_ml, _mb, TW, H-_mt-_mb, id='main')
    doc.addPageTemplates([
        PageTemplate(id='cover',  frames=[frame], onPage=on_cover),
        PageTemplate(id='normal', frames=[frame], onPage=on_normal),
    ])

    story = []

    # ── COVER ─────────────────────────────────────────────────────────────────
    story += [
        Spacer(1, 3.5*cm),
        Paragraph('VISION · WERTE · STRATEGIE', s['kap_num']),
        Spacer(1, cv_sp1),
        Paragraph('Dein Coaching-<br/>Workbook', s['cover_hero']),
        rule('20%', 2.5, CR, 4, 22),
        Paragraph('9 Kapitel · 4 Werkstätten · Das 6-Wochen-Programm', s['cover_sub']),
        Paragraph('Kein Fragebogen. Keine Spielerei.<br/>'
                  'Ein Spiegel. Manchmal unbequem. Immer ehrlich.',
                  s['cover_body']),
        Paragraph(f'Erstellt für: {coachee_name}' if coachee_name else '', s['cover_body']),
        Spacer(1, cv_sp2),
        Image('/home/claude/kentaur_only_alpha.png',
              width=cv_img, height=int(cv_img*(246/189)),
              hAlign='CENTER'),
        NextPageTemplate('normal'),
        PageBreak(),
    ]

    # ── BRIEF ─────────────────────────────────────────────────────────────────
    ch_store[0] = 'Brief von Werner'
    story += [
        Spacer(1, 3.4*cm),
        Paragraph(f'Liebe:r {coachee_name},' if coachee_name else 'Liebe:r Coachee,', s['brief_salut']),
        Paragraph('In 20 Jahren Coaching habe ich eines gelernt: '
                  'Die meisten Menschen wissen, was sie wollen. '
                  'Sie wissen nur nicht, warum sie es nicht bekommen.', s['body']),
        Paragraph('Die Antwort liegt selten in fehlenden Fähigkeiten. '
                  'Sie liegt in ungeklärten Fragen. Wer bin ich wirklich? '
                  'Wofür stehe ich, wenn es schwierig wird? '
                  'Wo will ich hin, wenn ich mutig genug bin, es laut auszusprechen?', s['body']),
        Paragraph('Dieses Workbook begleitet dich durch diese Fragen. '
                  'Ich sage dir nicht, was du antworten sollst. '
                  'Ich sage dir, welche Fragen wirklich zählen — '
                  'und lasse dich dann deine eigenen Antworten finden.', s['body']),
        Spacer(1, 1.2*cm),
        Paragraph('Werner', s['sign']),
        Paragraph('Dr. Werner von der Bey, MBA', s['small']),
        Paragraph('Coach · <i>Vision, Werte, Strategie</i>', s['small']),
        PageBreak(),
    ]

    # ── HOWTO + PROGRAMM-ÜBERSICHT ────────────────────────────────────────────
    ch_store[0] = 'Wie du arbeitest'
    story += wb_ext.howto_pages(s)

    # ── TOC ───────────────────────────────────────────────────────────────────
    ch_store[0] = 'Inhalt'
    story += [
        Spacer(1, 0.6*cm),
        Paragraph('INHALT', s['kap_num']),
        Paragraph('Dein Spiegel', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 28),
    ]

    chapters_list = [
        (1, 'Die Identitätsfalle',       'Wer du wirklich bist — und wen du spielst'),
        (2, 'Das Eisberg-Prinzip',        'Was wirklich unter der Oberfläche treibt'),
        (3, 'Visionen die funktionieren', 'Der Unterschied zwischen Wunsch und Kompass'),
        (4, 'Werte unter Druck',          'Was du wirklich priorisierst — wenn es schwierig wird'),
        (5, 'Strategie ist Verzicht',     'Weniger, aber das Richtige'),
        (6, 'Energie ist deine Ressource','Was dich trägt — und was dich kostet'),
        (7, 'Wirkung hinterlassen',       'Wofür du stehst, wenn du nicht mehr da bist'),
        (8, 'Warum Olympioniken weniger trainieren', 'Leistung durch Regeneration, nicht durch Erschöpfung'),
        (9, 'Visionäre, Strategen, Werteverfechter', 'Was historische Persönlichkeiten uns lehren'),
    ]

    for num, title, sub in chapters_list:
        badge = chapter_badge(str(num).zfill(2))
        badge.width = 36; badge.height = 36
        data = [[renderPDF.GraphicsFlowable(badge),
                 [Paragraph(title, s['toc_title']),
                  Paragraph(sub,   s['toc_sub'])]]]
        t = Table(data, colWidths=[52, TW-52])
        t.setStyle(TableStyle([
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),0),
            ('RIGHTPADDING',(0,0),(-1,-1),0),
            ('LEFTPADDING',(1,0),(1,-1),12),
            ('BOTTOMPADDING',(0,0),(-1,-1),14),
            ('TOPPADDING',(0,0),(-1,-1),4),
            ('LINEBELOW',(0,0),(-1,-1),0.3,RU),
        ]))
        story.append(t)
    story.append(PageBreak())

    # ── CHAPTERS ──────────────────────────────────────────────────────────────
    chapter_data = [
        (1, 'Die Identitätsfalle', 'Wer du wirklich bist — und wen du spielst',
         'Die meisten Menschen haben nie entschieden, wer sie sind. Sie haben sich ergeben — an Erwartungen, Rollen, Gewohnheiten. Das ist kein Vorwurf. Es ist eine Einladung.',
         'DIE GESCHICHTE',
         'Marcus, 41, Unternehmensberater. Erfolgreich, gut bezahlt, innerlich leer. '
         'Sein Kernwert: Freiheit. Dann schauen wir gemeinsam auf seine letzten drei Jahre. '
         'Jede größere Entscheidung hat seine Freiheit eingeschränkt. '
         'Marcus schweigt lange. Dann: „Ich habe Freiheit nie wirklich gelebt. Ich habe nur davon geträumt.“',
         'Was das mit dir zu tun hat',
         'Identität ist das, was übrig bleibt, wenn du alle Rollen ablegst. '
         'Nicht Manager, nicht Elternteil — sondern du. '
         'Psychologen nennen das narrative Identität: die Geschichte, die wir uns über uns selbst erzählen. '
         'Der Abstand zwischen dem, der du bist, und dem, den du spielst, ist dein wichtigstes Entwicklungsfeld.',
         'ÜBUNG — 3 MINUTEN',
         'Schreib auf, wer du bist. Keine Rollen, keine Titel. '
         'Was ist wahr über mich, wenn niemand zuschaut? '
         'Wann warst du zuletzt wirklich du selbst — konkret, mit Datum?', 5,
         'Von deinen Entscheidungen der letzten 12 Monate: Wie viele spiegeln wirklich deine Werte?',
         ['Fast alle — ich lebe, was ich sage',
          'Die Hälfte — manchmal ja, manchmal nicht',
          'Wenige — ich handle oft gegen meine Überzeugungen',
          'Ich weiß es ehrlich gesagt nicht'],
         'Heute Abend: Nenne einer Person, die dir nahesteht, einen Moment aus der letzten Woche, in dem du nicht du selbst warst.',
         'Bevor wir über Vision sprechen, müssen wir verstehen, was unter der Oberfläche treibt. Weiter in Kapitel 2.'),

        (2, 'Das Eisberg-Prinzip', 'Was wirklich unter der Oberfläche treibt',
         'Was du siehst, ist das Ergebnis. Was du nicht siehst, ist alles andere. Ich interessiere mich für das andere.',
         'DIE GESCHICHTE',
         'Zwei Chirurgen, gleiche Ausbildung, gleiche Klinik. Nach 20 Jahren: '
         'der eine brennt noch, der andere hat innerlich gekündigt. '
         'Der Unterschied? Nicht die Arbeit. Es ist die Geschichte, die sie sich darüber erzählen.',
         'Die vier Ebenen',
         'Schreib auf was du beruflich tust. Dann: Warum tue ich das? '
         'Warum ist das wichtig? Warum ist das wirklich wichtig? '
         'Vier Ebenen tiefer findest du deinen eigentlichen Antrieb. '
         'Viktor Frankl nannte das den Sinn. Werner nennt es: den Motor, der nicht abschaltet.',
         'ÜBUNG — VIER EBENEN',
         'Ebene 1: Was tue ich?\nEbene 2: Warum tue ich es?\nEbene 3: Warum ist das wichtig?\nEbene 4: Warum ist das wirklich wichtig?', 8,
         'Was hält dich wirklich davon ab dein volles Potenzial abzurufen?',
         ['Fehlende Fähigkeiten oder Wissen',
          'Ungünstige Umstände',
          'Meine eigene innere Bremse — Zweifel, Angst, Glaubenssätze',
          'Ich bin schon da wo ich hinwill'],
         'Wähle einen einschränkenden Glaubenssatz. Schreib ihn auf. Dann: Was wäre, wenn das nicht stimmt?',
         'Du weißt jetzt was dich antreibt. Jetzt bauen wir eine Vision, die diesem Antrieb entspricht. Kapitel 3.'),

        (3, 'Visionen die funktionieren', 'Der Unterschied zwischen Wunsch und Kompass',
         'Ich habe hunderte Visionen gehört. Die meisten klingen gut. Wenige funktionieren. Der Unterschied liegt in der Präzision des Bildes.',
         'DER VERGLEICH',
         'Vision A: „Ich will ein erfolgreiches Unternehmen aufbauen, das Menschen hilft.“\n\n'
         'Vision B: „Ich führe ein 12-Personen-Studio, das Marken hilft, in 90 Tagen mehr Umsatz zu machen — und ich bin um 17 Uhr zu Hause.“\n\n'
         'Nur eine ist ein Kompass. Welche hilft dir, bei einem Jobangebot Ja oder Nein zu sagen?',
         'Die fünf Tests',
         'Gegenwartsform: „Ich bin“ — nicht „Ich will sein.“ · '
         'Entscheidungsfilter: Du kannst damit klar Ja oder Nein sagen. · '
         'Unverwechselbarkeit: Nur du könntest diesen Satz geschrieben haben. · '
         'Körperlichkeit: Du spürst etwas wenn du sie liest. · '
         'Vermächtnis: In 20 Jahren noch wahr.',
         'DEINE VISION — ERSTER ENTWURF',
         'Ich-Form. Gegenwartsform. Unverwechselbar und zeitlos. Roh, aber echt.', 5,
         'Was passiert wenn du deine Vision laut liest?',
         ['Ich spüre Energie und Richtung',
          'Es klingt gut aber ich glaube es noch nicht ganz',
          'Es fühlt sich noch nicht wie ich an',
          'Ich habe noch keine — diese Übung zeigt mir warum'],
         'Lies deine Vision jeden Morgen eine Woche lang laut vor. Notiere täglich: Was hat sich dadurch verändert?',
         'Eine Vision ohne Werte ist wie ein Kompass ohne Magnet. Kapitel 4.'),

        (4, 'Werte unter Druck', 'Was du wirklich priorisierst — wenn es schwierig wird',
         'Werte zeigen sich in dem, was du opferst — nicht in dem, was du auf einer Liste aufschreibst.',
         'DIE GESCHICHTE',
         'Elena, 38, Führungskraft. Ihr wichtigster Wert: Nähe — gelebt in ihrer Familie. '
         'Dann das Angebot ihres Lebens — 80% Reiseanteil, doppeltes Gehalt. '
         '„Wann hast du diesen Wert zuletzt wirklich gelebt — konkret, mit Konsequenz?“ '
         'Sie schweigt drei Minuten.',
         'Die Schattenseiten',
         'Jeder Wert hat eine Schattenseite. '
         'Loyalität kann Unterwerfung sein. Exzellenz kann Perfektionismus sein. '
         'Freiheit kann Bindungsangst sein. Das ist keine Schwäche — es ist eine Information.',
         'ÜBUNG — SCHATTENSEITEN',
         'Für jeden deiner Top-3-Werte: Schreibe die Schattenseite auf. Wann hast du sie zuletzt gespielt?', 8,
         'Ein Angebot gegen deinen wichtigsten Wert — aber finanziell absichernd. Was tust du?',
         ['Ich nehme es an — Sicherheit geht vor',
          'Ich lehne ab — Werte sind nicht verhandelbar',
          'Ich verhandle andere Konditionen',
          'Ich bin mir nicht sicher'],
         '"In der letzten Woche habe ich meinen Wert [X] verletzt, weil [...]." Kein Selbstvorwurf. Nur Klarheit.',
         'Du kennst deine Werte. Wie baust du daraus eine Strategie? Kapitel 5.'),

        (5, 'Strategie ist Verzicht', 'Weniger, aber das Richtige',
         'Das größte strategische Problem: zu viele Ideen. Strategie bedeutet nicht mehr tun — sondern klarer entscheiden.',
         'DIE GESCHICHTE',
         'Steve Jobs kehrt 1997 zu Apple zurück und streicht sofort 70% der Produkte. '
         'Nicht weil sie schlecht sind — sondern weil Fokus wichtiger ist als Vollständigkeit. '
         'In den kommenden Jahren wird Apple zum wertvollsten Unternehmen der Welt.',
         'Die Nein-Liste',
         'Die stärkste strategische Übung ist keine Ziel-Liste. Es ist eine Nein-Liste. '
         'Was wirst du in den nächsten 6 Monaten bewusst nicht tun?',
         'DEINE NEIN-LISTE',
         '10 Dinge, die du in den nächsten 6 Monaten NICHT tun wirst. '
         '„Weniger Netflix“ zählt nicht — „Netflix nach 23 Uhr“ zählt.', 10,
         'Von deinen aktuellen Projekten: Wie viele bringen dich wirklich deiner Vision näher?',
         ['Fast alle — ich bin sehr fokussiert',
          'Die Hälfte',
          'Wenige — ich bin zu verstreut',
          'Ich habe noch keine Vision als Filter'],
         'Sage heute zu einer Anfrage Nein, die du bisher aus Pflichtgefühl bejaht hättest.',
         'Strategie ohne Energie ist nur ein Plan. Kapitel 6.'),

        (6, 'Energie ist deine Ressource', 'Was dich trägt — und was dich kostet',
         'Zeit ist fix. Energie ist erneuerbar. Aber nur wenn du weißt wo du sie verlierst — und wo du sie gewinnst.',
         'DIE ENTDECKUNG',
         'Olympia-Athleten trainieren nicht härter als du denkst. '
         'Das Geheimnis ist Regenerationsqualität, nicht Trainingsintensität. '
         'Die nachhaltig Erfolgreichen wissen, wann sie sich zurückziehen müssen — und tun es ohne Schuldgefühl.',
         'Dein Energiesystem',
         'Es gibt drei Arten von Energieräubern: Menschen, die dich auslaugen, '
         'Aufgaben, die keinen Sinn ergeben, Umgebungen, die dir nicht entsprechen. '
         'Du kannst nicht alle eliminieren — aber du kannst aufhören, täglich über alle drei hinwegzusehen.',
         'ÜBUNG — ENERGIEBILANZ',
         '5 Dinge, die mir Energie geben.\n5 Dinge, die mir Energie nehmen.\n'
         'Was wäre, wenn ich eine Sache aus der zweiten Liste diese Woche streiche?', 10,
         'Wann bist du in deinem Element — wenn Zeit verschwindet und Energie steigt?',
         ['Bei der Arbeit mit Menschen',
          'Bei strategischem Denken und Planen',
          'Bei kreativem Schaffen und Gestalten',
          'Wenn ich allein bin und tief nachdenken kann'],
         'Schütze diese Woche eine Stunde, die dir Energie gibt, wie ein wichtiges Meeting.',
         'Du hast Energie, Fokus und Werte. Weiter in Kapitel 7 — und dann Kapitel 8.'),

        (7, 'Wirkung hinterlassen', 'Wofür du stehst, wenn du nicht mehr da bist',
         'Das ist die Frage, die ich am liebsten stelle. Nicht weil sie schwer ist. Sondern weil sie ehrlich ist.',
         'DER VERMÄCHTNISTEST',
         'Drei Menschen, alle erfolgreich. Wer wird in 20 Jahren noch erinnert? '
         'Nicht der mit dem besten LinkedIn-Profil. '
         'Derjenige, der Menschen berührt hat — und etwas hinterlassen hat, das größer war als er selbst.',
         'Der Abstand',
         'Was würden fünf Menschen, die dich wirklich kennen, über dich sagen, wenn du morgen nicht mehr da wärst? '
         'Schreib es auf. Dann schreib auf, was du dir wünschst, dass sie sagen. '
         'Der Abstand zwischen beiden Texten ist deine Entwicklungsaufgabe.',
         'DIE ZWEI TEXTE',
         'Text 1: Was würden Menschen heute über mich sagen?\n\n\n\nText 2: Was möchte ich in 10 Jahren hören?', 8,
         'Was ist dein größtes Geschenk an die Welt, das du noch nicht entfaltet hast?',
         ['Meine Fähigkeit Menschen zu verbinden und zu führen',
          'Mein Wissen und meine Erfahrung weiterzugeben',
          'Etwas zu schaffen, das länger lebt als ich',
          'Mir selbst treu zu sein und das anderen vorzuleben'],
         'Schreibe heute eine Nachricht an jemanden, dessen Leben du beeinflusst hast. Konkret. Heute noch.',
         ''),
    ]

    _chapter_quotes = {
        1: ('Die größte Entdeckung meiner Generation ist, dass ein Mensch sein Leben '
            'verändern kann, indem er seine Geisteshaltung ändert.',
            'William James'),
        2: ('Der Mensch ist nicht frei von Bedingungen. '
            'Aber er ist frei, zu ihnen Stellung zu nehmen.',
            'Viktor E. Frankl'),
        3: ('Diejenigen, die verrückt genug sind zu glauben, '
            'sie können die Welt verändern — sind diejenigen, die es tun.',
            'Steve Jobs, „Think Different“-Kampagne'),
        4: ('Ich habe gelernt, dass Mut nicht die Abwesenheit von Furcht ist — '
            'sondern der Triumph über sie.',
            'Nelson Mandela, „Long Walk to Freedom“'),
        5: ('Non refert quam multos libros habeas. '
            'Es kommt nicht darauf an wie viel du hast — '
            'sondern wie tief du es verstehst.',
            'Seneca'),
        6: ('Bald wirst du alles vergessen haben — '
            'und bald werden alle dich vergessen haben.',
            'Marc Aurel, Selbstbetrachtungen'),
        7: ('Menschen vergessen, was du gesagt hast. '
            'Sie vergessen, was du getan hast. '
            'Aber sie vergessen nie, wie du sie fühlen ließest.',
            'Maya Angelou'),
    }

    for (num, title, sub, quote, story_lbl, story_txt, h2_txt, theory,
         ex_lbl, ex_txt, ex_lines, quiz_q, quiz_opts, commit_txt, thread_txt) in chapter_data:

        ch_store[0] = f'Kapitel {num} — {title}'
        story += chapter_intro_page(num, title, sub, s, num)
        story += werner_box(quote, s)
        story += story_box(story_lbl, story_txt, s)
        story.append(Paragraph(h2_txt, s['h2']))
        story.append(Paragraph(theory, s['body']))
        story += exercise_box(ex_lbl, ex_txt, s, ex_lines)
        story.append(renderPDF.GraphicsFlowable(divider_ornament()))
        story += quiz_box(quiz_q, quiz_opts, s)
        story += commitment(commit_txt, s)
        if thread_txt:
            story += thread(thread_txt, s)
        _q = _chapter_quotes.get(num)
        if _q:
            story += quote_page(_q[0], _q[1], s)

        # ── VERTIEFUNGS-SCHREIBRAUM je Kapitel ───────────────────────────────
        story += wb_ext.kapitel_schreibraum(num, s)

        # ── ERWEITERUNGEN: Selbsttests + Werkstätten je Themenblock ──────────
        if num == 2:
            ch_store[0] = 'Selbsttest — Fundament'
            story += wb_ext.selftest_fundament(s)
        elif num == 3:
            ch_store[0] = 'Visions-Werkstatt'
            story += wb_ext.werkstatt_vision(s)
            ch_store[0] = 'Selbsttest — Vision'
            story += wb_ext.selftest_vision(s)
        elif num == 4:
            ch_store[0] = 'Werte-Werkstatt'
            story += wb_ext.werkstatt_werte(s)
            ch_store[0] = 'Selbsttest — Werte'
            story += wb_ext.selftest_werte(s)
        elif num == 5:
            ch_store[0] = 'Strategie-Werkstatt'
            story += wb_ext.werkstatt_strategie(s)
            ch_store[0] = 'Selbsttest — Strategie'
            story += wb_ext.selftest_strategie(s)

    # KAPITEL 8
    # ══════════════════════════════════════════════════════════════════════════
    # KAPITEL 8 — OLYMPIONIKEN
    # ══════════════════════════════════════════════════════════════════════════
    ch_store[0] = 'Kapitel 8 — Warum Olympioniken weniger trainieren'
    story += chapter_intro_page(8,
        'Warum Olympioniken weniger trainieren',
        'Leistung durch Regeneration, nicht durch Erschöpfung', s, 8)

    story += werner_box(
        'Die meisten Menschen denken, Spitzenleistung entsteht durch mehr Einsatz. '
        'Das Gegenteil ist wahr. Die Besten leisten mehr, weil sie klüger pausieren.', s)

    story += story_box('DIE ENTDECKUNG',
        'Michael Phelps, 23-facher Olympiasieger, schläft 10 bis 12 Stunden pro Nacht. '
        'Roger Federer 11 bis 12. LeBron James investiert jährlich 1,5 Millionen Dollar '
        'in Schlaf, Erholung und Körperpflege — nicht in Training. '
        'Norwegische Langläufer, die das Ausdauersport-Training revolutioniert haben, '
        'absolvieren 80% ihres Trainings bei niedriger Intensität. '
        'Nur 20% ist Hochleistung. Das nennt sich die 80/20-Regel — '
        'und es gilt nicht nur im Sport.', s)

    story.append(KeepTogether([Paragraph('Was das bedeutet', s['h2']), Spacer(1,4)]))
    story.append(Paragraph(
        'Schlafforscher Matthew Walker hat gezeigt: eine einzige Nacht unter sechs Stunden '
        'Wer 17 Stunden wach ist, reagiert so eingeschränkt wie mit 0,5 Promille — das ist Studienlage, kein Bauchgefühl. '
        'Entscheidungsqualität, Kreativität, emotionale Intelligenz — alles bricht ein. '
        'Kein Kaffee gleicht das aus. Kein Willensakt. '
        'Der Körper ist kein Feind der Leistung. Er ist ihre Grundlage.', s['body']))

    story.append(KeepTogether([Paragraph('Fünf Strategien der Besten', s['h2']), Spacer(1,4)]))

    strategies = [
        ('Die 80/20-Regel',
         'Achtzig Prozent deiner Arbeit in einem Tempo, das sich nachhaltig anfühlt. '
         'Zwanzig Prozent volle Intensität. Nicht umgekehrt. '
         'Die meisten Führungskräfte leben auf Dauer im 100-Prozent-Modus — '
         'und wundern sich, warum die Kreativität nachlässt.'),
        ('Periodisierung',
         'Olympioniken planen Hochphasen und Tiefphasen in Wochen- und Monatsrhythmen. '
         'Nicht jede Woche ist Wettkampfwoche. '
         'Plane auch du bewusst Regenerationswochen ein — '
         'Wochen mit weniger Terminen, weniger Output, mehr Denken.'),
        ('Schlaf als nicht verhandelbar',
         'Sieben bis neun Stunden. Nicht als Luxus — als Voraussetzung. '
         'Wer weniger schläft trifft schlechtere Entscheidungen, '
         'lernt langsamer und reagiert emotionaler. '
         'Das sind keine Empfehlungen. Das sind Messwerte.'),
        ('Aktive Regeneration',
         'Vollständige Pause ist oft schlechter als leichte Bewegung. '
         'Ein 20-minütiger Spaziergang nach intensiver Arbeit '
         'beschleunigt die Erholung mehr als Sitzen. '
         'Dein Körper regeneriert besser wenn er in Bewegung bleibt.'),
        ('Flow schützen',
         'Identifiziere deine zwei bis drei Stunden täglich in denen du am schärfsten bist. '
         'Schütze diese Zeit vor allem anderen. '
         'Keine Meetings. Keine E-Mails. Nur deine wichtigste Arbeit. '
         'Das ist Leistungsoptimierung ohne ein einziges zusätzliches Stunde Arbeit.'),
    ]

    for title_s, desc_s in strategies:
        story.append(KeepTogether([
            Paragraph(title_s, s['label_cr']),
            Paragraph(desc_s, s['body']),
            Spacer(1, 4),
        ]))

    story.append(KeepTogether([Paragraph('Dein persönlicher Leistungsrhythmus', s['h2']), Spacer(1,4)]))
    story.append(Paragraph(
        'Jeder Mensch hat einen biologisch bestimmten Rhythmus. '
        'Lerche oder Eule, Morgentyp oder Abendtyp — das ist keine Charakterfrage, '
        'sondern Genetik. Die Frage ist nicht, wann du solltest, '
        'sondern wann du am besten bist.', s['body']))

    story += exercise_box('ÜBUNG — DEIN ENERGIE-KALENDER',
        'Zeichne eine typische Arbeitswoche auf. '
        'Markiere: Wann bist du auf dem Höhepunkt? (Hochphase) '
        'Wann läufst du auf Reserve? (Tiefphase) '
        'Wann regenerierst du bewusst? '
        'Vergleiche das mit deinem aktuellen Kalender. '
        'Was fällt auf?', s, lines=6)

    story += exercise_box('ÜBUNG — DAS REGENERATIONS-PROTOKOLL',
        'Diese Woche: Führe Protokoll über deine Energie. '
        'Morgens (vor der Arbeit), mittags und abends je eine Zahl von 1 bis 10. '
        'Nach sieben Tagen siehst du deinen Rhythmus. '
        'Kein Tool nötig — ein Blatt Papier reicht.', s, lines=7)

    story += quiz_box(
        'Wie viele Stunden schläfst du durchschnittlich pro Nacht?',
        ['Unter 6 Stunden — ich komme damit zurecht',
         '6 bis 7 Stunden — könnte mehr sein',
         '7 bis 8 Stunden — ich achte darauf',
         '8 Stunden oder mehr — Schlaf ist mir wichtig'], s)

    story += commitment(
        'Diese Woche: Schütze täglich eine 90-Minuten-Regenerationsphase '
        'genauso wie ein wichtiges Meeting. '
        'Kein Bildschirm. Bewegung, Schlaf oder bewusste Stille. '
        'Trage sie jetzt in den Kalender ein.', s)

    story += thread(
        'Energie, Fokus, Werte — und jetzt Vorbilder. '
        'Was können wir von den größten Visionären der Geschichte lernen? Kapitel 9.', s)

    story += wb_ext.kapitel_schreibraum(8, s)

    # Quote after chapter 8
    story += quote_page(
        'Du kannst nicht beständig leisten, was du nicht beständig aufladen kannst.',
        'Jim Loehr & Tony Schwartz, „The Power of Full Engagement“', s)

    ch_store[0] = 'Kapitel 9 — Visionäre, Strategen, Werteverfechter'
    story += chapter_intro_page(9,
        'Visionäre, Strategen, Werteverfechter',
        'Was historische Persönlichkeiten uns lehren', s, 9)

    story += werner_box(
        'Die besten Lehrmeister sind nicht die lautesten. '
        'Sie sind diejenigen, die etwas riskiert haben und es trotzdem getan haben.', s)

    story.append(KeepTogether([Paragraph('Vision', s['h2']), Spacer(1,2)]))

    story += story_box('NELSON MANDELA — DIE VISION DIE 27 JAHRE UEBERDAUERT',
        'Mandela verbringt 27 Jahre im Gefängnis. Seine Vision: ein freies '
        'demokratisches Südafrika ohne Apartheid. So präzise und so tief verankert, '
        'dass sie keine äußeren Bedingungen braucht. Als er 1990 freikommt '
        'sagt er nicht: Was habe ich verloren. Er sagt: Jetzt beginnt die eigentliche Arbeit. '
        'Was ich daraus gelernt habe: Eine Vision, die nur unter guten Bedingungen trägt, '
        'ist kein Kompass. Sie ist ein Wunsch.', s)

    story += story_box('LEONARDO DA VINCI — DIE VISION DES GANZEN MENSCHEN',
        'Da Vinci malt nicht nur. Er entwirft Maschinen, studiert Anatomie, '
        'komponiert Musik, schreibt über Hydrodynamik. Seine Vision: den Menschen '
        'und die Natur vollständig verstehen. Nicht als Spezialist, sondern als '
        'Beobachter des Ganzen. Was ich daraus gelernt habe: Die stärksten Visionen beschreiben nicht einen Beruf. '
        'Sie beschreiben eine Art zu sein.', s)

    story.append(KeepTogether([Paragraph('Werte', s['h2']), Spacer(1,2)]))

    story += story_box('MARCUS AURELIUS — WERTE UNTER DRUCK',
        'Kaiser Marcus Aurelius regiert das mächtigste Reich der Welt und könnte alles haben. '
        'Trotzdem schreibt er jeden Abend in sein Tagebuch Rechenschaft über seine eigenen Werte: '
        'Gerechtigkeit, Besonnenheit, Mut, Weisheit. Nicht für die Öffentlichkeit. Für sich selbst. Was ich daraus gelernt habe: Werte, die niemand sieht, sind die einzigen echten. '
        'Prüfe sie jeden Abend still gegen dein Handeln.', s)

    story += story_box('ROSA PARKS — EIN WERT, EIN MOMENT, EINE BEWEGUNG',
        'Montgomery 1955. Rosa Parks weigert sich, ihren Sitzplatz im Bus freizugeben. '
        'Kein langer Plan. Kein Kalkül. Nur ein Wert, der in diesem Moment '
        'stärker ist als die Konsequenz. Was ich daraus gelernt habe: Werte zeigen sich nicht in Reden. '
        'Sie zeigen sich in dem einen Moment in dem es wirklich darauf ankommt.', s)

    story.append(KeepTogether([Paragraph('Strategie', s['h2']), Spacer(1,2)]))

    story += story_box('SENECA — STRATEGIE DURCH FOKUS',
        'Seneca schreibt: Non refert quam multos libros habeas. '
        'Es kommt nicht darauf an wie viele Bücher du hast. '
        'Sein Kerngedanke ist radikal einfach: Weniger. Tiefer. Konsequenter. Was ich daraus gelernt habe: Strategie ist nicht das Summieren von Möglichkeiten. '
        'Es ist das Streichen von allem, was nicht zählt.', s)

    story += story_box('FLORENCE NIGHTINGALE — DATEN ALS STRATEGIE',
        'Nightingale rettet im Krimkrieg tausende Leben nicht mit Mut allein '
        'sondern mit Strategie. Sie erfindet die statistische Grafik als '
        'Kommunikationsmittel und überzeugt das britische Militär mit Daten statt Emotion. Was ich daraus gelernt habe: Die wirksamste Strategie verbindet Haltung mit Methode. '
        'Werte sagen warum. Strategie sagt wie.', s)

    story.append(KeepTogether([Paragraph('Was sie gemeinsam haben', s['h2']), Spacer(1, 4)]))
    story.append(Paragraph(
        'Keiner dieser Menschen hatte perfekte Bedingungen. '
        'Keiner wartete auf Erlaubnis. '
        'Alle hatten ein klares Bild davon, wer sie waren, und ließen sich davon leiten '
        'wenn es schwierig wurde. Das ist keine Frage der Geschichte. '
        'Das ist eine Frage der Entscheidung.', s['body']))

    story += exercise_box('DEINE INSPIRATION',
        'Wer spricht dich am meisten an? Was genau berührt dich daran? '
        'Und: Was davon steckt auch in dir, noch unentfaltet?', s, lines=5)

    story += commitment(
        'Benenne eine historische Persönlichkeit, die du in den nächsten 30 Tagen '
        'tiefer kennenlernen willst. Ihre Biografie. Ihre Entscheidungen. '
        'Was würde sie in deiner aktuellen Situation tun?', s)

        # Vertiefung Kapitel 9
    story += wb_ext.kapitel_schreibraum(9, s)

    # ── ENERGIE-PROTOKOLL (zu Kapitel 6/8) ───────────────────────────────
    story.append(PageBreak())
    ch_store[0] = 'Energie-Protokoll'
    story += wb_ext.werkstatt_energie(s)

    # ── BERUFSPROFILE ─────────────────────────────────────────────────────────
    ch_store[0] = 'Vorbilder aus der Praxis'
    story += wb_ext.berufsprofile(s)

    # ── 6-WOCHEN-PROGRAMM ─────────────────────────────────────────────────────
    ch_store[0] = 'Das 6-Wochen-Programm'
    story += wb_ext.wochenprogramm(s)

    # ── DRANBLEIBEN ───────────────────────────────────────────────────────────
    ch_store[0] = 'Dranbleiben'
    story += wb_ext.dranbleiben(s)

    # ══════════════════════════════════════════════════════════════════════════
    # WERNERS EMPFEHLUNGEN
    # ══════════════════════════════════════════════════════════════════════════
    ch_store[0] = 'Werners Empfehlungen'
    story += [
        PageBreak(),
        Spacer(1, 0.6*cm),
        Paragraph('WERNERS EMPFEHLUNGEN', s['kap_num']),
        Paragraph('Was ich selbst genutzt habe', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 24),
    ]

    story.append(KeepTogether([Paragraph('Bücher', s['h2']), Spacer(1, 4)]))
    books = [
        ('The Courage to Be Disliked', 'Ichiro Kishimi & Fumitake Koga',
         'Adlers Psychologie als Streitgespräch zwischen einem Philosophen '
         'und einem jungen Mann. Befreit vom Urteil der anderen — '
         'radikaler, als der Titel klingt.'),
        ('Man\u2019s Search for Meaning', 'Viktor E. Frankl',
         'Frankl findet Sinn in einem Konzentrationslager. '
         'Wenn das möglich ist, ist alles möglich. '
         'Das Fundament von allem, was in Kapitel 2 steht.'),
        ('Thinking, Fast and Slow', 'Daniel Kahneman',
         'Wie wir wirklich entscheiden — und warum wir uns so oft irren. '
         'Sehr nützlich für jeden, der strategisch denken will.'),
        ('Also sprach Zarathustra', 'Friedrich Nietzsche',
         'Keine leichte Kost, kein Ratgeber. Aber wer den eigenen Weg sucht, '
         'findet hier den härtesten Sparringspartner der Literatur.'),
        ('Die Prinzipien des Erfolgs', 'Ray Dalio',
         'Dalio macht Entscheidungen wiederholbar: Prinzipien statt '
         'Bauchgefühl. Das Kapitel über radikale Transparenz allein '
         'lohnt das Buch.'),
        ('Hagakure', 'Yamamoto Tsunetomo',
         'Der Kodex der Samurai, dreihundert Jahre alt. Über Haltung, '
         'wenn niemand zusieht — und Klarheit im Angesicht der Konsequenz.'),
    ]
    for title_b, author_b, desc_b in books:
        story.append(Paragraph(
            f'<b>{title_b}</b> — {author_b}',
            ParagraphStyle('bk', fontName='Helvetica', fontSize=10.5,
                leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_b,
            ParagraphStyle('bkd', fontName='Helvetica', fontSize=9.5,
                leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))

    story.append(KeepTogether([Paragraph('Hörbücher', s['h2']), Spacer(1, 4)]))
    audiobooks = [
        ('Ikigai', 'Héctor García & Francesc Miralles',
         'Warum die Menschen auf Okinawa hundert werden — und was dein '
         'Grund ist, morgens aufzustehen. Leicht zu hören, lange im Kopf.'),
        ('Der Sinn des Lebens', 'Alfred Adler',
         'Das Original von 1933 hinter der modernen Sinn-Literatur. '
         'Adler steckt in meinem Coaching öfter, als du denkst.'),
        ('Start with No', 'Jim Camp',
         'Verhandeln ohne Win-win-Floskeln: Das Nein als stärkster '
         'Startpunkt. Ein Werkzeugkasten für jedes harte Gespräch.'),
    ]
    for title_a, author_a, desc_a in audiobooks:
        story.append(Paragraph(
            f'<b>{title_a}</b> — {author_a}',
            ParagraphStyle('ab', fontName='Helvetica', fontSize=10.5,
                leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_a,
            ParagraphStyle('abd', fontName='Helvetica', fontSize=9.5,
                leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))

    story.append(KeepTogether([Paragraph('Dokumentationen & Serien', s['h2']), Spacer(1, 4)]))
    series = [
        ('The Last Dance', 'Netflix',
         'Michael Jordan und der Weg zur Spitze. '
         'Führung, Werte unter Druck, Strategie in Echtzeit. '
         'Mehr Coaching als Sport.'),
        ('The Crown', 'Netflix',
         'Ein halbes Jahrhundert zwischen Person und Amt: was es kostet, '
         'einer Rolle treu zu bleiben. Ganz nebenbei die beste Studie '
         'über Macht in Institutionen.'),
        ('Built In Birmingham: Brady & The Blues', 'Prime Video',
         'Tom Brady übernimmt einen englischen Traditionsverein. '
         'Vision gegen Realität, Woche für Woche — Strategie zum Zuschauen.'),
        ('Be Water — Die Bruce Lee-Story', 'Disney+',
         'Bruce Lee in eigenen Worten und seltenem Archivmaterial. '
         'Anpassungsfähigkeit als Strategie: Sei formlos. Sei Wasser.'),
    ]
    for title_s, platform_s, desc_s in series:
        story.append(Paragraph(
            f'<b>{title_s}</b> — {platform_s}',
            ParagraphStyle('sr', fontName='Helvetica', fontSize=10.5,
                leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_s,
            ParagraphStyle('srd', fontName='Helvetica', fontSize=9.5,
                leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))

    story.append(KeepTogether([Paragraph('Übungen', s['h2']), Spacer(1, 4)]))
    exercises = [
        ('Das Abend-Journal',
         'Fünf Minuten vor dem Schlafen. Drei Fragen: Was war heute gut? '
         'Was hätte ich anders gemacht? Was nehme ich morgen mit? '
         'Nicht mehr. Nicht weniger. '
         'Nach 30 Tagen siehst du Muster, die du vorher nicht gesehen hast.'),
        ('Die Wochenfrage',
         'Jeden Sonntag eine einzige Frage: '
         'War ich diese Woche der Mensch, der ich sein will? '
         'Ja oder Nein. Keine Ausrede. Kein Kommentar. '
         'Diese eine Frage hat bei meinen Klienten mehr verändert '
         'als jede Technik, die ich kenne.'),
        ('Box Breathing — Atemübung für klare Entscheidungen',
         '4 Sekunden einatmen. 4 Sekunden halten. 4 Sekunden ausatmen. '
         '4 Sekunden halten. Vier Runden. Zwei Minuten. '
         'Ich mache das vor wichtigen Gesprächen und vor jeder Entscheidung, '
         'die ich nüchtern treffen will. Die Gedanken werden dadurch kristallklar.'),
        ('Die Fünf-Minuten-Kraft — Körperübung ohne Ausrede',
         '5 Liegestütze. 10 Kniebeugen. 15 Sekunden Plank. '
         'Dreimal wiederholen — das sind acht Minuten. '
         'Nicht wegen der Muskeln. Sondern weil du deinem Kopf zeigst, '
         'dass du tust, was du dir vornimmst. '
         'Disziplin im Kleinen überträgt sich auf das Große.'),
        ('Der 20-Minuten-Gang — Ausdauer als Denkwerkzeug',
         'Jeden Tag 20 Minuten zu Fuß. Kein Telefon. Keine Kopfhörer. '
         'Nur du und dein Tempo. '
         'Die meisten meiner besten Ideen sind beim Gehen entstanden. '
         'Bewegung löst Denkblockaden schneller als Kaffee und Brainstorming zusammen.'),
        ('Der Prä-Mortem — Strategisches Denken üben',
         'Vor jeder wichtigen Entscheidung: Stell dir vor, es ist ein Jahr später '
         'und die Entscheidung ist gründlich schiefgelaufen. '
         'Was ist passiert? Schreib es auf. '
         'Dann frag: Was hätte ich vorher sehen können? '
         'Diese Übung hat mir mehr schlechte Entscheidungen erspart '
         'als alle Strategieframeworks, die ich kenne.'),
    ]

    for title_e, desc_e in exercises:
        story.append(Paragraph(f'<b>{title_e}</b>',
            ParagraphStyle('ex', fontName='Helvetica', fontSize=10.5,
                leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_e,
            ParagraphStyle('exd', fontName='Helvetica', fontSize=9.5,
                leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))

    story += werner_box(
        'Sechs Übungen, vier Routinen in diesem Buch — niemand macht alles, '
        'und das musst du auch nicht. Wenn du nur eines mitnimmst: die '
        'Wochenfrage. Ein Sonntag, eine Frage, ein ehrliches Ja oder Nein. '
        'Alles andere ist Ausbau.', s)

    story.append(PageBreak())

    # ══════════════════════════════════════════════════════════════════════════
    # GROESSTE STRATEGISCHE LEISTUNGEN DER GESCHICHTE
    # ══════════════════════════════════════════════════════════════════════════
    ch_store[0] = 'Strategische Meisterleistungen'
    story += [
        Spacer(1, 0.6*cm),
        Paragraph('STRATEGISCHE MEISTERLEISTUNGEN', s['kap_num']),
        Paragraph('Was die Geschichte über Strategie lehrt', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 24),
        Paragraph(
            'Die großen Strategen der Geschichte hatten eines gemeinsam: '
            'Sie entschieden sich für das Wesentliche '
            'und verzichteten konsequent auf alles andere. '
            'Hier sind fünf Lektionen, die heute noch gelten.',
            s['body']),
    ]

    achievements = [
        ('ALEXANDER DER GROSSE — GESCHWINDIGKEIT ALS STRATEGIE',
         'Alexander besiegt das Persische Reich nicht durch überlegene Zahlen. '
         'Sein Heer ist kleiner. Bei Gaugamela 331 v. Chr. lässt er absichtlich '
         'eine Lücke in seiner Linie um den Gegner hineinzuziehen. '
         'Was ich daraus gelernt habe: Die schnellste Entscheidung schlägt häufig '
         'die beste. Perfektion ist der Feind des Handelns.',
         'Vision: Ich werde die Grenzen der bekannten Welt überschreiten.'),
        ('NAPOLEON BONAPARTE — KONZENTRATION DER KRAEFTE',
         'Napoleons Genie basiert auf einem Prinzip: nie die Kräfte aufteilen '
         'wenn man sie konzentrieren kann. Bei Austerlitz 1805 erscheint sein rechter '
         'Flügel absichtlich schwach um in der Mitte durchzubrechen. '
         'Was ich daraus gelernt habe: Fokus schlägt Breite. Immer.',
         'Strategie: Teile den Feind — konzentriere dich selbst.'),
        ('WINSTON CHURCHILL — VISION IN DER DUNKELSTEN STUNDE',
         '1940. Frankreich fällt. Churchills Kabinett diskutiert Friedensverhandlungen. '
         'Churchill weigert sich. Nicht weil er sicher ist zu gewinnen — '
         'sondern weil seine Vision von einem freien Europa keine Verhandlungsoption zulässt. '
         'Was ich daraus gelernt habe: Eine echte Vision ist kein Luxus für gute Zeiten.',
         'Vision: Wir werden niemals aufgeben.'),
        ('HANNIBAL BARCA — DER UMWEG ALS DIREKTER WEG',
         'Hannibal überquert mit Elefanten die Alpen — den Weg, den Rom für unmöglich hält. '
         'Bei Cannae 216 v. Chr. besiegt er eine römische Armee, die fast doppelt so groß ist. '
         'Seine Strategie: nicht frontal angreifen, sondern einhüllen. '
         'Was ich daraus gelernt habe: Wer nur den direkten Weg kennt, wird vorhersehbar.',
         'Strategie: Tue das Unerwartete — konsequent.'),
        ('MAHATMA GANDHI — WERTE ALS WAFFE',
         'Gandhi besiegt das British Empire nicht mit Gewalt, sondern mit Satyagraha — '
         'der Kraft der Wahrheit. Er entzieht dem Imperium seine moralische Legitimität. '
         'Was ich daraus gelernt habe: Werte sind keine Schwäche. '
         'Sie sind die stärkste strategische Ressource, die du hast.',
         'Werte: Sei die Veränderung, die du in der Welt sehen willst.'),
    ]
    for title_h, text_h, lens_h in achievements:
        story.append(Paragraph(title_h, s['label_cr']))
        story.append(Paragraph(text_h, s['body']))
        story.append(Paragraph(lens_h,
            ParagraphStyle('lens', fontName='Lora-It', fontSize=10,
                leading=16, textColor=SL, spaceAfter=16,
                leftIndent=16)))

    story.append(PageBreak())

    # ── RITUAL ────────────────────────────────────────────────────────────────
    
    # ══════════════════════════════════════════════════════════════════════════
    # ABSCHLUSSPORTRAIT — TUPAC SHAKUR
    # ══════════════════════════════════════════════════════════════════════════
    ch_store[0] = 'Abschlussportrait — Tupac Shakur'
    story += [
        PageBreak(),
        Spacer(1, 0.6*cm),
        Paragraph('ABSCHLUSSPORTRAIT', s['kap_num']),
        Paragraph('Tupac Shakur', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 14),
        Paragraph('Ein Mann mit Vision, Werten und Strategie', s['kap_sub']),
        Spacer(1, 0.5*cm),
        Paragraph(
            'Tupac Amaru Shakur, 1971 in New York geboren, 1996 in Las Vegas erschossen. '
            '25 Jahre alt. Dichter, Rapper, Schauspieler — und bis heute eine der '
            'meistgehörten Stimmen der Welt, mit über 75 Millionen verkauften Alben. '
            'Er steht am Ende dieses Kapitels, weil er etwas zeigt, das in keiner '
            'Vorstandsetage zu lernen ist: Vision, Werte und Strategie sind kein '
            'Privileg der Gebildeten und Etablierten. Sie sind ein Konzept für jedes Leben — '
            'auch für eines, das in Armut beginnt und gegen alle Wahrscheinlichkeiten anläuft.', s['body']),
        Spacer(1, 0.3*cm),
        Paragraph('VISION — DIE STIMME DER STIMMLOSEN', s['label_cr']),
        Paragraph(
            'Seine Mutter Afeni Shakur war Bürgerrechtsaktivistin; seinen Namen trug er '
            'nach einem Anführer des Aufstands gegen die Kolonialherrschaft in Peru. Tupacs Vision war von '
            'Anfang an größer als seine Karriere: Er wollte denen eine Stimme geben, '
            'die keine hatten — den Übersehenen der amerikanischen Großstädte. Nicht '
            'irgendwann, sondern in jedem Song, in jedem Interview, in jeder Rolle. '
            'Seine Vision war ein Zustand, kein Plan:', s['body']),
        Paragraph('„I will spark the brain that will change the world.“', s['quote']),
        Paragraph('Ich werde das Gehirn entzünden, das die Welt verändern wird. — MTV-Interview, 1994', s['quote_attr']),
        Spacer(1, 0.2*cm),
        Paragraph('WERTE — WAHRHAFTIGKEIT, LOYALITÄT, WÜRDE', s['label_cr']),
        Paragraph(
            'Tupac sagte, was er dachte — auch wenn es ihn Plattenverträge, Sympathien '
            'und am Ende vielleicht das Leben kostete. Seine Loyalität galt seiner '
            'Herkunft und seiner Mutter, der er mitten im Erfolg öffentlich seine '
            'Dankbarkeit erwies. Sein Maßstab war Echtheit: lieber anecken als sich '
            'verbiegen. Sein Lieblingssatz, frei nach Shakespeare, war sein '
            'Wertekompass in einem Satz:', s['body']),
        Paragraph('„A coward dies a thousand deaths. A soldier dies but once.“', s['quote']),
        Paragraph('Ein Feigling stirbt tausend Tode. Ein Soldat stirbt nur einmal. — frei nach Shakespeare, Julius Caesar', s['quote_attr']),
        PageBreak(),
        Spacer(1, 0.6*cm),
        Paragraph('STRATEGIE — EIN WERK, DAS DEN MENSCHEN ÜBERDAUERT', s['label_cr']),
        Paragraph(
            'Das Unterschätzteste an Tupac war seine Strategie. Er las Machiavelli und '
            'Sun Tsu im Gefängnis — und nannte sich danach Makaveli. Er nahm in '
            'wenigen Jahren hunderte Songs auf, weit mehr als er veröffentlichen '
            'konnte: ein bewusst angelegter Vorrat. Er baute parallel eine zweite '
            'Karriere als Schauspieler auf — ein zweites Standbein, falls die Musik '
            'endet. Er dachte voraus statt zu reagieren: Er wusste um die Fragilität '
            'seines Lebens und baute ein Werk, das ihn überdauern würde. Es erschienen '
            'mehr Alben nach seinem Tod als zu Lebzeiten — kein Zufall, sondern Antizipation. '
            'Das ist Strategie in Reinform: Meilensteine, die der Vision dienen, '
            'nicht dem Moment.', s['body']),
        Spacer(1, 0.4*cm),
    ]
    story += werner_box(
        'Du musst Tupacs Musik nicht mögen, um von ihm zu lernen. Eine Vision, '
        'die aus dem eigenen Schmerz wächst. Werte, die auch unter Druck nicht '
        'verhandelt werden. Eine Strategie, die weiter denkt als das eigene Leben. '
        'Vision, Werte, Strategie — das ist kein Konzept für Vorstandsetagen. '
        'Es ist ein Konzept für ein Leben. Auch für deines.', s)
    story += commitment(
        'Welche Spur willst du hinterlassen — und was davon beginnst du noch in '
        'dieser Woche?', s)
    story.append(PageBreak())

    ch_store[0] = 'Das Ritual'
    story += [
        rule('100%', 0.4, RU, 24, 20),
        Paragraph('DAS RITUAL', s['kap_num']),
        Spacer(1, 0.3*cm),
        Paragraph('Dein Versprechen an dich', s['sect_hero']),
        rule('20%', 2.5, CR, 6, 20),
        Paragraph('Du hast neun Kapitel gearbeitet. '
                  'Du hast Fragen beantwortet, die du dir selten stellst. '
                  'Jetzt noch ein letzter Schritt.', s['body']),
        Paragraph('Schreibe einen einzigen Satz, der beschreibt, wer du in drei Jahren sein wirst. '
                  'Nicht was du haben wirst — wer du sein wirst.', s['ritual_body']),
        Spacer(1, 1.8*cm),
    ]
    for lbl in ['Mein Satz:', 'Datum:', 'Unterschrift:']:
        story.append(Paragraph(lbl, s['small_nv']))
        story.append(HRFlowable(width='58%', thickness=0.4, color=RU,
                                spaceBefore=4, spaceAfter=28))
    story += [
        Spacer(1, 1.2*cm),
        Paragraph('Falte diese Seite. Lege sie weg. Öffne sie in drei Jahren.', s['small']),
        PageBreak(),
    ]

    # ── NOTIZEN ───────────────────────────────────────────────────────────────
    ch_store[0] = 'Notizen'
    story += wb_ext.notizen_seiten(s, 8)

    # ── IMPRESSUM ─────────────────────────────────────────────────────────────
    ch_store[0] = 'Impressum'
    imp_h = ParagraphStyle('imph', parent=s['h2'], fontSize=13)
    imp_t = ParagraphStyle('impt', fontName='Helvetica', fontSize=9, leading=15,
                           textColor=CH, spaceAfter=10)
    imp_l = ParagraphStyle('impl', fontName='Helvetica', fontSize=7.5, leading=12,
                           textColor=HexColor('#888888'), spaceAfter=8)
    story += [
        PageBreak(),
        Spacer(1, 0.8*cm),
        Paragraph('Impressum', imp_h),
        rule('12%', 1.5, CR, 6, 18),
        Paragraph('<b>© 2026 Dr. Werner von der Bey, MBA</b><br/>Alle Rechte vorbehalten. 1. Auflage 2026.', imp_t),
        Paragraph('von der Bey Consulting<br/>'
                  'Dr. Werner von der Bey<br/>'
                  'von-Rauhenbergstr. 2<br/>'
                  '86424 Dinkelscherben', imp_t),
        Paragraph('wo@vonderbeyconsulting.com<br/>'
                  '+49 152 57 66 05 01<br/>'
                  'www.vonderbeyconsulting.com', imp_t),
        Spacer(1, 0.4*cm),
        Paragraph('<b>Hinweise</b>', imp_t),
        Paragraph('Die Fallbeispiele in diesem Buch sind frei erfunden. '
                  'Ähnlichkeiten mit realen Personen wären zufällig und nicht beabsichtigt.', imp_l),
        Paragraph('Dieses Buch gibt Coaching-Impulse und Anregungen zur Selbstreflexion. '
                  'Es ersetzt keine medizinische, psychotherapeutische oder rechtliche Beratung. '
                  'Die Durchführung der beschriebenen Übungen erfolgt in eigener Verantwortung.', imp_l),
        Paragraph('Zitate wurden nach bestem Wissen geprüft und ihren Urhebern zugeschrieben. '
                  'Genannte Marken und Titel sind Eigentum ihrer jeweiligen Inhaber; '
                  'die Nennung erfolgt redaktionell.', imp_l),
        Paragraph('Gestaltung und Satz: von der Bey Consulting.', imp_l),
    ]

    # ── BACK PAGE ─────────────────────────────────────────────────────────────
    ch_store[0] = ''
    bp_name = ParagraphStyle('bpn', parent=s['h2'], alignment=1)
    bp_role = ParagraphStyle('bpr', parent=s['kap_sub'], alignment=1)
    bp_body = ParagraphStyle('bpb', parent=s['body'], alignment=1)
    bp_mail = ParagraphStyle('bpm', parent=s['small'], alignment=1, textColor=NV, fontSize=10, leading=16)
    bp_web  = ParagraphStyle('bpw', parent=s['small'], alignment=1, textColor=CR, fontSize=10.5, leading=16)
    story += [
        Spacer(1, 2.2*cm),
        Paragraph('Dr. Werner von der Bey, MBA', bp_name),
        Paragraph('Coach · <i>Vision, Werte, Strategie</i>', bp_role),
        Spacer(1, 0.7*cm),
        rule('12%', 1.5, CR, 0, 18),
        Paragraph('Die Antworten gehören dir. Nicht mir.', bp_body),
        Spacer(1, 1.4*cm),
        rule('30%', 0.6, '#D8D4CC', 0, 14),
        Paragraph('wo@vonderbeyconsulting.com', bp_mail),
        Paragraph('+49 152 57 66 05 01', bp_mail),
        Spacer(1, 0.25*cm),
        Paragraph('www.vonderbeyconsulting.com', bp_web),
    ]

    doc.build(story, canvasmaker=rl_canvas.Canvas)
    size = os.path.getsize(path)
    print(f'✅ Premium Workbook: {path}')
    print(f'   {size:,} bytes ({size//1024} KB)')

if __name__ == '__main__':
    import sys
    name = sys.argv[1] if len(sys.argv) > 1 else ''
    build('/mnt/user-data/outputs/VWS_Workbook_Master.pdf', coachee_name=name)
