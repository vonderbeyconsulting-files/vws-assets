# -*- coding: utf-8 -*-
"""Kentaur-Vektorisierung über libpotrace (ctypes) — echte Kurvenverfolgung."""
import ctypes as C
import numpy as np
from PIL import Image, ImageDraw

lib = C.CDLL('libpotrace.so.0')

class DPoint(C.Structure):
    _fields_ = [('x', C.c_double), ('y', C.c_double)]

class Curve(C.Structure):
    _fields_ = [('n', C.c_int),
                ('tag', C.POINTER(C.c_int)),
                ('c', C.POINTER(DPoint * 3))]

class Path(C.Structure):
    pass

Path._fields_ = [('area', C.c_int), ('sign', C.c_int), ('curve', Curve),
                 ('next', C.POINTER(Path)), ('childlist', C.POINTER(Path)),
                 ('sibling', C.POINTER(Path)), ('priv', C.c_void_p)]

class Bitmap(C.Structure):
    _fields_ = [('w', C.c_int), ('h', C.c_int), ('dy', C.c_int),
                ('map', C.POINTER(C.c_ulong))]

class State(C.Structure):
    _fields_ = [('status', C.c_int), ('plist', C.POINTER(Path)),
                ('priv', C.c_void_p)]

lib.potrace_param_default.restype = C.c_void_p
lib.potrace_trace.restype = C.POINTER(State)
lib.potrace_trace.argtypes = [C.c_void_p, C.POINTER(Bitmap)]

CURVETO, CORNER = 1, 2
WORDBITS = 64


def trace_mask(mask):
    """mask: bool array (h, w) → Liste von (sign, polygon[(x,y)…]) in Bildkoordinaten."""
    h, w = mask.shape
    dy = (w + WORDBITS - 1) // WORDBITS
    words = np.zeros((h, dy), dtype=np.uint64)
    ys, xs = np.nonzero(mask)
    # potrace: Zeile 0 = unten
    yy = h - 1 - ys
    bitpos = (WORDBITS - 1 - (xs % WORDBITS)).astype(np.uint64)
    np.bitwise_or.at(words, (yy, xs // WORDBITS), np.uint64(1) << bitpos)
    buf = words.tobytes()
    arr = (C.c_ulong * (h * dy)).from_buffer_copy(buf)
    bm = Bitmap(w, h, dy, C.cast(arr, C.POINTER(C.c_ulong)))
    param = lib.potrace_param_default()
    st = lib.potrace_trace(param, C.byref(bm))
    assert st.contents.status == 0
    out = []
    p = st.contents.plist
    while p:
        cur = p.contents.curve
        n = cur.n
        pts = []
        start = cur.c[n - 1][2]
        cx, cy = start.x, start.y
        pts.append((cx, h - cy))
        for i in range(n):
            seg = cur.c[i]
            if cur.tag[i] == CORNER:
                for q in (seg[1], seg[2]):
                    pts.append((q.x, h - q.y))
                cx, cy = seg[2].x, seg[2].y
            else:  # CURVETO: kubische Bezier von (cx,cy) über c0,c1 nach c2
                p0 = (cx, cy)
                p1, p2, p3 = (seg[0].x, seg[0].y), (seg[1].x, seg[1].y), (seg[2].x, seg[2].y)
                for t in np.linspace(0, 1, 18)[1:]:
                    mt = 1 - t
                    bx = mt**3 * p0[0] + 3 * mt**2 * t * p1[0] + 3 * mt * t**2 * p2[0] + t**3 * p3[0]
                    by = mt**3 * p0[1] + 3 * mt**2 * t * p1[1] + 3 * mt * t**2 * p2[1] + t**3 * p3[1]
                    pts.append((bx, h - by))
                cx, cy = p3
            # Vorzeichen: '+' = Fläche, '-' = Loch
        out.append((chr(p.contents.sign), pts))
        p = p.contents.next
    return out


def render_layer(paths, w, h, scale, ss=4):
    """Pfade bei scale×ss rastern (Supersampling), auf scale verkleinern → Alpha-L."""
    big = Image.new('L', (w * scale * ss, h * scale * ss), 0)
    d = ImageDraw.Draw(big)
    f = scale * ss
    for sign, pts in paths:
        poly = [(x * f, y * f) for x, y in pts]
        d.polygon(poly, fill=255 if sign == '+' else 0)
    return big.resize((w * scale, h * scale), Image.LANCZOS)


def main():
    im = Image.open('/home/claude/kentaur_only_alpha.png').convert('RGBA')
    a = np.array(im).astype(int)
    alpha, r, b = a[..., 3], a[..., 0], a[..., 2]
    solid = alpha > 110           # Kern der Striche (Halbtransparenz = Kantenglanz)
    red_m = solid & (r > b + 15)
    blue_m = solid & ~red_m
    core = alpha > 200
    def col(mask):
        m = mask & core
        if m.sum() < 50: m = mask
        return tuple(int(np.median(a[..., i][m])) for i in range(3))
    col_r, col_b = col(red_m), col(blue_m)
    h, w = alpha.shape
    SCALE = 8
    layers = []
    for mask, color in [(blue_m, col_b), (red_m, col_r)]:
        paths = trace_mask(mask)
        lay = render_layer(paths, w, h, SCALE)
        layers.append((color, np.array(lay)))
        print(f'Ebene {color}: {len(paths)} Pfade')
    out = np.zeros((h * SCALE, w * SCALE, 4), dtype=np.uint8)
    for color, lay in layers:
        l = lay / 255.0
        for i in range(3):
            out[..., i] = (out[..., i] * (1 - l) + color[i] * l).astype(np.uint8)
        out[..., 3] = np.maximum(out[..., 3], lay)
    res = Image.fromarray(out, 'RGBA')
    res.save('/home/claude/kentaur_vec.png')
    print(f'✅ kentaur_vec.png {res.size[0]}×{res.size[1]}')


if __name__ == '__main__':
    main()
