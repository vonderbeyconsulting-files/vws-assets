# -*- coding: utf-8 -*-
"""VWS Workbook Master — Erweiterungs-Modul (Werkstätten, Tests, Programm, Profile)"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white
from reportlab.platypus import (Paragraph, Spacer, PageBreak, HRFlowable,
                                Table, TableStyle, KeepTogether)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT

CR  = HexColor('#8E1429'); SL = HexColor('#5F7FA8'); WW = HexColor('#F0EEE8')
NV  = HexColor('#1A2744'); GD = HexColor('#C0A84A'); CH = HexColor('#3A3A3A')
DG  = HexColor('#888888'); RU = HexColor('#D8D3CB'); CB = HexColor('#EBF0F5')
CW  = HexColor('#FAF7EE')
W, H = A4
ML=3.2*cm; MR=3.2*cm
TW = W - ML - MR

# ── BASIS-HELFER ──────────────────────────────────────────────────────────────
def rule(w='100%', thick=0.4, col=RU, before=6, after=10, align='CENTER'):
    return HRFlowable(width=w, thickness=thick, color=col,
                      spaceBefore=before, spaceAfter=after, hAlign=align)

def lines(n=6, width='100%', gap=26):
    out = []
    for _ in range(n):
        out.append(HRFlowable(width=width, thickness=0.35, color=RU,
                              spaceBefore=gap, spaceAfter=0))
    out.append(Spacer(1, 8))
    return out

def part_page(roman, title, sub, body, s):
    """Teil-Trennerseite"""
    return [
        Spacer(1, 4.2*cm),
        Paragraph('TEIL ' + roman, ParagraphStyle('pt_num', fontName='Lora',
            fontSize=13, textColor=GD, alignment=TA_CENTER,
            spaceAfter=10, tracking=3)),
        Paragraph(title, ParagraphStyle('pt_title', fontName='Lora',
            fontSize=30, leading=38, textColor=NV, alignment=TA_CENTER,
            spaceAfter=6)),
        rule('16%', 2.2, CR, 10, 18),
        Paragraph(sub, ParagraphStyle('pt_sub', fontName='Lora-It',
            fontSize=13, leading=20, textColor=SL, alignment=TA_CENTER,
            spaceAfter=22)),
        Paragraph(body, ParagraphStyle('pt_body', fontName='Lora',
            fontSize=10.5, leading=17.5, textColor=CH, alignment=TA_CENTER,
            leftIndent=34, rightIndent=34)),
        PageBreak(),
    ]

def ws_head(kicker, title, intro, s):
    """Werkstatt-Kopf"""
    return [
        Spacer(1, 0.3*cm),
        Paragraph(kicker, s['kap_num']),
        Paragraph(title, ParagraphStyle('ws_t', fontName='Lora', fontSize=21,
            leading=27, textColor=NV, spaceAfter=4)),
        rule('14%', 2, CR, 10, 14, align='LEFT'),
        Paragraph(intro, s['body']),
    ]

def step_label(num, text, s):
    return Paragraph(
        f'<font color="#8E1429"><b>SCHRITT {num}</b></font>&nbsp;&nbsp;{text}',
        ParagraphStyle('step', fontName='Lora', fontSize=10.5, leading=16,
                       textColor=NV, spaceBefore=14, spaceAfter=6))

def hint(text, s):
    return Paragraph('💡 ' + text, ParagraphStyle('hint', fontName='Lora-It',
        fontSize=9.5, leading=15, textColor=SL, spaceBefore=4, spaceAfter=10,
        leftIndent=10))

def writing_page(title, prompt, n_lines, s, kicker='SCHREIBRAUM'):
    """Eine volle Schreibseite"""
    out = [
        Spacer(1, 0.2*cm),
        Paragraph(kicker, ParagraphStyle('wp_k', fontName='Lora', fontSize=8.5,
            textColor=GD, spaceAfter=4, tracking=2)),
        Paragraph(title, ParagraphStyle('wp_t', fontName='Lora', fontSize=15,
            leading=20, textColor=NV, spaceAfter=6)),
        Paragraph(prompt, ParagraphStyle('wp_p', fontName='Lora-It',
            fontSize=10, leading=16, textColor=CH, spaceAfter=10)),
    ]
    out += lines(n_lines)
    out.append(PageBreak())
    return out

def checkbox(text, s, indent=0):
    return Paragraph('☐&nbsp;&nbsp;' + text,
        ParagraphStyle('cb', fontName='Lora', fontSize=10, leading=18,
                       textColor=CH, leftIndent=indent, spaceAfter=5))

# ── SELBSTTEST-BAUSTEINE ─────────────────────────────────────────────────────
def scale_header(s):
    t = Table([[Paragraph('<font color="#888888" size="8">1 = trifft gar nicht zu'
                          ' &nbsp;·&nbsp; 3 = teils-teils &nbsp;·&nbsp; '
                          '5 = trifft voll zu</font>',
                ParagraphStyle('sh', fontName='Lora', fontSize=8))]],
              colWidths=[TW])
    t.setStyle(TableStyle([('BOTTOMPADDING',(0,0),(-1,-1),8),
                           ('LEFTPADDING',(0,0),(-1,-1),0)]))
    return t

def test_item(num, text, s):
    circles = Paragraph(
        '<font color="#5F7FA8">①&nbsp;&nbsp;②&nbsp;&nbsp;③&nbsp;&nbsp;④&nbsp;&nbsp;⑤</font>',
        ParagraphStyle('ti_c', fontName='DejaVu', fontSize=11, alignment=TA_RIGHT))
    q = Paragraph(f'<font color="#8E1429"><b>{num:02d}</b></font>&nbsp;&nbsp;{text}',
        ParagraphStyle('ti_q', fontName='Lora', fontSize=9.8, leading=14.5,
                       textColor=CH))
    t = Table([[q, circles]], colWidths=[TW-118, 118])
    t.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('LEFTPADDING',(0,0),(-1,-1),0),
        ('RIGHTPADDING',(0,0),(-1,-1),0),
        ('TOPPADDING',(0,0),(-1,-1),5),
        ('BOTTOMPADDING',(0,0),(-1,-1),5),
        ('LINEBELOW',(0,0),(-1,-1),0.3,RU),
    ]))
    return t

def score_table(rows, s):
    """rows: list of (range_label, headline, text)"""
    data = []
    for rng, head, txt in rows:
        data.append([
            Paragraph(f'<b>{rng}</b>', ParagraphStyle('sc_r', fontName='Lora',
                fontSize=10, textColor=CR)),
            [Paragraph(head, ParagraphStyle('sc_h', fontName='Lora', fontSize=10,
                textColor=NV, spaceAfter=2)),
             Paragraph(txt, ParagraphStyle('sc_t', fontName='Lora', fontSize=9.3,
                leading=13.5, textColor=CH))]
        ])
    t = Table(data, colWidths=[78, TW-78])
    t.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8),
        ('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),9),
        ('BOTTOMPADDING',(0,0),(-1,-1),9),
        ('BACKGROUND',(0,0),(-1,-1),CW),
        ('LINEBELOW',(0,0),(-1,-2),0.4,white),
    ]))
    return t

def selftest(kicker, title, intro, items, eval_title, eval_rows, s,
             items_per_page=9):
    """Kompletter Selbsttest mit Auswertung"""
    out = ws_head(kicker, title, intro, s)
    out.append(Spacer(1, 6))
    out.append(scale_header(s))
    for i, item in enumerate(items, 1):
        out.append(test_item(i, item, s))
        if i % items_per_page == 0 and i < len(items):
            out.append(PageBreak())
            out.append(Spacer(1, 0.3*cm))
    out.append(Spacer(1, 14))
    out.append(Paragraph('AUSWERTUNG', ParagraphStyle('ev_k', fontName='Lora',
        fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
    out.append(Paragraph(eval_title, ParagraphStyle('ev_t', fontName='Lora',
        fontSize=13, textColor=NV, spaceAfter=4)))
    out.append(Paragraph('Zähle deine Punkte zusammen (Frage 1–'
        f'{len(items)}, je 1–5 Punkte). Trage die Summe ein:',
        ParagraphStyle('ev_i', fontName='Lora', fontSize=9.8, leading=15,
                       textColor=CH, spaceAfter=8)))
    sumline = Table([[Paragraph('Meine Punktzahl:', ParagraphStyle('ev_s',
        fontName='Lora', fontSize=10, textColor=NV)),
        HRFlowable(width='80%', thickness=0.4, color=RU, spaceBefore=12)]],
        colWidths=[110, 130])
    sumline.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'BOTTOM'),
        ('LEFTPADDING',(0,0),(-1,-1),0), ('BOTTOMPADDING',(0,0),(-1,-1),14)]))
    out.append(sumline)
    out.append(score_table(eval_rows, s))
    out.append(PageBreak())
    return out

# ══════════════════════════════════════════════════════════════════════════════
# INHALTE
# ══════════════════════════════════════════════════════════════════════════════

def howto_pages(s):
    """Wie du mit diesem Buch arbeitest + Programm-Übersicht"""
    out = [
        Spacer(1, 0.4*cm),
        Paragraph('BEVOR DU BEGINNST', s['kap_num']),
        Paragraph('Wie du mit diesem Buch arbeitest', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 18),
        Paragraph('Dieses Workbook ist kein Buch zum Durchlesen. '
                  'Es ist ein Arbeitsraum. Du wirst schreiben, streichen, '
                  'zweifeln, neu ansetzen. Genau so soll es sein. '
                  'Eine Erkenntnis, die du selbst aufgeschrieben hast, '
                  'wiegt mehr als zehn, die du nur gelesen hast.', s['body']),
        Paragraph('<b>Drei Wege durch dieses Buch:</b>', s['body']),
    ]
    ways = [
        ('Der Kapitelweg', 'Du arbeitest die neun Kapitel der Reihe nach durch — '
         'mit allen Übungen und Werkstätten. Rechne mit vier bis sechs Wochen, '
         'wenn du dir pro Woche zwei feste Termine mit dir selbst gibst.'),
        ('Das 6-Wochen-Programm', 'Im hinteren Teil findest du ein strukturiertes '
         'Programm mit Wochenfokus, Tages-Check-ins und Wochenreview. '
         'Es führt dich durch alle Themen — mit klarem Rhythmus.'),
        ('Der Werkzeugweg', 'Du steigst dort ein, wo es brennt: Vision unklar? '
         'Teil II. Werte in Konflikt? Teil III. Zu viele Baustellen? '
         'Teil IV. Jeder Teil funktioniert auch für sich.'),
    ]
    for t_, x_ in ways:
        out.append(Paragraph(f'<font color="#8E1429"><b>{t_}</b></font> — {x_}',
            ParagraphStyle('way', fontName='Lora', fontSize=10.3, leading=15.5,
                           textColor=CH, spaceAfter=7, leftIndent=6)))
    out += [
        Spacer(1, 3),
        Paragraph('<b>Vier Regeln, die ich dir ans Herz lege:</b>', s['body']),
    ]
    rules_ = [
        'Schreibe mit der Hand. Was die Hand schreibt, denkt der Kopf gründlicher.',
        'Antworte ehrlich, nicht vorzeigbar. Dieses Buch liest niemand außer dir.',
        'Wenn eine Frage unangenehm ist, ist sie wahrscheinlich die richtige.',
        'Kein Perfektionismus. Eine ehrliche halbe Antwort schlägt eine polierte ganze.',
    ]
    for r_ in rules_:
        out.append(checkbox(r_, s))
    out += [
        Spacer(1, 6),
        Paragraph('Gemeinsam gestalten wir deine Zukunft.', ParagraphStyle('motto',
            fontName='Lora-It', fontSize=11, textColor=CR, spaceAfter=2)),
        Paragraph('<i>Werner</i>', s['small']),
        PageBreak(),
    ]

    # Programm-Übersicht
    out += [
        Spacer(1, 0.2*cm),
        Paragraph('DEIN FAHRPLAN', s['kap_num']),
        Paragraph('Das 6-Wochen-Programm im Überblick', s['sect_hero']),
        rule('20%', 2.5, CR, 4, 10),
        Paragraph('Wenn du den strukturierten Weg wählst: So ist er aufgebaut. '
                  'Jede Woche hat einen Fokus, drei Kernaufgaben und ein '
                  'Wochenreview. Die Arbeitsbögen dazu findest du in Teil VII.',
                  s['body']),
    ]
    weeks = [
        ('1', 'Fundament', 'Standortbestimmung. Identität und Rollen trennen. '
         'Selbsttest: Wo stehst du wirklich?', 'Kapitel 1–2'),
        ('2', 'Vision', 'Deinen Zustand in drei Jahren beschreiben — als wäre er '
         'schon Wirklichkeit. Visions-Werkstatt durcharbeiten.', 'Kapitel 3 + Teil II'),
        ('3', 'Werte', 'Deine drei bis sechs Kernwerte finden — die echten, '
         'nicht die vorzeigbaren. Konflikte und Schattenseiten benennen.', 'Kapitel 4 + Teil III'),
        ('4', 'Strategie', 'Aus der Vision drei strategische Ziele ableiten. '
         'Verzicht üben: Was machst du bewusst nicht?', 'Kapitel 5 + Teil IV'),
        ('5', 'Energie & Umsetzung', 'Energiequellen und -fresser bilanzieren. '
         'Aufgabenblöcke und Eisenhower-Sortierung.', 'Kapitel 6 + 8'),
        ('6', 'Wirkung & Dranbleiben', 'Dein Vermächtnis-Satz. Rituale festlegen. '
         '90-Tage-Plan schreiben. Das Ritual am Buchende.', 'Kapitel 7 + 9 + Teil VIII'),
    ]
    data = []
    for n_, f_, t_, k_ in weeks:
        data.append([
            Paragraph(f'<b>W{n_}</b>', ParagraphStyle('wk_n', fontName='Lora',
                fontSize=12, textColor=white, alignment=TA_CENTER)),
            [Paragraph(f_, ParagraphStyle('wk_f', fontName='Lora', fontSize=10.5,
                textColor=NV, spaceAfter=2)),
             Paragraph(t_, ParagraphStyle('wk_t', fontName='Lora', fontSize=9,
                leading=13, textColor=CH)),
             Paragraph(k_, ParagraphStyle('wk_k', fontName='Lora-It', fontSize=8.3,
                textColor=SL, spaceBefore=2))]
        ])
    t = Table(data, colWidths=[44, TW-44])
    t.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'TOP'),
        ('BACKGROUND',(0,0),(0,-1),NV),
        ('TOPPADDING',(0,0),(-1,-1),4),
        ('BOTTOMPADDING',(0,0),(-1,-1),4),
        ('LEFTPADDING',(1,0),(1,-1),12),
        ('LINEBELOW',(0,0),(-1,-2),1.2,white),
    ]))
    out.append(t)
    out.append(PageBreak())
    return out


def selftest_fundament(s):
    items = [
        'Ich kann in einem Satz sagen, wer ich bin — ohne meinen Beruf zu nennen.',
        'Meine wichtigsten Entscheidungen der letzten Jahre habe ich aktiv getroffen, nicht erlitten.',
        'Ich weiß, welche Erwartungen anderer mein Leben gerade prägen.',
        'Ich kann meine Rollen (Beruf, Familie, Freundeskreis) von meiner Person unterscheiden.',
        'Wenn ich morgens aufwache, weiß ich, wofür ich aufstehe — über die Pflicht hinaus.',
        'Ich treffe Entscheidungen auch dann, wenn sie jemanden enttäuschen.',
        'Ich weiß, was mir Energie gibt — und richte meinen Alltag danach aus.',
        'Ich erkenne meine wiederkehrenden Denkmuster, wenn sie mich blockieren.',
        'Ich kann Nein sagen, ohne mich tagelang zu rechtfertigen.',
        'Ich habe in den letzten zwölf Monaten etwas getan, das mich wirklich gefordert hat.',
        'Ich spreche über meine Ziele so konkret, dass andere sie sofort verstehen.',
        'Wenn ich auf die letzten fünf Jahre schaue, erkenne ich eine Richtung — keine Zufälle.',
    ]
    eval_rows = [
        ('12–27', 'Du funktionierst — aber wer steuert?',
         'Vieles in deinem Leben läuft nach fremden Plänen. Das ist kein Vorwurf: '
         'Die meisten Menschen haben nie entschieden, wer sie sind. Dieses Buch '
         'ist für dich kein Feinschliff, sondern eine Grundsanierung. Nimm dir Zeit '
         'für Teil I und II — dort liegen deine größten Hebel.'),
        ('28–44', 'Das Fundament steht — die Richtung fehlt.',
         'Du kennst dich besser als die meisten. Aber zwischen Selbstkenntnis und '
         'gelebter Richtung klafft eine Lücke. Deine Arbeit liegt in der Übersetzung: '
         'aus Erkenntnis Entscheidung machen. Die Werkstätten in Teil II bis IV '
         'sind dein Kernprogramm.'),
        ('45–60', 'Du bist weiter als die meisten — jetzt wird es anspruchsvoll.',
         'Selbstkenntnis ist da, Richtung auch. Deine Gefahr heißt Komfortzone in '
         'schönen Worten. Arbeite besonders an den Schattenseiten-Übungen und am '
         'Verzicht in Teil IV: Was machst du bewusst nicht mehr? Dort wächst du.'),
    ]
    return selftest('SELBSTTEST · TEIL I', 'Wo stehst du wirklich?',
        'Zwölf Aussagen. Bewerte ehrlich, nicht vorzeigbar — dieses Buch liest '
        'niemand außer dir. Es gibt kein gutes oder schlechtes Ergebnis. '
        'Es gibt nur einen ehrlichen Startpunkt.',
        items, 'Dein Startpunkt', eval_rows, s)


def selftest_vision(s):
    items = [
        'Ich kann meine Vision in drei Sätzen sagen — ohne nachzudenken.',
        'Meine Vision beschreibt einen Zustand, nicht einen Plan oder Prozess.',
        'Meine Vision steht in der Gegenwartsform: „Ich bin“, nicht „Ich will sein“.',
        'Wer meine Vision hört, versteht sie sofort — ohne Nachfragen.',
        'Meine Vision beschreibt, wie ich als Mensch wirke — nicht nur, was ich tue.',
        'Meine Vision würde auch dann gelten, wenn ich morgen den Beruf wechsle.',
        'Meine Vision hilft mir bei konkreten Entscheidungen, Nein zu sagen.',
        'Wenn ich meine Vision lese, spüre ich etwas — sie lässt mich nicht kalt.',
        'Meine Vision ist unverwechselbar meine — sie könnte in keinem anderen Leben stehen.',
        'Ich habe meine Vision in den letzten Wochen mindestens einmal gelesen oder gedacht.',
        'Meine Vision ist groß genug, um unbequem zu sein.',
        'Ich könnte meine Vision laut aussprechen, vor Menschen, die mich kennen.',
    ]
    eval_rows = [
        ('12–27', 'Du hast Wünsche — noch keine Vision.',
         'Das ist der ehrlichste Startpunkt, den es gibt. Die meisten verwechseln '
         'Vision mit Karriereplan. Arbeite die Visions-Werkstatt komplett durch — '
         'besonders Schritt 1 und 2. Eine Vision entsteht nicht am Schreibtisch '
         'in einer Stunde. Gib ihr eine Woche.'),
        ('28–44', 'Eine Vision ist da — sie trägt nur noch nicht.',
         'Du hast eine Richtung formuliert, aber sie ist noch zu glatt, zu '
         'austauschbar oder zu sehr Plan. Konzentriere dich auf zwei Fragen: '
         'Beschreibt sie einen Zustand? Und ist sie unverwechselbar deine? '
         'Die Werkstatt-Schritte 3 und 4 schärfen genau das.'),
        ('45–60', 'Deine Vision steht — jetzt muss sie arbeiten.',
         'Eine starke Vision, die in der Schublade liegt, ist Dekoration. '
         'Deine Aufgabe heißt Integration: Vision als Entscheidungsfilter im '
         'Alltag nutzen. Teil IV (Strategie) und das 6-Wochen-Programm machen '
         'aus deinem Kompass ein Navigationssystem.'),
    ]
    return selftest('SELBSTTEST · TEIL II', 'Wie tragfähig ist deine Vision?',
        'Falls du schon eine Vision hast — oder einen Entwurf — prüfe ihn mit '
        'diesen zwölf Aussagen. Falls noch nicht: Überspringe den Test und komm '
        'nach der Werkstatt hierher zurück. Der Vergleich lohnt sich.',
        items, 'Die Tragfähigkeit deiner Vision', eval_rows, s)


def selftest_werte(s):
    items = [
        'Ich kann meine drei wichtigsten Werte nennen — sofort, ohne Liste.',
        'Meine Werte zeigen sich in meinem Kalender — nicht nur in meinen Worten.',
        'Ich habe in den letzten drei Monaten eine unbequeme Entscheidung getroffen, weil ein Wert es verlangte.',
        'Ich weiß, welcher meiner Werte unter Druck als erster fällt.',
        'Ich kenne die Schattenseite meiner wichtigsten Werte.',
        'Meine Werte sind meine eigenen — nicht die meiner Eltern, meines Umfelds oder meiner Branche.',
        'Ich erkenne, wenn zwei meiner Werte in Konflikt geraten — und kann den Konflikt benennen.',
        'Menschen, die mich gut kennen, würden mir dieselben Werte zuschreiben, die ich mir selbst gebe.',
        'Ich habe schon einmal etwas Attraktives abgelehnt, weil es einem Wert widersprach.',
        'Meine Werte helfen mir in Konflikten, klar zu bleiben statt es allen recht zu machen.',
        'Ich überprüfe gelegentlich, ob meine Werte noch stimmen — oder nur noch Gewohnheit sind.',
        'Ich könnte zu jedem meiner Werte eine konkrete Situation der letzten Wochen erzählen.',
    ]
    eval_rows = [
        ('12–27', 'Du trägst Werte — aber sind es deine?',
         'Vermutlich lebst du nach Werten, die du nie bewusst gewählt hast: '
         'übernommen, angelernt, erwartet. Die Werte-Werkstatt trennt für dich '
         'gelebte von genannten Werten. Sei dabei besonders ehrlich bei der '
         'Frage: Wann hat dieser Wert mich zuletzt etwas gekostet?'),
        ('28–44', 'Deine Werte sind dir bekannt — aber noch nicht souverän.',
         'Du kennst deine Werte, aber unter Druck verrutschen sie. Das ist '
         'menschlich — und veränderbar. Arbeite an der Konflikt-Matrix und der '
         'Frage, welcher Wert das letzte Wort hat. Emotionale Souveränität '
         'beginnt genau dort.'),
        ('45–60', 'Werte-Klarheit auf hohem Niveau — prüfe die Schattenseiten.',
         'Du lebst deine Werte. Die Gefahr auf diesem Niveau: Werte werden zu '
         'Dogmen. Loyalität wird Unterwerfung, Exzellenz wird Perfektionismus. '
         'Die Schattenseiten-Übung ist für dich keine Pflichtübung, sondern '
         'das eigentliche Programm.'),
    ]
    return selftest('SELBSTTEST · TEIL III', 'Wie klar sind deine Werte?',
        'Werte, die man nennt, und Werte, die man lebt, sind oft verschieden. '
        'Diese zwölf Aussagen messen die Lücke. Bewerte nach gelebtem Alltag '
        'der letzten Monate — nicht nach guten Vorsätzen.',
        items, 'Deine Werte-Klarheit', eval_rows, s)


def selftest_strategie(s):
    items = [
        'Ich habe höchstens drei strategische Ziele — nicht zehn.',
        'Meine Ziele zahlen erkennbar auf meine Vision ein.',
        'Ich kann sagen, was ich bewusst NICHT mache, um meine Ziele zu erreichen.',
        'Jedes meiner Ziele hat einen nächsten konkreten Schritt mit Termin.',
        'Ich unterscheide im Alltag zwischen wichtig und dringend.',
        'Ich arbeite jede Woche an mindestens einem wichtigen, nicht dringenden Thema.',
        'Ich delegiere oder streiche Aufgaben, die nicht auf meine Ziele einzahlen.',
        'Ich überprüfe meine Ziele regelmäßig — mindestens alle 90 Tage.',
        'Rückschläge werfen mich nicht aus der Bahn — ich passe den Weg an, nicht das Ziel.',
        'Ich plane meine Woche, bevor sie mich plant.',
        'Ich kann bei neuen Gelegenheiten schnell entscheiden: Passt das zu meiner Strategie?',
        'Meine Strategie passt zu meiner Energie — sie überfordert mich nicht dauerhaft.',
    ]
    eval_rows = [
        ('12–27', 'Du bist beschäftigt — aber bist du wirksam?',
         'Vermutlich arbeitest du viel und kommst trotzdem nicht voran. Das '
         'liegt selten am Einsatz, fast immer an fehlender Auswahl. Strategie '
         'ist Verzicht. Die Strategie-Werkstatt führt dich von zehn Baustellen '
         'zu drei Zielen. Das fühlt sich erst falsch an — und dann frei.'),
        ('28–44', 'Die Richtung stimmt — der Rhythmus fehlt.',
         'Du hast Ziele, aber sie verlieren im Alltag gegen das Dringende. '
         'Dein Hebel: feste Termine mit dem Wichtigen. Arbeite mit dem '
         'Eisenhower-Bogen und dem 90-Tage-Plan — und verteidige Quadrant II '
         'wie einen Notartermin.'),
        ('45–60', 'Strategisch stark — bleib wachsam bei der Energie.',
         'Du arbeitest fokussiert und ausgerichtet. Auf diesem Niveau kippen '
         'Menschen selten an der Strategie — sie kippen an der Erschöpfung. '
         'Kapitel 8 und das Energie-Protokoll sind deine Versicherung. '
         'Leistung folgt der Regeneration, nicht umgekehrt.'),
    ]
    return selftest('SELBSTTEST · TEIL IV', 'Wie strategisch lebst du?',
        'Strategie heißt nicht, mehr zu schaffen. Strategie heißt, das Richtige '
        'zu wählen — und den Rest bewusst zu lassen. Zwölf Aussagen zu deinem '
        'Ist-Zustand.',
        items, 'Deine strategische Reife', eval_rows, s)

# ══════════════════════════════════════════════════════════════════════════════
# WERKSTÄTTEN
# ══════════════════════════════════════════════════════════════════════════════

def werkstatt_vision(s):
    out = ws_head('WERKSTATT · TEIL II', 'Die Visions-Werkstatt',
        'Hier entsteht deine Vision — in vier Schritten. Nimm dir dafür nicht '
        'eine Stunde, sondern eine Woche. Eine Vision, die trägt, braucht Zeit '
        'zum Setzen. Du wirst mehrfach streichen. Genau dafür ist hier Platz.', s)
    out.append(step_label(1, 'Sammeln — ohne Zensur', s))
    out.append(Paragraph('Beantworte die folgenden Fragen schnell und unsortiert. '
        'Stichworte reichen. Es geht um Material, nicht um Formulierung.', s['body']))
    out.append(PageBreak())
    out += writing_page('Was würdest du tun, wenn du nicht scheitern könntest?',
        'Nicht den sicheren Gedanken — den ersten. Schreib ihn auf, bevor der '
        'innere Kritiker aufwacht.', 12, s, 'SCHRITT 1 · SAMMELN')
    out += writing_page('Wann warst du zuletzt ganz bei dir?',
        'Beschreibe zwei oder drei Situationen, in denen du Energie, Klarheit '
        'und Stolz zugleich gespürt hast. Was genau hast du da getan — und wie '
        'hast du gewirkt?', 12, s, 'SCHRITT 1 · SAMMELN')
    out += writing_page('Was hast du als Kind geliebt — bevor jemand sagte, was daraus werden soll?',
        'Tätigkeiten, Orte, Spiele, Themen. Vieles davon trägt einen Kern, '
        'der nie verschwunden ist — nur verschüttet. Sammle, ohne zu bewerten.',
        12, s, 'SCHRITT 1 · SAMMELN')
    out += writing_page('Was sollen Menschen über dich sagen, wenn du den Raum verlassen hast?',
        'Nicht über deine Leistung — über deine Wirkung. Drei Sätze, die du dir '
        'wünschst. Und ein Satz, den du nie wieder hören willst.', 12, s,
        'SCHRITT 1 · SAMMELN')
    out.append(Spacer(1, 0.2*cm))
    out.append(step_label(2, 'Verdichten — den Kern finden', s))
    out.append(Paragraph('Lies alles aus Schritt 1. Unterstreiche die fünf '
        'Wörter oder Wendungen mit der stärksten Ladung — die, bei denen es in '
        'dir reagiert. Trage sie hier ein:', s['body']))
    out += lines(5, '85%')
    out.append(hint('Werners Tipp: Die stärksten Wörter sind selten die '
        'schönsten. Oft sind es die unbequemen.', s))
    out.append(Paragraph('Erkenne das Anliegen dahinter: Nicht was du sagst — '
        'was du meinst. Welcher rote Faden verbindet deine fünf Wörter?', s['body']))
    out += lines(4)
    out.append(PageBreak())
    out.append(step_label(3, 'Formulieren — Zustand statt Prozess', s))
    out.append(Paragraph('Jetzt schreibst du deinen ersten Visionsentwurf. '
        'Die Regeln kennst du aus Kapitel 3 — hier als Checkliste:', s['body']))
    for c_ in ['Gegenwartsform: „Ich bin“ — nicht „Ich will sein“',
               'Ein erreichter Zustand — kein Plan, kein Weg, kein Prozess',
               'Wenige pointierte Sätze — drei bis fünf, nicht zehn',
               'Ein Lebensgefühl und eine Wirkung — kein Berufsbild',
               'Zeitlos: gilt auch noch in 20 Jahren',
               'Sofort verständlich — ohne Nachfragen']:
        out.append(checkbox(c_, s))
    out.append(Spacer(1, 10))
    out.append(Paragraph('<b>Entwurf 1:</b>', s['body']))
    out += lines(6)
    out.append(PageBreak())
    out += writing_page('Entwurf 2 — nach einem Tag Abstand',
        'Lies Entwurf 1 laut. Streiche jedes Wort, das auch in hundert anderen '
        'Visionen stehen könnte. Was bleibt, ist dein Kern. Formuliere neu.',
        8, s, 'SCHRITT 3 · FORMULIEREN')
    out += writing_page('Entwurf 3 — die Fassung, die bleibt',
        'Letzte Prüfung: Würdest du diesen Text laut aussprechen, vor Menschen, '
        'die dich kennen? Wenn ja — schreib ihn hier in Schönschrift. '
        'Das ist deine Vision.', 8, s, 'SCHRITT 3 · FORMULIEREN')
    out.append(step_label(4, 'Prüfen — der Alltagstest', s))
    out.append(Paragraph('Eine Vision ohne Grenze ist kein Kompass. Teste deine '
        'Vision an drei realen Entscheidungen, die gerade anstehen oder kürzlich '
        'anstanden:', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>Entscheidung {i}:</b> Worum geht es?',
            ParagraphStyle('dec', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=12, spaceAfter=4)))
        out += lines(2)
        out.append(Paragraph('Was sagt deine Vision dazu — Ja oder Nein? Und warum?',
            ParagraphStyle('dec2', fontName='Lora-It', fontSize=9.5,
                           textColor=SL, spaceAfter=4)))
        out += lines(2)
    out.append(hint('Wenn deine Vision bei keiner der drei Entscheidungen klar '
        'Nein sagen kann, ist sie noch zu weich. Zurück zu Schritt 3 — '
        'eine Runde mutiger.', s))
    out.append(PageBreak())
    return out


WERTE_LISTE = [
    'Freiheit','Unabhängigkeit','Sicherheit','Stabilität','Nähe','Loyalität',
    'Ehrlichkeit','Integrität','Gerechtigkeit','Fairness','Verantwortung','Verlässlichkeit',
    'Leistung','Exzellenz','Erfolg','Wachstum','Lernen','Neugier',
    'Kreativität','Gestaltung','Innovation','Abenteuer','Mut','Risikobereitschaft',
    'Harmonie','Frieden','Gelassenheit','Achtsamkeit','Gesundheit','Balance',
    'Gemeinschaft','Zugehörigkeit','Freundschaft','Liebe','Mitgefühl','Großzügigkeit',
    'Anerkennung','Status','Einfluss','Macht','Führung','Wirkung',
    'Selbstbestimmung','Authentizität','Klarheit','Disziplin','Struktur','Ordnung',
    'Genuss','Lebensfreude','Humor','Leichtigkeit','Spiritualität','Sinn',
    'Tradition','Beständigkeit','Nachhaltigkeit','Natur','Schönheit','Ästhetik',
]

def werkstatt_werte(s):
    out = ws_head('WERKSTATT · TEIL III', 'Die Werte-Werkstatt',
        'Sechzig Werte stehen auf der nächsten Seite. Am Ende dieser Werkstatt '
        'bleiben drei bis sechs übrig — deine. Nicht die, die gut klingen. '
        'Die, nach denen du tatsächlich entscheidest, wenn es etwas kostet.', s)
    out.append(step_label(1, 'Eingrenzen — von 60 auf 12', s))
    out.append(Paragraph('Kreise spontan alle Werte ein, die dich ansprechen. '
        'Dann streiche so lange, bis höchstens zwölf übrig sind. '
        'Streichen fällt schwer? Gut. Genau das ist die Übung.', s['body']))
    out.append(Spacer(1, 8))
    rows, row = [], []
    for i, w_ in enumerate(WERTE_LISTE, 1):
        row.append(Paragraph(w_, ParagraphStyle('wl', fontName='Lora',
            fontSize=9.5, textColor=CH, alignment=TA_CENTER)))
        if i % 3 == 0:
            rows.append(row); row = []
    t = Table(rows, colWidths=[TW/3]*3)
    t.setStyle(TableStyle([
        ('TOPPADDING',(0,0),(-1,-1),7),
        ('BOTTOMPADDING',(0,0),(-1,-1),7),
        ('GRID',(0,0),(-1,-1),0.3,RU),
        ('BACKGROUND',(0,0),(-1,-1),CW),
    ]))
    out.append(t)
    out.append(PageBreak())
    out.append(step_label(2, 'Verschärfen — von 12 auf 6', s))
    out.append(Paragraph('Stelle jedem deiner zwölf Werte dieselbe Frage: '
        '<b>Wann hat dieser Wert mich zuletzt etwas gekostet?</b> Zeit, Geld, '
        'Bequemlichkeit, Zustimmung. Ein Wert, der nie etwas kostet, ist eine '
        'Vorliebe — kein Wert. Streiche auf sechs.', s['body']))
    out.append(Paragraph('Meine sechs Kandidaten — mit der Situation, in der '
        'sie mich zuletzt etwas gekostet haben:', s['body']))
    for i in range(1, 7):
        out.append(Paragraph(f'<b>{i}.</b> Wert: ____________________  ·  '
            'Was er mich gekostet hat:', ParagraphStyle('wk6',
            fontName='Lora', fontSize=10, textColor=NV, spaceBefore=12,
            spaceAfter=4)))
        out += lines(2)
    out.append(PageBreak())
    out.append(step_label(3, 'Entscheiden — deine 3 bis 6 Kernwerte', s))
    out.append(Paragraph('Letzter Schnitt. Welche Werte bleiben? Trage sie ein '
        'und beschreibe zu jedem: Wie zeigt er sich konkret — und was ist seine '
        'Schattenseite? Jeder Wert hat eine: Loyalität kann Unterwerfung werden, '
        'Exzellenz Perfektionismus, Freiheit Bindungsangst.', s['body']))
    for i in range(1, 7):
        out.append(Paragraph(f'<b>KERNWERT {i}:</b>',
            ParagraphStyle('kw', fontName='Lora', fontSize=10.5, textColor=CR,
                           spaceBefore=14, spaceAfter=4)))
        out.append(Paragraph('So zeigt er sich in meinem Alltag:',
            ParagraphStyle('kw2', fontName='Lora-It', fontSize=9.3, textColor=SL,
                           spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('Seine Schattenseite bei mir:',
            ParagraphStyle('kw3', fontName='Lora-It', fontSize=9.3, textColor=SL,
                           spaceAfter=2)))
        out += lines(2)
        if i in (2, 4):
            out.append(PageBreak())
            out.append(Spacer(1, 0.2*cm))
    out.append(PageBreak())
    out.append(step_label(4, 'Die Konflikt-Matrix', s))
    out.append(Paragraph('Deine Werte ziehen nicht immer in dieselbe Richtung. '
        'Wo geraten zwei davon in echten Konflikt — in konkreten Situationen? '
        'Beispiel: Freiheit will kündigen, Sicherheit will bleiben. '
        'Benenne deine zwei stärksten Spannungen:', s['body']))
    for i in [1, 2]:
        out.append(Paragraph(f'<b>Spannung {i}:</b> '
            '__________________  ⇄  __________________',
            ParagraphStyle('sp', fontName='Lora', fontSize=10.5, textColor=NV,
                           spaceBefore=16, spaceAfter=6)))
        out.append(Paragraph('Die Alltagssituation, in der dieser Konflikt sichtbar wird:',
            ParagraphStyle('sp2', fontName='Lora-It', fontSize=9.3, textColor=SL,
                           spaceAfter=2)))
        out += lines(3)
        out.append(Paragraph('Welcher der beiden hat im Zweifel das letzte Wort — und warum?',
            ParagraphStyle('sp3', fontName='Lora-It', fontSize=9.3, textColor=SL,
                           spaceAfter=2)))
        out += lines(3)
    out.append(hint('Konflikte zwischen Werten löst man nicht auf — man '
        'integriert sie. Wer weiß, welcher Wert wann Vorrang hat, bleibt unter '
        'Druck souverän. Das ist emotionale Souveränität in der Praxis.', s))
    out.append(PageBreak())
    return out


def werkstatt_strategie(s):
    out = ws_head('WERKSTATT · TEIL IV', 'Die Strategie-Werkstatt',
        'Aus deiner Vision werden jetzt drei strategische Ziele — und ein '
        'klares Nein zu allem anderen. Strategie ist Verzicht: Du wirst hier '
        'mehr streichen als schreiben.', s)
    out.append(step_label(1, 'Die Baustellen-Inventur', s))
    out.append(Paragraph('Schreibe alle Ziele, Projekte und Vorhaben auf, die '
        'gerade in deinem Kopf leben. Alle. Auch die halbvergessenen. '
        'Erfahrungsgemäß kommen 8 bis 15 zusammen.', s['body']))
    out += lines(14)
    out.append(PageBreak())
    out.append(step_label(2, 'Der Visions-Filter', s))
    out.append(Paragraph('Lies deine Vision. Gehe dann die Liste durch und '
        'frage bei jedem Punkt: <b>Zahlt das auf meine Vision ein?</b> '
        'Drei Antworten sind erlaubt: JA (markieren), NEIN (streichen), '
        'SPÄTER (in die Klammer unten). Sei hart. Ein halbes Ja ist ein Nein.',
        s['body']))
    out.append(Spacer(1, 6))
    out.append(Paragraph('<b>Die Später-Klammer</b> — gute Ideen, falsche Zeit. '
        'Hier dürfen sie warten, ohne dich zu beschäftigen:', s['body']))
    out += lines(5)
    out.append(Spacer(1, 10))
    out.append(step_label(3, 'Drei strategische Ziele', s))
    out.append(Paragraph('Aus den verbleibenden JAs wählst du drei. Nicht vier. '
        'Formuliere jedes so, dass ein Außenstehender prüfen könnte, ob du es '
        'erreicht hast — konkret, mit Zeithorizont.', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>STRATEGISCHES ZIEL {i}:</b>',
            ParagraphStyle('sz', fontName='Lora', fontSize=10.5, textColor=CR,
                           spaceBefore=12, spaceAfter=4)))
        out += lines(2)
        out.append(Paragraph('So zahlt es auf meine Vision ein:',
            ParagraphStyle('sz2', fontName='Lora-It', fontSize=9.3, textColor=SL,
                           spaceAfter=2)))
        out += lines(2)
    out.append(PageBreak())
    out.append(step_label(4, 'Der Verzichts-Vertrag', s))
    out.append(Paragraph('Der wichtigste Schritt — und der unbequemste. '
        'Was machst du in den nächsten 90 Tagen bewusst NICHT, damit deine drei '
        'Ziele Raum haben? Mindestens drei konkrete Verzichte:', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>Ich verzichte auf:</b>',
            ParagraphStyle('vz', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=12, spaceAfter=4)))
        out += lines(2)
    out.append(hint('Werners Erfahrung: Wer den Verzichts-Vertrag überspringt, '
        'hat in 90 Tagen wieder zehn Baustellen. Häufig sind es nur einige '
        'kleine Hebel — aber sie müssen umgelegt werden.', s))
    out.append(Spacer(1, 8))
    out.append(Paragraph('Datum: ____________  ·  Unterschrift: ____________________',
        ParagraphStyle('vzd', fontName='Lora', fontSize=10, textColor=CH)))
    out.append(PageBreak())

    # Eisenhower vertieft
    out += ws_head('VERTIEFUNG · TEIL IV', 'Eisenhower in der Praxis',
        'Wichtig ist, was auf deine Ziele einzahlt. Dringend ist, was laut ist. '
        'Die Matrix trennt beides — und dein Kalender entscheidet, ob du sie '
        'ernst meinst.', s)
    cell_st = ParagraphStyle('eh_c', fontName='Lora', fontSize=9, leading=13,
                             textColor=CH)
    head_st = ParagraphStyle('eh_h', fontName='Lora', fontSize=9.5,
                             textColor=white, alignment=TA_CENTER)
    q = lambda title, desc: [Paragraph(f'<b>{title}</b>', ParagraphStyle('eh_q',
            fontName='Lora', fontSize=10, textColor=NV, spaceAfter=3)),
        Paragraph(desc, cell_st)]
    data = [
        ['', Paragraph('<b>DRINGEND</b>', head_st), Paragraph('<b>NICHT DRINGEND</b>', head_st)],
        [Paragraph('<b>WICHTIG</b>', ParagraphStyle('eh_l', fontName='Lora',
            fontSize=8, textColor=white, alignment=TA_CENTER)),
         q('I — Sofort selbst', 'Krisen, Fristen, echte Notfälle. '
           'Hier lebst du, wenn du nie planst.'),
         q('II — Einplanen & schützen', 'Vision, Strategie, Beziehungen, '
           'Gesundheit, Lernen. Hier entsteht deine Zukunft. Quadrant II '
           'verteidigst du wie einen Notartermin.')],
        [Paragraph('<b>NICHT<br/>WICHTIG</b>', ParagraphStyle('eh_l2',
            fontName='Lora', fontSize=8, textColor=white, alignment=TA_CENTER)),
         q('III — Delegieren, automatisieren, outsourcen',
           'Fremde Dringlichkeit: viele Mails, Meetings, Unterbrechungen. '
           'Fühlt sich nach Arbeit an, ist aber Lärm.'),
         q('IV — Streichen', 'Zeitfresser ohne Wert. Nicht reduzieren — '
           'streichen.')],
    ]
    t = Table(data, colWidths=[68, (TW-68)/2, (TW-68)/2],
              rowHeights=[24, None, None])
    t.setStyle(TableStyle([
        ('BACKGROUND',(1,0),(-1,0),NV),
        ('BACKGROUND',(0,1),(0,-1),NV),
        ('BACKGROUND',(1,1),(-1,-1),CW),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('VALIGN',(1,1),(-1,-1),'TOP'),
        ('GRID',(0,0),(-1,-1),0.7,white),
        ('TOPPADDING',(1,1),(-1,-1),9),
        ('BOTTOMPADDING',(1,1),(-1,-1),9),
        ('LEFTPADDING',(0,0),(-1,-1),8),
        ('RIGHTPADDING',(0,0),(-1,-1),8),
    ]))
    out.append(t)
    out.append(Spacer(1, 14))
    out.append(Paragraph('<b>Übung — Deine Woche durch die Matrix:</b> '
        'Nimm deine letzte Arbeitswoche und verteile die zehn größten '
        'Zeitblöcke auf die Quadranten:', s['body']))
    out.append(Spacer(1, 4))
    qt = Table([
        [Paragraph('<b>Quadrant I</b>', cell_st), Paragraph('<b>Quadrant II</b>', cell_st)],
        ['\n\n\n\n\n', '\n\n\n\n\n'],
        [Paragraph('<b>Quadrant III</b>', cell_st), Paragraph('<b>Quadrant IV</b>', cell_st)],
        ['\n\n\n\n\n', '\n\n\n\n\n'],
    ], colWidths=[TW/2, TW/2])
    qt.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.4,RU),
        ('TOPPADDING',(0,0),(-1,-1),6),
        ('BOTTOMPADDING',(0,0),(-1,-1),6),
        ('LEFTPADDING',(0,0),(-1,-1),8),
    ]))
    out.append(qt)
    out.append(hint('Ehrliche Bilanz: Wie viel Prozent deiner Woche lebt in '
        'Quadrant II? Unter 20 Prozent heißt: Deine Zukunft bekommt Reste.', s))
    out.append(PageBreak())

    # 90-Tage-Plan
    out += ws_head('WERKZEUG · TEIL IV', 'Dein 90-Tage-Plan',
        'Drei Monate sind der beste Planungshorizont: lang genug für echte '
        'Ergebnisse, kurz genug, um konkret zu bleiben. Pro strategischem Ziel '
        'ein Bogen.', s)
    for zi in range(1, 4):
        if zi > 1:
            out.append(PageBreak())
            out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(f'90-TAGE-BOGEN · ZIEL {zi}',
            ParagraphStyle('p90k', fontName='Lora', fontSize=9, textColor=GD,
                           spaceAfter=4, tracking=2)))
        out.append(Paragraph('Das Ziel in einem Satz:',
            ParagraphStyle('p90a', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=6, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('Woran ich in 90 Tagen den Fortschritt messe:',
            ParagraphStyle('p90b', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=8, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('Die drei wichtigsten Aufgabenblöcke:',
            ParagraphStyle('p90c', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=8, spaceAfter=2)))
        for blk in ['Monat 1:', 'Monat 2:', 'Monat 3:']:
            out.append(Paragraph(blk, ParagraphStyle('p90m', fontName='Lora-It',
                fontSize=9.3, textColor=SL, spaceBefore=8, spaceAfter=2)))
            out += lines(2)
        out.append(Paragraph('Das größte Hindernis — und mein Umgang damit:',
            ParagraphStyle('p90d', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=8, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('Der erste Schritt — mit Datum:',
            ParagraphStyle('p90e', fontName='Lora', fontSize=10, textColor=CR,
                           spaceBefore=8, spaceAfter=2)))
        out += lines(2)
    out.append(PageBreak())
    return out


def werkstatt_energie(s):
    out = ws_head('WERKZEUG · TEIL V', 'Das Energie-Protokoll',
        'Eine Woche lang beobachtest du, was dich trägt und was dich kostet. '
        'Keine Veränderung — nur Beobachtung. Die Veränderung kommt von allein, '
        'sobald du die Muster siehst.', s)
    cell = ParagraphStyle('en_c', fontName='Lora', fontSize=8.5, textColor=CH)
    head = ParagraphStyle('en_h', fontName='Lora', fontSize=8.5, textColor=white,
                          alignment=TA_CENTER)
    for half in [(1, 4), (5, 8)]:
        data = [[Paragraph('<b>Tag</b>', head),
                 Paragraph('<b>Was mir heute Energie gegeben hat</b>', head),
                 Paragraph('<b>Was mich Energie gekostet hat</b>', head),
                 Paragraph('<b>Level<br/>1–10</b>', head)]]
        days = ['Mo','Di','Mi','Do','Fr','Sa','So']
        rng = days[:4] if half[0] == 1 else days[4:]
        for d_ in rng:
            data.append([Paragraph(f'<b>{d_}</b>', cell), '\n\n\n\n', '\n\n\n\n', ''])
        t = Table(data, colWidths=[34, (TW-84)/2, (TW-84)/2, 50])
        t.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),NV),
            ('GRID',(0,0),(-1,-1),0.4,RU),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
            ('TOPPADDING',(0,0),(-1,-1),6),
            ('BOTTOMPADDING',(0,0),(-1,-1),6),
            ('LEFTPADDING',(0,0),(-1,-1),6),
        ]))
        out.append(t)
        if half[0] == 1:
            out.append(PageBreak())
            out.append(Spacer(1, 0.3*cm))
    out.append(Spacer(1, 12))
    out.append(Paragraph('<b>Bilanz nach sieben Tagen:</b> Welche drei Quellen '
        'tauchen immer wieder auf? Welche zwei Kostenstellen kannst du '
        'reduzieren, delegieren oder streichen?', s['body']))
    out += lines(6)
    out.append(PageBreak())
    return out

# ══════════════════════════════════════════════════════════════════════════════
# BERUFSPROFILE — 4 komplett durchgespielte Beispiele
# ══════════════════════════════════════════════════════════════════════════════

PROFILE = [
    dict(
        name='Julia, 34 — Rechtsanwältin auf dem Weg in die eigene Kanzlei',
        situation='Acht Jahre Großkanzlei. Fachlich exzellent, innerlich leer. '
            'Julia merkt: Sie verteidigt Verträge, aber nicht mehr ihre eigene '
            'Zeit. Der Gedanke an die eigene Kanzlei ist seit drei Jahren da — '
            'und seit drei Jahren aufgeschoben.',
        vision='Ich bin Anwältin mit eigener Kanzlei — Menschen kommen zu mir, '
            'weil ich zuhöre, bevor ich berate. Ich arbeite an Fällen, die ich '
            'selbst gewählt habe, in einem Tempo, das ich selbst bestimme. '
            'Meine Mandanten verlassen mein Büro klüger, als sie gekommen sind.',
        vision_note='Beachte: kein Wort über Umsatz oder Kanzleigröße. Die '
            'Vision beschreibt Wirkung und Lebensgefühl — die Zahlen kommen in '
            'die Strategie.',
        werte=[('Selbstbestimmung', 'hat sie acht Jahre gegen Sicherheit '
                'eingetauscht — jetzt kehrt sie die Gewichtung um'),
               ('Verlässlichkeit', 'ihr Anker gegenüber Mandanten — und ihre '
                'Schattenseite: Sie sagt zu selten Nein'),
               ('Klarheit', 'in der Beratung ihre Stärke, sich selbst gegenüber '
                'lange ihr blinder Fleck')],
        konflikt='Selbstbestimmung gegen Verlässlichkeit: Als Einzelanwältin kann Julia nicht '
            'mehr jedes Mandat annehmen — und jede Absage fühlt sich an, als ließe sie '
            'jemanden im Stich. Ihre Lösung: Verlässlichkeit gilt den Mandaten, die sie '
            'annimmt — nicht jeder Anfrage. Wer alles annimmt, ist am Ende für niemanden verlässlich.',
        ziele=['In 12 Monaten Kanzlei gegründet mit fünf zahlenden '
               'Stamm-Mandanten', 'Spezialisierung auf Arbeitsrecht für '
               'Gründer:innen aufgebaut und sichtbar gemacht',
               'Finanzpuffer für sechs Monate angespart — vor der Kündigung'],
        verzicht='Kein zweites Fachgebiet im ersten Jahr. Keine Pro-bono-Mandate, '
            'bis die Basis steht. Kein Perfektionieren der Website über '
            'Version 1 hinaus.',
        schritt='Ein Freitag, fest im Kalender geblockt: Kanzleisoftware '
            'einrichten und die ersten drei Wunschmandanten anschreiben. Drei '
            'Wochen später stellt Julia ihre erste Honorarrechnung — 1.840 €. '
            'Klein, konkret, terminiert — so beginnen Kanzleien.'
    ),
    dict(
        name='Marc, 43 — Gründer zwischen Wachstum und Erschöpfung',
        situation='Sein Software-Unternehmen läuft: zwölf Mitarbeitende, '
            'stabile Kunden. Aber Marc arbeitet 70 Stunden, entscheidet alles '
            'selbst und merkt, dass er zum Engpass seiner eigenen Firma '
            'geworden ist. Das Wachstum stagniert — nicht am Markt, an ihm.',
        vision='Ich bin Unternehmer, kein Dauerläufer. Mein Unternehmen wächst, '
            'weil ich Menschen wachsen lasse. Ich arbeite am Unternehmen, '
            'nicht im Unternehmen — und bin abends ein Vater mit Energie, '
            'nicht ein Gründer mit Restakku.',
        vision_note='Marcs erster Entwurf lautete „Ich will eine Firma mit 50 '
            'Mitarbeitern“. Eine Zahl ist ein Ziel — kein Lebensgefühl. Die '
            'finale Fassung beschreibt, wer er als Unternehmer ist.',
        werte=[('Gestaltung', 'sein Antrieb seit der Gründung — er verwechselte '
                'sie lange mit Kontrolle'),
               ('Verantwortung', 'für sein Team echt gelebt — die Schattenseite: '
                'Er nimmt anderen Verantwortung weg, statt sie zu geben'),
               ('Nähe', 'gelebt in der Familie — auf jeder Werteliste ganz oben, '
                'im Kalender ganz unten: die ehrlichste Erkenntnis seiner Werte-Werkstatt')],
        konflikt='Gestaltung gegen Nähe: Jedes neue Projekt ist gestohlene '
            'Familienzeit. Marcs Integration: Gestaltung bekommt die Arbeitszeit '
            '— aber die Arbeitszeit bekommt eine harte Grenze. Ab 18 Uhr hat '
            'die Familie das letzte Wort, ohne Diskussion.',
        ziele=['Führungsebene aufgebaut: zwei Bereichsleiter, die ohne ihn '
               'entscheiden', 'Eigene Arbeitszeit in 9 Monaten von 70 auf 45 '
               'Stunden — gemessen, nicht geschätzt',
               'Strategie-Tag pro Woche etabliert: ein Tag ohne operatives '
               'Geschäft'],
        verzicht='Keine Teilnahme mehr an operativen Meetings unter '
            'Bereichsleiter-Ebene. Kein neues Produkt in diesem Jahr. '
            'Keine Kundentermine am Freitag — der gehört der Strategie.',
        schritt='Montag, 9 Uhr: Termin mit beiden Senior-Entwicklern — das '
            'Gespräch über die Bereichsleitung, das er seit vier Monaten '
            'aufschiebt.'
    ),
    dict(
        name='Sandra, 48 — Führungskraft vor der Sinnfrage',
        situation='Bereichsleiterin im Konzern, 120 Mitarbeitende, respektiert '
            'und gut bezahlt. Und doch: Seit der letzten Umstrukturierung fragt '
            'sich Sandra, wofür sie eigentlich führt. Die nächste Beförderung '
            'reizt sie nicht — das erschreckt sie mehr als jede Krise.',
        situation_extra='',
        vision='Ich bin eine Führungskraft, an der sich Menschen aufrichten. '
            'In meinem Bereich trauen sich Leute, Fehler zuzugeben und Neues zu '
            'versuchen. Was ich hinterlasse, sind keine Organigramme — es sind '
            'Menschen, die führen können, weil ich sie habe wachsen lassen.',
        vision_note='Sandras Wendepunkt: Die Erkenntnis, dass ihre Vision keine '
            'neue Position braucht. Sie beschreibt eine Art zu führen — auf '
            'jeder Ebene gültig. Manchmal ist die Vision kein Aufbruch, '
            'sondern eine Vertiefung.',
        werte=[('Wirkung', 'lange mit Aufstieg verwechselt — tatsächlich meint '
                'sie: Spuren in Menschen'),
               ('Ehrlichkeit', 'ihr Ruf im Unternehmen — die Schattenseite: '
                'Härte, wenn die Dosis nicht stimmt'),
               ('Lernen', 'ihr stiller Motor — verkümmert in Routine-Meetings, '
                'lebendig in jedem Mentoring')],
        konflikt='Ehrlichkeit gegen Wirkung: Die ungefilterte Wahrheit erreicht '
            'Menschen nicht immer. Sandras Integration: Ehrlichkeit über das '
            'Was, Sorgfalt über das Wie. Die Wahrheit bleibt — die Verpackung '
            'entscheidet, ob sie ankommt.',
        ziele=['Mentoring-Programm für acht Nachwuchskräfte aufgebaut — mit '
               'messbaren Entwicklungsschritten', 'Fehlerkultur im Bereich: '
               'monatliche „Lessons Learned“ ohne Schuldzuweisung etabliert',
               'Eigene Rolle geschärft: 30 Prozent der Zeit für '
               'Menschenentwicklung freigeräumt — im Kalender, nicht im Kopf'],
        verzicht='Keine Bewerbung auf die nächste Hierarchiestufe in diesem '
            'Jahr — bewusst entschieden statt stillschweigend vermieden. '
            'Keine Detailkontrolle von Vorlagen, die ihre Teamleiter '
            'verantworten.',
        schritt='Diese Woche: Das erste Mentoring-Gespräch ansetzen — mit der '
            'Nachwuchskraft, in der sie sich selbst vor 20 Jahren erkennt.'
    ),
    dict(
        name='Tim, 26 — Berufseinsteiger mit zu vielen Möglichkeiten',
        situation='Master in BWL, zweites Jahr im Job, drei Abende pro Woche '
            'Weiterbildung, vier Projektideen, ein Podcast-Plan. Tim hat kein '
            'Motivationsproblem — er hat ein Auswahlproblem. Alles scheint '
            'möglich, nichts wird fertig.',
        vision='Ich bin jemand, der Dinge zu Ende bringt. Ich wähle wenige '
            'Wege und gehe sie tief statt breit. Menschen verbinden meinen '
            'Namen mit Verlässlichkeit und Substanz — nicht mit zehn '
            'angefangenen Projekten.',
        vision_note='Tims Vision ist bewusst eine Charakter-Vision, keine '
            'Karriere-Vision. Mit 26 muss niemand wissen, welcher Beruf es in '
            '20 Jahren ist. Aber wer man dabei sein will — das trägt durch '
            'jede Station.',
        werte=[('Neugier', 'sein Geschenk und sein Risiko — sie öffnet Türen '
                'und verhindert Ankommen'),
               ('Substanz', 'sein Gegengift: lieber eine Sache können als fünf '
                'anreißen'),
               ('Freundschaft', 'sein Korrektiv — die Menschen, die ihn erden, '
                'wenn das nächste „Riesending“ lockt')],
        konflikt='Neugier gegen Substanz: Jede neue Idee fühlt sich wichtiger '
            'an als das laufende Projekt. Tims Integration: Neugier bekommt '
            'ein Budget — vier Stunden pro Woche, nicht mehr. Substanz bekommt '
            'den Rest. Neue Ideen kommen in die Später-Klammer.',
        ziele=['Ein Projekt — den Podcast — in 6 Monaten auf zehn '
               'veröffentlichte Folgen gebracht', 'Im Job ein Thema besetzt: '
               'als Erster Ansprechpartner für Datenanalyse im Team etabliert',
               'Weiterbildung auf eine reduziert — abgeschlossen statt drei '
               'begonnen'],
        verzicht='Keine neuen Projekte, bis der Podcast Folge zehn erreicht. '
            'Maximal eine Weiterbildung parallel. Social-Media-Konsum auf '
            '30 Minuten am Tag — die Ideen anderer sind sein größter '
            'Ablenkungskanal.',
        schritt='Sonntag, 17 Uhr: Folge 1 aufnehmen. Nicht perfekt — '
            'veröffentlicht. Substanz beginnt mit Fertigstellen.'
    ),
]

def berufsprofile(s):
    out = []
    intro = ws_head('VORBILDER AUS DER PRAXIS', 'Vier Wege durch dieses Buch',
        'Vier Menschen, vier Ausgangslagen — und vier komplett durchgearbeitete '
        'VWS-Profile. Keine Idealbilder: Du siehst auch die Irrwege, die '
        'gestrichenen Entwürfe, die Wertekonflikte. Such dir den Weg, der '
        'deinem am nächsten kommt — und vergleiche mit deinen eigenen Seiten.', s)
    out += intro
    out.append(PageBreak())
    lbl = lambda txt: Paragraph(txt, ParagraphStyle('pf_l', fontName='Lora',
        fontSize=8.5, textColor=GD, spaceBefore=14, spaceAfter=4, tracking=2))
    body = ParagraphStyle('pf_b', fontName='Lora', fontSize=10, leading=16,
                          textColor=CH, spaceAfter=6)
    vision_st = ParagraphStyle('pf_v', fontName='Lora-It', fontSize=10.5,
        leading=17, textColor=NV, spaceAfter=6, leftIndent=12, rightIndent=12)
    for p in PROFILE:
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph('PROFIL', ParagraphStyle('pf_k', fontName='Lora',
            fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph(p['name'], ParagraphStyle('pf_n', fontName='Lora',
            fontSize=16, leading=21, textColor=NV, spaceAfter=4)))
        out.append(rule('14%', 2, CR, 10, 12, align='LEFT'))
        out.append(lbl('DIE AUSGANGSLAGE'))
        out.append(Paragraph(p['situation'], body))
        out.append(lbl('DIE VISION'))
        out.append(Paragraph('„' + p['vision'] + '“', vision_st))
        out.append(Paragraph(p['vision_note'], ParagraphStyle('pf_vn',
            fontName='Lora-It', fontSize=9, leading=14, textColor=SL,
            spaceAfter=6, leftIndent=12)))
        out.append(lbl('DIE KERNWERTE'))
        for w_, note_ in p['werte']:
            out.append(Paragraph(f'<font color="#8E1429"><b>{w_}</b></font> — {note_}',
                ParagraphStyle('pf_w', fontName='Lora', fontSize=9.7,
                    leading=15, textColor=CH, spaceAfter=5, leftIndent=6)))
        out.append(PageBreak())
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(p['name'].split(' — ')[0] + ' — Fortsetzung',
            ParagraphStyle('pf_n2', fontName='Lora', fontSize=11,
                textColor=DG, spaceAfter=8)))
        out.append(lbl('DER WERTEKONFLIKT — UND SEINE INTEGRATION'))
        out.append(Paragraph(p['konflikt'], body))
        out.append(lbl('DIE DREI STRATEGISCHEN ZIELE'))
        for i, z_ in enumerate(p['ziele'], 1):
            out.append(Paragraph(f'<font color="#8E1429"><b>{i}.</b></font> {z_}',
                ParagraphStyle('pf_z', fontName='Lora', fontSize=9.8,
                    leading=15, textColor=CH, spaceAfter=5, leftIndent=6)))
        out.append(lbl('DER VERZICHTS-VERTRAG'))
        out.append(Paragraph(p['verzicht'], body))
        out.append(lbl('DER ERSTE SCHRITT'))
        out.append(Paragraph(p['schritt'], ParagraphStyle('pf_s',
            fontName='Lora', fontSize=10, leading=16, textColor=NV,
            spaceAfter=10)))
        out.append(Paragraph('Und du? Was wäre dein Pendant zu diesem ersten '
            'Schritt?', ParagraphStyle('pf_q', fontName='Lora-It', fontSize=9.5,
                textColor=CR, spaceBefore=6, spaceAfter=4)))
        out += lines(3)
        out.append(PageBreak())
    return out


# ══════════════════════════════════════════════════════════════════════════════
# DAS 6-WOCHEN-PROGRAMM
# ══════════════════════════════════════════════════════════════════════════════

WEEKS = [
    dict(num=1, titel='Fundament', fokus='Standortbestimmung — ehrlich, nicht vorzeigbar',
        intro='Diese Woche geht es nicht um Veränderung. Es geht um Wahrheit: '
            'Wo stehst du wirklich? Welche Rollen spielst du — und wer bist du '
            'darunter? Lies Kapitel 1 und 2, mach den Selbsttest in Teil I.',
        aufgaben=['Kapitel 1 und 2 durcharbeiten — mit allen Übungen',
                  'Selbsttest „Wo stehst du wirklich?“ ausfüllen und auswerten',
                  'Die Rollen-Übung: drei Rollen benennen, die du spielst — '
                  'und was sie dich kosten'],
        frage='Welche Erwartung anderer hat diese Woche eine Entscheidung von '
              'mir geprägt?'),
    dict(num=2, titel='Vision', fokus='Deinen Zustand beschreiben — als wäre er schon da',
        intro='Die wichtigste Woche des Programms. Du arbeitest die komplette '
            'Visions-Werkstatt durch — alle vier Schritte. Plane drei feste '
            'Termine mit dir selbst ein: Sammeln, Verdichten, Formulieren '
            'brauchen Abstand zueinander.',
        aufgaben=['Kapitel 3 lesen + Visions-Werkstatt Schritt 1 und 2',
                  'Zwei Tage Pause — dann Schritt 3: drei Entwürfe schreiben',
                  'Schritt 4: Vision an drei realen Entscheidungen testen'],
        frage='Steht meine Vision in der Gegenwartsform — oder versteckt sich '
              'noch ein „Ich will“ darin?'),
    dict(num=3, titel='Werte', fokus='Die echten finden — nicht die vorzeigbaren',
        intro='Sechzig Werte, am Ende bleiben drei bis sechs. Der Maßstab ist '
            'unbequem: Ein Wert, der dich nie etwas gekostet hat, ist eine '
            'Vorliebe. Diese Woche trennt gelebte von genannten Werten.',
        aufgaben=['Kapitel 4 lesen + Werte-Werkstatt Schritt 1 bis 3',
                  'Zu jedem Kernwert die Schattenseite benennen',
                  'Konflikt-Matrix: deine zwei stärksten Wertespannungen '
                  'ausarbeiten'],
        frage='Welcher meiner Werte ist diese Woche unter Druck geraten — '
              'und hat er gehalten?'),
    dict(num=4, titel='Strategie', fokus='Drei Ziele — und ein klares Nein zum Rest',
        intro='Strategie ist Verzicht. Diese Woche machst du Inventur über '
            'alle Baustellen, filterst sie durch deine Vision und entscheidest '
            'dich für drei strategische Ziele. Der Verzichts-Vertrag am Ende '
            'ist der wichtigste Teil.',
        aufgaben=['Kapitel 5 lesen + Strategie-Werkstatt komplett',
                  'Verzichts-Vertrag unterschreiben — mit Datum',
                  'Für Ziel 1 den 90-Tage-Bogen ausfüllen'],
        frage='Was habe ich diese Woche bewusst NICHT getan — und was wurde '
              'dadurch möglich?'),
    dict(num=5, titel='Energie & Umsetzung', fokus='Den Tank kennen, bevor du Strecke planst',
        intro='Leistung folgt der Regeneration — nicht umgekehrt. Diese Woche '
            'führst du das Energie-Protokoll und sortierst deine Woche durch '
            'die Eisenhower-Matrix. Du wirst sehen, wohin deine Kraft '
            'tatsächlich fließt.',
        aufgaben=['Kapitel 6 und 8 lesen',
                  'Energie-Protokoll: sieben Tage täglich ausfüllen',
                  'Eisenhower-Übung: deine letzte Woche auf die Quadranten '
                  'verteilen — und einen festen Quadrant-II-Termin einplanen'],
        frage='Wie viel Prozent meiner Woche hat in Quadrant II gelebt?'),
    dict(num=6, titel='Wirkung & Dranbleiben', fokus='Vom Programm zur Gewohnheit',
        intro='Die letzte Programmwoche baut die Brücke in deinen Alltag: '
            'dein Vermächtnis-Satz, deine Rituale, dein Review-Rhythmus. '
            'Am Ende steht das Ritual auf der letzten Buchseite — dein '
            'Versprechen an dich.',
        aufgaben=['Kapitel 7 und 9 lesen',
                  'Drei Rituale aus Teil VIII auswählen und im Kalender '
                  'verankern', 'Das Ritual am Buchende: deinen Satz schreiben, '
                  'datieren, unterschreiben'],
        frage='Welches Ritual überlebt auch eine stressige Woche — und welches '
              'braucht Schutz?'),
]

def wochenprogramm(s):
    out = part_page('VII', 'Das 6-Wochen-Programm',
        'Struktur für alle, die einen Rhythmus wollen',
        'Sechs Wochen, sechs Schwerpunkte. Jede Woche: ein Fokus, drei '
        'Kernaufgaben, tägliche Check-ins, ein Wochenreview. Du brauchst etwa '
        'drei bis vier Stunden pro Woche — verteilt auf feste Termine mit dir '
        'selbst. Die trägst du jetzt ein, bevor der Alltag sie frisst.', s)
    cell = ParagraphStyle('wp_c', fontName='Lora', fontSize=8.5, textColor=CH)
    head = ParagraphStyle('wp_h', fontName='Lora', fontSize=8.5,
                          textColor=white, alignment=TA_CENTER)
    for wk in WEEKS:
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(f'WOCHE {wk["num"]} VON 6',
            ParagraphStyle('wk_k', fontName='Lora', fontSize=9, textColor=GD,
                           spaceAfter=4, tracking=2)))
        out.append(Paragraph(wk['titel'], ParagraphStyle('wk_t',
            fontName='Lora', fontSize=19, leading=25, textColor=NV,
            spaceAfter=2)))
        out.append(Paragraph(wk['fokus'], ParagraphStyle('wk_f',
            fontName='Lora-It', fontSize=11, textColor=SL, spaceAfter=10)))
        out.append(rule('14%', 2, CR, 10, 12, align='LEFT'))
        out.append(Paragraph(wk['intro'], s['body']))
        out.append(Paragraph('<b>Deine drei Kernaufgaben:</b>', s['body']))
        for a_ in wk['aufgaben']:
            out.append(checkbox(a_, s, indent=6))
        out.append(Spacer(1, 8))
        out.append(Paragraph('<b>Meine festen Termine mit mir diese Woche:</b>',
            s['body']))
        out.append(Paragraph('Termin 1: ____________________  ·  '
            'Termin 2: ____________________  ·  Termin 3: ____________________',
            ParagraphStyle('wk_term', fontName='Lora', fontSize=9.5,
                textColor=CH, spaceAfter=4)))
        out.append(PageBreak())
        # Tages-Check-ins
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(f'WOCHE {wk["num"]} · TAGES-CHECK-IN',
            ParagraphStyle('ci_k', fontName='Lora', fontSize=9, textColor=GD,
                           spaceAfter=4, tracking=2)))
        out.append(Paragraph('Jeden Abend zwei Minuten. Mehr nicht — aber auch '
            'nicht weniger.', ParagraphStyle('ci_i', fontName='Lora-It',
                fontSize=9.5, textColor=SL, spaceAfter=10)))
        data = [[Paragraph('<b>Tag</b>', head),
                 Paragraph('<b>Heute auf mein Ziel eingezahlt</b>', head),
                 Paragraph('<b>Heute gelernt / bemerkt</b>', head),
                 Paragraph('<b>Energie<br/>1–10</b>', head)]]
        for d_ in ['Mo','Di','Mi','Do','Fr','Sa','So']:
            data.append([Paragraph(f'<b>{d_}</b>', cell), '\n\n\n', '\n\n\n', ''])
        t = Table(data, colWidths=[32, (TW-78)/2, (TW-78)/2, 46])
        t.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),NV),
            ('GRID',(0,0),(-1,-1),0.4,RU),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
            ('TOPPADDING',(0,0),(-1,-1),5),
            ('BOTTOMPADDING',(0,0),(-1,-1),5),
            ('LEFTPADDING',(0,0),(-1,-1),5),
        ]))
        out.append(t)
        out.append(PageBreak())
        # Wochenreview
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(f'WOCHE {wk["num"]} · WOCHENREVIEW',
            ParagraphStyle('wr_k', fontName='Lora', fontSize=9, textColor=GD,
                           spaceAfter=4, tracking=2)))
        out.append(Paragraph('Am Ende der Woche — 15 Minuten, ehrlich.',
            ParagraphStyle('wr_i', fontName='Lora-It', fontSize=9.5,
                textColor=SL, spaceAfter=12)))
        for q_ in ['Was ist diese Woche gelungen — konkret?',
                   'Was habe ich vermieden — und warum vermutlich?',
                   wk['frage'],
                   'Was nehme ich in die nächste Woche mit — eine Sache, '
                   'nicht fünf?']:
            out.append(Paragraph(q_, ParagraphStyle('wr_q', fontName='Lora',
                fontSize=10, leading=15, textColor=NV, spaceBefore=10,
                spaceAfter=2)))
            out += lines(3)
        out.append(PageBreak())
        out += wochen_schreibseite(wk['num'], wk['titel'], s)
    return out

# ══════════════════════════════════════════════════════════════════════════════
# TEIL VIII — DRANBLEIBEN
# ══════════════════════════════════════════════════════════════════════════════

def dranbleiben(s):
    out = part_page('VIII', 'Dranbleiben',
        'Rituale, Reviews und der Umgang mit Rückschlägen',
        'Die meisten Programme scheitern nicht in Woche eins — sie scheitern '
        'in Woche sieben, wenn der Alltag zurückkehrt. Dieser Teil baut die '
        'Strukturen, die deine Arbeit überleben lassen: Rituale, feste '
        'Reviews und einen ehrlichen Umgang mit Rückschlägen.', s)

    # Rituale
    out += ws_head('DRANBLEIBEN · 1', 'Rituale, die halten',
        'Disziplin ist überschätzt — Struktur ist unterschätzt. Ein Ritual ist '
        'eine Entscheidung, die du nur einmal triffst und dann nie wieder '
        'treffen musst. Wähle aus den folgenden sechs höchstens drei. '
        'Drei gehaltene schlagen sechs gebrochene.', s)
    rituale = [
        ('Der Wochenstart (Montag, 15 Min.)', 'Drei Fragen vor der ersten Mail: '
         'Was ist diese Woche wirklich wichtig? Welcher Quadrant-II-Block steht '
         'im Kalender? Was lasse ich bewusst liegen?'),
        ('Der Visions-Blick (täglich, 1 Min.)', 'Deine Vision dort, wo du sie '
         'siehst: Spiegelrand, Handyhülle, Schreibtischschublade. Einmal am Tag '
         'lesen. Nicht analysieren — nur lesen.'),
        ('Der Abend-Check (täglich, 2 Min.)', 'Zwei Fragen: Habe ich heute auf '
         'eines meiner drei Ziele eingezahlt? Was hat mir heute Energie '
         'gegeben? Stichworte reichen.'),
        ('Der Werte-Moment (bei jeder schweren Entscheidung)',
         'Bevor du entscheidest: Welcher meiner Kernwerte ist hier betroffen — '
         'und was würde er raten? 30 Sekunden, die jahrelange Umwege ersparen.'),
        ('Das Monatsreview (letzter Sonntag, 30 Min.)', 'Mit dem Bogen auf den '
         'nächsten Seiten: Fortschritt auf die drei Ziele, Energie-Bilanz, '
         'eine Anpassung für den nächsten Monat.'),
        ('Der Quartals-Kompass (alle 90 Tage, 2 Std.)', 'Der große Blick: '
         '90-Tage-Bögen auswerten, Ziele bestätigen oder anpassen, neuen '
         '90-Tage-Plan schreiben. Am besten außer Haus — anderer Ort, '
         'anderer Blick.'),
    ]
    for t_, x_ in rituale:
        out.append(checkbox(f'<b>{t_}</b> — {x_}', s))
    out.append(Spacer(1, 12))
    out.append(Paragraph('<b>Meine drei Rituale — mit festem Platz im Kalender:</b>',
        s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'{i}. Ritual: ______________________________  ·  '
            'Wann: ____________________',
            ParagraphStyle('rit', fontName='Lora', fontSize=10, textColor=CH,
                           spaceBefore=10)))
    out.append(PageBreak())

    # Rückschläge & Glaubenssätze
    out += ws_head('DRANBLEIBEN · 2', 'Rückschläge und Glaubenssätze',
        'Du wirst Wochen haben, in denen nichts gelingt. Das ist kein Zeichen, '
        'dass dein Plan falsch ist — es ist ein Zeichen, dass du lebst. '
        'Entscheidend ist nicht der Rückschlag. Entscheidend ist die '
        'Geschichte, die du dir danach erzählst.', s)
    out.append(Paragraph('<b>Das Muster erkennen:</b> Nach einem Rückschlag '
        'meldet sich meist ein alter Glaubenssatz — „Ich halte sowieso nichts '
        'durch“, „Das war ja klar“, „Anderen fällt das leichter“. Diese Sätze '
        'fühlen sich wie Wahrheit an. Es sind Gewohnheiten.', s['body']))
    out.append(Paragraph('<b>Die Übung:</b> Hole den Satz aus dem Kopf aufs '
        'Papier — dort verliert er Macht. Dann prüfe ihn wie ein Anwalt: '
        'Was spricht dafür? Was dagegen? Und was wäre ein Satz, der ehrlicher '
        'ist?', s['body']))
    for blk in [
        ('Mein wiederkehrender Satz nach Rückschlägen:', 2),
        ('Drei Fakten, die gegen diesen Satz sprechen:', 3),
        ('Der ehrlichere Satz — nicht schöngefärbt, aber fair:', 2),
    ]:
        out.append(Paragraph('<b>' + blk[0] + '</b>',
            ParagraphStyle('gs', fontName='Lora', fontSize=10, textColor=NV,
                           spaceBefore=12, spaceAfter=2)))
        out += lines(blk[1])
    out.append(hint('Weg von den Problemen, hin zu den Lösungen heißt nicht, '
        'Probleme zu leugnen. Es heißt, ihnen nicht das Steuer zu überlassen.', s))
    out.append(PageBreak())

    # Monatsreview-Bögen
    for m in range(1, 7):
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph(f'MONATSREVIEW · MONAT {m}',
            ParagraphStyle('mr_k', fontName='Lora', fontSize=9, textColor=GD,
                           spaceAfter=4, tracking=2)))
        out.append(Paragraph('30 Minuten am letzten Sonntag des Monats.',
            ParagraphStyle('mr_i', fontName='Lora-It', fontSize=9.5,
                textColor=SL, spaceAfter=12)))
        for q_, n_ in [
            ('Fortschritt auf Ziel 1 / 2 / 3 — in je einem Satz:', 4),
            ('Mein bester Moment diesen Monat — und was er über mich sagt:', 3),
            ('Wo ich vom Plan abgewichen bin — und ob die Abweichung klug war:', 3),
            ('Energie-Bilanz: Was nehme ich mit, was lasse ich zurück?', 3),
            ('Eine Anpassung für den nächsten Monat — eine, nicht fünf:', 2),
        ]:
            out.append(Paragraph(q_, ParagraphStyle('mr_q', fontName='Lora',
                fontSize=10, leading=15, textColor=NV, spaceBefore=8,
                spaceAfter=2)))
            out += lines(n_)
        out.append(PageBreak())

    # 90-Tage-Review
    out.append(Spacer(1, 0.2*cm))
    out.append(Paragraph('DER 90-TAGE-REVIEW',
        ParagraphStyle('r90_k', fontName='Lora', fontSize=9, textColor=GD,
                       spaceAfter=4, tracking=2)))
    out.append(Paragraph('Der große Blick zurück — und nach vorn',
        ParagraphStyle('r90_t', fontName='Lora', fontSize=17, textColor=NV,
                       spaceAfter=4)))
    out.append(rule('14%', 2, CR, 10, 14, align='LEFT'))
    out.append(Paragraph('Nach 90 Tagen entscheidest du neu: Welche Ziele '
        'bestätigst du, welche passt du an, welche haben sich erledigt? '
        'Eine Strategie, die sich nie anpasst, ist keine Strategie — '
        'sie ist Sturheit.', s['body']))
    for q_, n_ in [
        ('Ziel 1 — erreicht / angepasst / gestrichen? Begründung:', 3),
        ('Ziel 2 — erreicht / angepasst / gestrichen? Begründung:', 3),
        ('Ziel 3 — erreicht / angepasst / gestrichen? Begründung:', 3),
        ('Was ich über mich gelernt habe — die eine wichtigste Erkenntnis:', 3),
        ('Hat sich meine Vision bewährt? Wo hat sie mir Entscheidungen '
         'erleichtert — wo war sie zu weich?', 4),
        ('Meine drei Ziele für die nächsten 90 Tage:', 4),
    ]:
        out.append(Paragraph(q_, ParagraphStyle('r90_q', fontName='Lora',
            fontSize=10, leading=15, textColor=NV, spaceBefore=10,
            spaceAfter=2)))
        out += lines(n_)
    out.append(PageBreak())

    # Jahreskompass
    out.append(Spacer(1, 0.2*cm))
    out.append(Paragraph('DER JAHRESKOMPASS',
        ParagraphStyle('jk_k', fontName='Lora', fontSize=9, textColor=GD,
                       spaceAfter=4, tracking=2)))
    out.append(Paragraph('Einmal im Jahr — der Blick aufs Ganze',
        ParagraphStyle('jk_t', fontName='Lora', fontSize=17, textColor=NV,
                       spaceAfter=4)))
    out.append(rule('14%', 2, CR, 10, 14, align='LEFT'))
    out.append(Paragraph('Nimm dir einen halben Tag, am besten zwischen den '
        'Jahren oder an deinem Geburtstag. Anderer Ort, kein Telefon. '
        'Vier Fragen — mehr braucht es nicht.', s['body']))
    for q_, n_ in [
        ('Worauf bin ich in diesem Jahr wirklich stolz — auch auf das Leise?', 4),
        ('Gilt meine Vision noch — wörtlich, Satz für Satz? Was hat sich '
         'verschoben?', 4),
        ('Haben meine Werte gehalten, als es schwierig wurde? Wo ja, wo nein?', 4),
        ('Das Leitmotiv für mein nächstes Jahr — ein Wort oder ein Satz:', 3),
    ]:
        out.append(Paragraph(q_, ParagraphStyle('jk_q', fontName='Lora',
            fontSize=10, leading=15, textColor=NV, spaceBefore=10,
            spaceAfter=2)))
        out += lines(n_)
    out.append(PageBreak())
    return out


def notizen_seiten(s, n=6):
    out = []
    for i in range(n):
        out.append(Spacer(1, 0.2*cm))
        out.append(Paragraph('NOTIZEN', ParagraphStyle('nt_k', fontName='Lora',
            fontSize=8.5, textColor=GD, spaceAfter=10, tracking=2)))
        out += lines(20, gap=27)
        out.append(PageBreak())
    return out

# ══════════════════════════════════════════════════════════════════════════════
# KAPITEL-SCHREIBRAUM — Vertiefungsfragen je Kapitel
# ══════════════════════════════════════════════════════════════════════════════

KAPITEL_FRAGEN = {
    1: [('Welche Rolle spielst du am überzeugendsten — und was kostet sie dich?',
         'Beschreibe die Rolle konkret: Wo trägst du sie, seit wann, für wen? '
         'Und dann ehrlich: Was bekommst du dafür — und was zahlst du?'),
        ('Wer wärst du ohne die Erwartungen der drei wichtigsten Menschen '
         'in deinem Leben?',
         'Keine Loyalitätsfrage — eine Gedankenübung. Was würdest du anders '
         'entscheiden, sagen, lassen? Was davon willst du dir zurückholen?')],
    2: [('Welche Überzeugung steuert dich, seit du denken kannst — '
         'und stimmt sie noch?',
         'Sätze wie „Ich muss es allein schaffen“ oder „Ohne Fleiß bin ich '
         'nichts wert“ entstehen früh und regieren lange. Hol deinen Satz '
         'ans Licht — und prüfe ihn mit heutigen Augen.'),
        ('Was würdest du tun, wenn niemand zusähe?',
         'Kein Publikum, keine Bewertung, kein Lebenslauf. Was bliebe übrig — '
         'und was sagt dir das über deinen Eisberg unter der Wasserlinie?')],
    3: [('Dein Tag in drei Jahren — von morgens bis abends',
         'Beschreibe ihn in der Gegenwartsform, als wäre er heute: Wo wachst '
         'du auf, woran arbeitest du, mit wem sprichst du, womit endet der '
         'Tag? Konkrete Bilder — keine Konzepte.')],
    4: [('Die Situation, in der du zuletzt gegen einen eigenen Wert '
         'gehandelt hast',
         'Erzähl sie ohne Beschönigung: Was war der Moment, was hast du '
         'getan, was hättest du gewollt? Und die wichtigste Frage: Was hat '
         'der Verrat dich gelehrt — über den Wert und über dich?')],
    5: [('Was würdest du heute beenden, wenn Beenden nichts kosten würde?',
         'Ein Projekt, eine Gewohnheit, eine Verpflichtung, vielleicht eine '
         'Rolle. Schreib auf, was du beenden würdest — und dann: Was kostet '
         'das Beenden wirklich? Oft weniger als das Weitermachen.')],
    6: [('Deine energiereichste Phase — was war damals anders?',
         'Geh zurück zu einer Zeit, in der du getragen warst statt erschöpft. '
         'Was war anders: Menschen, Aufgaben, Rhythmus, Schlaf, Bewegung? '
         'Welche zwei Zutaten davon kannst du dir zurückholen?')],
    7: [('Die Rede zu deinem 80. Geburtstag',
         'Der Mensch, der dich am besten kennt, hält sie. Was soll er sagen — '
         'über deine Wirkung, nicht deine Leistungen? Schreib die drei '
         'Kernsätze dieser Rede. Und dann: Lebst du schon darauf zu?')],
    8: [('Wie sieht echte Regeneration für dich aus — und wann hattest '
         'du sie zuletzt?',
         'Nicht Erholung nebenbei — echte Regeneration, nach der du anders '
         'denkst. Beschreibe sie konkret. Und plane die nächste: Wann, wo, '
         'wie lange, was ist dafür abzusagen?')],
    9: [('Dein Vorbild — und der eine Grundsatz, den du übernimmst',
         'Historisch oder lebend, berühmt oder privat: Wer inspiriert dich '
         'wirklich? Beschreibe, was diese Person auszeichnet — und welchen '
         'ihrer Grundsätze du ab jetzt in dein eigenes Leben übersetzt.')],
}

def kapitel_schreibraum(num, s):
    out = []
    for title, prompt in KAPITEL_FRAGEN.get(num, []):
        out += writing_page(title, prompt, 13, s,
                            f'VERTIEFUNG · KAPITEL {num}')
    return out

def wochen_schreibseite(num, titel, s):
    return writing_page(
        f'Raum für Woche {num} — {titel}',
        'Gedanken, Widerstände, Zwischenergebnisse dieser Woche. '
        'Unsortiert ist erlaubt — Hauptsache ehrlich.', 14, s,
        f'WOCHE {num} · FREIRAUM')
