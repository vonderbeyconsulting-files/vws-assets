"""VWS Workbook Master — extension module (workshops, tests, program, profiles)"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white
from reportlab.platypus import Paragraph, Spacer, PageBreak, HRFlowable, Table, TableStyle, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
CR = HexColor('#8E1429')
SL = HexColor('#5F7FA8')
WW = HexColor('#F0EEE8')
NV = HexColor('#1A2744')
GD = HexColor('#C0A84A')
CH = HexColor('#3A3A3A')
DG = HexColor('#888888')
RU = HexColor('#D8D3CB')
CB = HexColor('#EBF0F5')
CW = HexColor('#FAF7EE')
W, H = A4
ML = 3.2 * cm
MR = 3.2 * cm
TW = W - ML - MR

def rule(w='100%', thick=0.4, col=RU, before=6, after=10, align='CENTER'):
    return HRFlowable(width=w, thickness=thick, color=col, spaceBefore=before, spaceAfter=after, hAlign=align)

def lines(n=6, width='100%', gap=26):
    out = []
    for _ in range(n):
        out.append(HRFlowable(width=width, thickness=0.35, color=RU, spaceBefore=gap, spaceAfter=0))
    out.append(Spacer(1, 8))
    return out

def part_page(roman, title, sub, body, s):
    """Teil-Trennerseite"""
    return [Spacer(1, 4.2 * cm), Paragraph('PART ' + roman, ParagraphStyle('pt_num', fontName='Lora', fontSize=13, textColor=GD, alignment=TA_CENTER, spaceAfter=10, tracking=3)), Paragraph(title, ParagraphStyle('pt_title', fontName='Lora', fontSize=30, leading=38, textColor=NV, alignment=TA_CENTER, spaceAfter=6)), rule('16%', 2.2, CR, 10, 18), Paragraph(sub, ParagraphStyle('pt_sub', fontName='Lora-It', fontSize=13, leading=20, textColor=SL, alignment=TA_CENTER, spaceAfter=22)), Paragraph(body, ParagraphStyle('pt_body', fontName='Lora', fontSize=10.5, leading=17.5, textColor=CH, alignment=TA_CENTER, leftIndent=34, rightIndent=34)), PageBreak()]

def ws_head(kicker, title, intro, s):
    """Werkstatt-Kopf"""
    return [Spacer(1, 0.3 * cm), Paragraph(kicker, s['kap_num']), Paragraph(title, ParagraphStyle('ws_t', fontName='Lora', fontSize=21, leading=27, textColor=NV, spaceAfter=4)), rule('14%', 2, CR, 10, 14, align='LEFT'), Paragraph(intro, s['body'])]

def step_label(num, text, s):
    return Paragraph(f'<font color="#8E1429"><b>STEP {num}</b></font>&nbsp;&nbsp;{text}', ParagraphStyle('step', fontName='Lora', fontSize=10.5, leading=16, textColor=NV, spaceBefore=14, spaceAfter=6))

def hint(text, s):
    return Paragraph('<font name="DejaVu" color="#8E1429"><b>→</b></font> ' + text, ParagraphStyle('hint', fontName='Lora-It', fontSize=9.5, leading=15, textColor=SL, spaceBefore=4, spaceAfter=10, leftIndent=10))

def writing_page(title, prompt, n_lines, s, kicker='WRITING SPACE'):
    """Eine volle Schreibseite"""
    out = [Spacer(1, 0.2 * cm), Paragraph(kicker, ParagraphStyle('wp_k', fontName='Lora', fontSize=8.5, textColor=GD, spaceAfter=4, tracking=2)), Paragraph(title, ParagraphStyle('wp_t', fontName='Lora', fontSize=15, leading=20, textColor=NV, spaceAfter=6)), Paragraph(prompt, ParagraphStyle('wp_p', fontName='Lora-It', fontSize=10, leading=16, textColor=CH, spaceAfter=10))]
    out += lines(n_lines)
    out.append(PageBreak())
    return out

def checkbox(text, s, indent=0):
    return Paragraph('<font name="DejaVu">□</font>&nbsp;&nbsp;' + text, ParagraphStyle('cb', fontName='Lora', fontSize=10, leading=18, textColor=CH, leftIndent=indent, spaceAfter=5))

def scale_header(s):
    t = Table([[Paragraph('<font color="#888888" size="8">1 = does not apply at all &nbsp;·&nbsp; 3 = partly &nbsp;·&nbsp; 5 = fully applies</font>', ParagraphStyle('sh', fontName='Lora', fontSize=8))]], colWidths=[TW])
    t.setStyle(TableStyle([('BOTTOMPADDING', (0, 0), (-1, -1), 8), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
    return t

def test_item(num, text, s):
    circles = Paragraph('<font color="#5F7FA8">①&nbsp;&nbsp;②&nbsp;&nbsp;③&nbsp;&nbsp;④&nbsp;&nbsp;⑤</font>', ParagraphStyle('ti_c', fontName='DejaVu', fontSize=11, alignment=TA_RIGHT))
    q = Paragraph(f'<font color="#8E1429"><b>{num:02d}</b></font>&nbsp;&nbsp;{text}', ParagraphStyle('ti_q', fontName='Lora', fontSize=9.8, leading=14.5, textColor=CH))
    t = Table([[q, circles]], colWidths=[TW - 118, 118])
    t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 0), ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5), ('LINEBELOW', (0, 0), (-1, -1), 0.3, RU)]))
    return t

def score_table(rows, s):
    """rows: list of (range_label, headline, text)"""
    data = []
    for rng, head, txt in rows:
        data.append([Paragraph(f'<b>{rng}</b>', ParagraphStyle('sc_r', fontName='Lora', fontSize=10, textColor=CR)), [Paragraph(head, ParagraphStyle('sc_h', fontName='Lora', fontSize=10, textColor=NV, spaceAfter=2)), Paragraph(txt, ParagraphStyle('sc_t', fontName='Lora', fontSize=9.3, leading=13.5, textColor=CH))]])
    t = Table(data, colWidths=[78, TW - 78])
    t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 8), ('RIGHTPADDING', (0, 0), (-1, -1), 8), ('TOPPADDING', (0, 0), (-1, -1), 9), ('BOTTOMPADDING', (0, 0), (-1, -1), 9), ('BACKGROUND', (0, 0), (-1, -1), CW), ('LINEBELOW', (0, 0), (-1, -2), 0.4, white)]))
    return t

def selftest(kicker, title, intro, items, eval_title, eval_rows, s, items_per_page=9):
    """Complete self-assessment with scoring"""
    out = ws_head(kicker, title, intro, s)
    out.append(Spacer(1, 6))
    out.append(scale_header(s))
    for i, item in enumerate(items, 1):
        out.append(test_item(i, item, s))
        if i % items_per_page == 0 and i < len(items):
            out.append(PageBreak())
            out.append(Spacer(1, 0.3 * cm))
    out.append(Spacer(1, 14))
    out.append(Paragraph('SCORING', ParagraphStyle('ev_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
    out.append(Paragraph(eval_title, ParagraphStyle('ev_t', fontName='Lora', fontSize=13, textColor=NV, spaceAfter=4)))
    out.append(Paragraph(f'Add up your points (question 1–{len(items)}, 1–5 points each). Enter the total:', ParagraphStyle('ev_i', fontName='Lora', fontSize=9.8, leading=15, textColor=CH, spaceAfter=8)))
    sumline = Table([[Paragraph('My score:', ParagraphStyle('ev_s', fontName='Lora', fontSize=10, textColor=NV)), HRFlowable(width='80%', thickness=0.4, color=RU, spaceBefore=12)]], colWidths=[110, 130])
    sumline.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'BOTTOM'), ('LEFTPADDING', (0, 0), (-1, -1), 0), ('BOTTOMPADDING', (0, 0), (-1, -1), 14)]))
    out.append(sumline)
    out.append(score_table(eval_rows, s))
    out.append(PageBreak())
    return out

def howto_pages(s):
    """How to work with this book + program overview"""
    out = [Spacer(1, 0.4 * cm), Paragraph('BEFORE YOU BEGIN', s['kap_num']), Paragraph('How to work with this book', s['sect_hero']), rule('20%', 2.5, CR, 4, 18), Paragraph('This workbook is not a book to read through. It is a workspace. You will write, cross out, doubt, start again. That is exactly how it should be. One insight you wrote down yourself weighs more than ten you only read.', s['body']), Paragraph('<b>Three paths through this book:</b>', s['body'])]
    ways = [('The Chapter Path', 'You work through the nine chapters in order — with all the exercises and workshops. Allow four to six weeks if you give yourself two fixed appointments with yourself each week.'), ('The 6-Week Program', "In the back you'll find a structured program with a weekly focus, daily check-ins and a weekly review. It guides you through every topic — with a clear rhythm."), ('The Toolbox Path', 'You start where it hurts: Vision unclear? Part II. Values in conflict? Part III. Too many open fronts? Part IV. Each part also works on its own.')]
    for t_, x_ in ways:
        out.append(Paragraph(f'<font color="#8E1429"><b>{t_}</b></font> — {x_}', ParagraphStyle('way', fontName='Lora', fontSize=10.3, leading=16.5, textColor=CH, spaceAfter=10, leftIndent=6)))
    out += [Spacer(1, 8), Paragraph('<b>Four rules I urge on you:</b>', s['body'])]
    rules_ = ['Write by hand. What the hand writes, the mind thinks through more thoroughly.', 'Answer honestly, not presentably. No one reads this book but you.', "If a question is uncomfortable, it's probably the right one.", 'No perfectionism. An honest half answer beats a polished whole one.']
    for r_ in rules_:
        out.append(checkbox(r_, s))
    out += [Spacer(1, 12), Paragraph('Together we shape your future.', ParagraphStyle('motto', fontName='Lora-It', fontSize=11, textColor=CR, spaceAfter=2)), Paragraph('<i>Werner</i>', s['small']), PageBreak()]
    out += [Spacer(1, 0.4 * cm), Paragraph('YOUR ROADMAP', s['kap_num']), Paragraph('The 6-week program at a glance', s['sect_hero']), rule('20%', 2.5, CR, 4, 18), Paragraph("If you choose the structured path: here's how it's built. Each week has a focus, three core tasks and a weekly review. The worksheets for it are in Part VII.", s['body'])]
    weeks = [('1', 'Foundation', 'Taking stock. Separating identity and roles. Self-assessment: where do you really stand?', 'Chapters 1–2'), ('2', 'Vision', 'Describing your state in three years — as if it were already real. Working through the Vision Workshop.', 'Chapter 3 + Part II'), ('3', 'Values', 'Finding your three to six core values — the real ones, not the presentable ones. Naming conflicts and shadow sides.', 'Chapter 4 + Part III'), ('4', 'Strategy', 'Deriving three strategic goals from the vision. Practicing sacrifice: What do you deliberately not do?', 'Chapter 5 + Part IV'), ('5', 'Energy & Execution', 'Taking stock of energy sources and drains. Task blocks and Eisenhower sorting.', 'Chapters 6 + 8'), ('6', 'Impact & Staying With It', 'Your legacy sentence. Setting rituals. Writing a 90-day plan. The ritual at the end of the book.', 'Chapters 7 + 9 + Part VIII')]
    data = []
    for n_, f_, t_, k_ in weeks:
        data.append([Paragraph(f'<b>W{n_}</b>', ParagraphStyle('wk_n', fontName='Lora', fontSize=12, textColor=white, alignment=TA_CENTER)), [Paragraph(f_, ParagraphStyle('wk_f', fontName='Lora', fontSize=10.5, textColor=NV, spaceAfter=2)), Paragraph(t_, ParagraphStyle('wk_t', fontName='Lora', fontSize=9, leading=13, textColor=CH)), Paragraph(k_, ParagraphStyle('wk_k', fontName='Lora-It', fontSize=8.3, textColor=SL, spaceBefore=2))]])
    t = Table(data, colWidths=[44, TW - 44])
    t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('BACKGROUND', (0, 0), (0, -1), NV), ('TOPPADDING', (0, 0), (-1, -1), 8), ('BOTTOMPADDING', (0, 0), (-1, -1), 8), ('LEFTPADDING', (1, 0), (1, -1), 12), ('LINEBELOW', (0, 0), (-1, -2), 1.2, white)]))
    out.append(t)
    out.append(PageBreak())
    return out

def selftest_fundament(s):
    items = ['I can say in one sentence who I am — without naming my profession.', 'I made my most important decisions of recent years actively, not by default.', 'I know which expectations of others are currently shaping my life.', 'I can distinguish my roles (work, family, friends) from my person.', "When I wake up in the morning, I know what I'm getting up for — beyond duty.", 'I make decisions even when they disappoint someone.', 'I know what gives me energy — and arrange my day around it.', 'I recognize my recurring thought patterns when they block me.', 'I can say no without justifying myself for days.', 'In the past twelve months I have done something that truly challenged me.', 'I talk about my goals so concretely that others understand them at once.', 'When I look at the last five years, I see a direction — not coincidences.']
    eval_rows = [('12–27', "You function — but who's steering?", "Much in your life runs to other people's plans. This is not an accusation: most people have never decided who they are. For you this book is not fine-tuning but a full renovation. Take your time with Parts I and II — that's where your greatest leverage lies."), ('28–44', 'The foundation is there — the direction is missing.', "You know yourself better than most. But between self-knowledge and lived direction there's a gap. Your work lies in the translation: turning insight into decision. The workshops in Parts II to IV are your core program."), ('45–60', "You're further along than most — now it gets demanding.", "Self-knowledge is there, direction too. Your danger is called a comfort zone dressed in fine words. Work especially on the shadow-side exercises and on sacrifice in Part IV: What do you deliberately stop doing? That's where you grow.")]
    return selftest('SELF-ASSESSMENT · PART I', 'Where do you really stand?', 'Twelve statements. Rate honestly, not presentably — no one reads this book but you. There is no good or bad result. There is only an honest starting point.', items, 'Your starting point', eval_rows, s)

def selftest_vision(s):
    items = ['I can state my vision in three sentences — without thinking.', 'My vision describes a state, not a plan or process.', 'My vision is in the present tense: “I am”, not “I want to be”.', 'Anyone who hears my vision understands it at once — without follow-up questions.', 'My vision describes how I come across as a person — not just what I do.', 'My vision would still hold even if I changed profession tomorrow.', 'My vision helps me say no in concrete decisions.', "When I read my vision, I feel something — it doesn't leave me cold.", 'My vision is unmistakably mine — it could belong to no other life.', 'I have read or thought about my vision at least once in the past few weeks.', 'My vision is big enough to be uncomfortable.', 'I could say my vision out loud, in front of people who know me.']
    eval_rows = [('12–27', 'You have wishes — not yet a vision.', "That's the most honest starting point there is. Most people confuse vision with a career plan. Work through the Vision Workshop completely — especially steps 1 and 2. A vision doesn't emerge at a desk in an hour. Give it a week."), ('28–44', "A vision is there — it just doesn't carry yet.", "You've formulated a direction, but it's still too smooth, too interchangeable or too much of a plan. Focus on two questions: Does it describe a state? And is it unmistakably yours? Workshop steps 3 and 4 sharpen exactly that."), ('45–60', 'Your vision is set — now it has to work.', 'A strong vision left in the drawer is decoration. Your task is called integration: using the vision as a decision filter in everyday life. Part IV (Strategy) and the 6-week program turn your compass into a navigation system.')]
    return selftest('SELF-ASSESSMENT · PART II', 'How sound is your vision?', 'If you already have a vision — or a draft — test it with these twelve statements. If not yet: skip the test and come back here after the workshop. The comparison is worth it.', items, 'The soundness of your vision', eval_rows, s)

def selftest_werte(s):
    items = ['I can name my three most important values — instantly, without a list.', 'My values show up in my calendar — not just in my words.', 'In the past three months I made an uncomfortable decision because a value demanded it.', 'I know which of my values falls first under pressure.', 'I know the shadow side of my most important values.', 'My values are my own — not those of my parents, my environment or my industry.', 'I notice when two of my values come into conflict — and can name the conflict.', 'People who know me well would attribute to me the same values I give myself.', 'I have once turned down something attractive because it contradicted a value.', 'My values help me stay clear in conflicts instead of trying to please everyone.', 'I occasionally check whether my values still hold true — or are just habit by now.', 'I could tell a concrete situation from recent weeks for each of my values.']
    eval_rows = [('12–27', 'You carry values — but are they yours?', 'You probably live by values you never consciously chose: inherited, learned, expected. The Values Workshop separates lived values from named ones for you. Be especially honest with the question: When did this value last cost me something?'), ('28–44', 'Your values are known to you — but not yet sovereign.', "You know your values, but under pressure they slip. That's human — and changeable. Work on the conflict matrix and the question of which value has the last word. Emotional sovereignty begins right there."), ('45–60', 'Value clarity at a high level — examine the shadow sides.', 'You live your values. The danger at this level: values become dogmas. Loyalty becomes submission, excellence becomes perfectionism. For you the shadow-side exercise is not a duty exercise but the real program.')]
    return selftest('SELF-ASSESSMENT · PART III', 'How clear are your values?', 'Values you name and values you live are often different. These twelve statements measure the gap. Rate by your actual daily life of recent months — not by good intentions.', items, 'Your Value Clarity', eval_rows, s)

def selftest_strategie(s):
    items = ['I have at most three strategic goals — not ten.', 'My goals visibly contribute to my vision.', 'I can say what I deliberately do NOT do in order to reach my goals.', 'Each of my goals has a concrete next step with a deadline.', 'In everyday life I distinguish between important and urgent.', 'Every week I work on at least one important, non-urgent thing.', "I delegate or drop tasks that don't contribute to my goals.", 'I review my goals regularly — at least every 90 days.', "Setbacks don't throw me off course — I adjust the path, not the goal.", 'I plan my week before it plans me.', 'With new opportunities I can decide quickly: Does this fit my strategy?', "My strategy fits my energy — it doesn't overwhelm me long-term."]
    eval_rows = [('12–27', "You're busy — but are you effective?", "You probably work a lot and still don't get ahead. That's rarely about effort, almost always about a lack of selection. Strategy is sacrifice. The Strategy Workshop leads you from ten open fronts to three goals. It feels wrong at first — and then free."), ('28–44', 'The direction is right — the rhythm is missing.', "You have goals, but in everyday life they lose to the urgent. Your leverage: fixed appointments with what's important. Work with the Eisenhower sheet and the 90-day plan — and defend Quadrant II like an appointment with the notary."), ('45–60', 'Strategically strong — stay alert to your energy.', 'You work focused and aligned. At this level people rarely fall on strategy — they fall on exhaustion. Chapter 8 and the energy log are your insurance. Performance follows recovery, not the other way around.')]
    return selftest('SELF-ASSESSMENT · PART IV', 'How strategically do you live?', "Strategy doesn't mean getting more done. Strategy means choosing the right things — and deliberately leaving the rest. Twelve statements on your current state.", items, 'Your strategic maturity', eval_rows, s)

def werkstatt_vision(s):
    out = ws_head('WORKSHOP · PART II', 'The Vision Workshop', "Here your vision takes shape — in four steps. Don't give it an hour, give it a week. A vision that holds needs time to settle. You'll cross things out several times. That's exactly what this space is for.", s)
    out.append(step_label(1, 'Collect — without censoring', s))
    out.append(Paragraph('Answer the following questions quickly and unsorted. Keywords are enough. This is about raw material, not wording.', s['body']))
    out.append(PageBreak())
    out += writing_page('What would you do if you could not fail?', 'Not the safe thought — the first one. Write it down before your inner critic wakes up.', 12, s, 'STEP 1 · COLLECT')
    out += writing_page('When were you last fully yourself?', 'Describe two or three situations in which you felt energy, clarity and pride at once. What exactly were you doing — and how did you come across?', 12, s, 'STEP 1 · COLLECT')
    out += writing_page('What did you love as a child — before anyone said what it should become?', 'Activities, places, games, topics. Much of it carries a core that never disappeared — only got buried. Collect without judging.', 12, s, 'STEP 1 · COLLECT')
    out += writing_page("What should people say about you once you've left the room?", 'Not about your performance — about your impact. Three sentences you wish for. And one sentence you never want to hear again.', 12, s, 'STEP 1 · COLLECT')
    out.append(Spacer(1, 0.2 * cm))
    out.append(step_label(2, 'Condense — find the core', s))
    out.append(Paragraph('Read everything from Step 1. Underline the five words or phrases with the strongest charge — the ones that make something react in you. Enter them here:', s['body']))
    out += lines(5, '85%')
    out.append(hint("Werner's tip: The strongest words are rarely the prettiest. Often they're the uncomfortable ones.", s))
    out.append(Paragraph('Recognize the intention behind it: not what you say — what you mean. What common thread connects your five words?', s['body']))
    out += lines(4)
    out.append(PageBreak())
    out.append(step_label(3, 'Formulate — state, not process', s))
    out.append(Paragraph('Now you write your first vision draft. You know the rules from Chapter 3 — here as a checklist:', s['body']))
    for c_ in ['Present tense: “I am” — not “I want to be”', 'An achieved state — not a plan, not a path, not a process', 'A few pointed sentences — three to five, not ten', 'A way of being and an impact — not a job description', 'Timeless: still true in 20 years', 'Immediately understandable — without follow-up questions']:
        out.append(checkbox(c_, s))
    out.append(Spacer(1, 10))
    out.append(Paragraph('<b>Draft 1:</b>', s['body']))
    out += lines(6)
    out.append(PageBreak())
    out += writing_page("Draft 2 — after a day's distance", 'Read draft 1 out loud. Cross out every word that could appear in a hundred other visions. What remains is your core. Rewrite it.', 8, s, 'STEP 3 · FORMULATE')
    out += writing_page('Draft 3 — the version that stays', 'Final check: Would you say this text out loud, in front of people who know you? If yes — write it here in your best hand. This is your vision.', 8, s, 'STEP 3 · FORMULATE')
    out.append(step_label(4, 'Testing — the everyday test', s))
    out.append(Paragraph('A vision without a boundary is not a compass. Test your vision against three real decisions that are pending now or were recently:', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>Decision {i}:</b> What is it about?', ParagraphStyle('dec', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=12, spaceAfter=4)))
        out += lines(2)
        out.append(Paragraph('What does your vision say about it — yes or no? And why?', ParagraphStyle('dec2', fontName='Lora-It', fontSize=9.5, textColor=SL, spaceAfter=4)))
        out += lines(2)
    out.append(hint("If your vision can't clearly say no to any of the three decisions, it's still too soft. Back to Step 3 — one round braver.", s))
    out.append(PageBreak())
    return out
WERTE_LISTE = ['Freedom', 'Independence', 'Security', 'Stability', 'Closeness', 'Loyalty', 'Honesty', 'Integrity', 'Justice', 'Fairness', 'Responsibility', 'Reliability', 'Achievement', 'Excellence', 'Success', 'Growth', 'Learning', 'Curiosity', 'Creativity', 'Shaping', 'Innovation', 'Adventure', 'Courage', 'Risk-taking', 'Harmony', 'Peace', 'Serenity', 'Mindfulness', 'Health', 'Balance', 'Community', 'Belonging', 'Friendship', 'Love', 'Compassion', 'Generosity', 'Recognition', 'Status', 'Influence', 'Power', 'Leadership', 'Impact', 'Self-determination', 'Authenticity', 'Clarity', 'Discipline', 'Structure', 'Order', 'Pleasure', 'Joy of life', 'Humor', 'Lightness', 'Spirituality', 'Meaning', 'Tradition', 'Constancy', 'Sustainability', 'Nature', 'Beauty', 'Aesthetics']

def werkstatt_werte(s):
    out = ws_head('WORKSHOP · PART III', 'The Values Workshop', 'Sixty values are on the next page. By the end of this workshop, three to six remain — yours. Not the ones that sound good. The ones you actually decide by when it costs something.', s)
    out.append(step_label(1, 'Narrowing down — from 60 to 12', s))
    out.append(Paragraph("Spontaneously circle all the values that speak to you. Then cross out until at most twelve remain. Hard to cross out? Good. That's exactly the exercise.", s['body']))
    out.append(Spacer(1, 8))
    rows, row = ([], [])
    for i, w_ in enumerate(WERTE_LISTE, 1):
        row.append(Paragraph(w_, ParagraphStyle('wl', fontName='Lora', fontSize=9.5, textColor=CH, alignment=TA_CENTER)))
        if i % 3 == 0:
            rows.append(row)
            row = []
    t = Table(rows, colWidths=[TW / 3] * 3)
    t.setStyle(TableStyle([('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7), ('GRID', (0, 0), (-1, -1), 0.3, RU), ('BACKGROUND', (0, 0), (-1, -1), CW)]))
    out.append(t)
    out.append(PageBreak())
    out.append(step_label(2, 'Sharpening — from 12 to 6', s))
    out.append(Paragraph('Ask each of your twelve values the same question: <b>When did this value last cost me something?</b> Time, money, comfort, approval. A value that never costs anything is a preference — not a value. Cut to six.', s['body']))
    out.append(Paragraph('My six candidates — with the situation in which they last cost me something:', s['body']))
    for i in range(1, 7):
        out.append(Paragraph(f'<b>{i}.</b> Value: ____________________  ·  What it cost me:', ParagraphStyle('wk6', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=12, spaceAfter=4)))
        out += lines(2)
    out.append(PageBreak())
    out.append(step_label(3, 'Deciding — your 3 to 6 core values', s))
    out.append(Paragraph('Final cut. Which values remain? Enter them and describe for each: How does it show up concretely — and what is its shadow side? Every value has one: loyalty can become submission, excellence perfectionism, freedom fear of commitment.', s['body']))
    for i in range(1, 7):
        out.append(Paragraph(f'<b>CORE VALUE {i}:</b>', ParagraphStyle('kw', fontName='Lora', fontSize=10.5, textColor=CR, spaceBefore=14, spaceAfter=4)))
        out.append(Paragraph('How it shows up in my everyday life:', ParagraphStyle('kw2', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('Its shadow side for me:', ParagraphStyle('kw3', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceAfter=2)))
        out += lines(2)
        if i in (2, 4):
            out.append(PageBreak())
            out.append(Spacer(1, 0.2 * cm))
    out.append(PageBreak())
    out.append(step_label(4, 'The Conflict Matrix', s))
    out.append(Paragraph("Your values don't always pull in the same direction. Where do two of them come into real conflict — in concrete situations? Example: freedom wants to quit, security wants to stay. Name your two strongest tensions:", s['body']))
    for i in [1, 2]:
        out.append(Paragraph(f'<b>Tension {i}:</b> __________________  ⇄  __________________', ParagraphStyle('sp', fontName='Lora', fontSize=10.5, textColor=NV, spaceBefore=16, spaceAfter=6)))
        out.append(Paragraph('The everyday situation in which this conflict becomes visible:', ParagraphStyle('sp2', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceAfter=2)))
        out += lines(3)
        out.append(Paragraph('Which of the two has the last word in case of doubt — and why?', ParagraphStyle('sp3', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceAfter=2)))
        out += lines(3)
    out.append(hint("Conflicts between values aren't resolved — they're integrated. Whoever knows which value comes first when they collide stays composed under pressure. That's emotional sovereignty in practice.", s))
    out.append(PageBreak())
    return out

def werkstatt_strategie(s):
    out = ws_head('WORKSHOP · PART IV', 'The Strategy Workshop', "Your vision now becomes three strategic goals — and a clear no to everything else. Strategy is sacrifice: you'll cross out more here than you write.", s)
    out.append(step_label(1, 'The Inventory of Open Fronts', s))
    out.append(Paragraph('Write down all the goals, projects and plans currently living in your head. All of them. Even the half-forgotten ones. Experience shows 8 to 15 add up.', s['body']))
    out += lines(14)
    out.append(PageBreak())
    out.append(step_label(2, 'The Vision Filter', s))
    out.append(Paragraph('Read your vision. Then go through the list and ask at each point: <b>Does this contribute to my vision?</b> Three answers are allowed: YES (mark it), NO (cross it out), LATER (into the bracket below). Be tough. A half yes is a no.', s['body']))
    out.append(Spacer(1, 6))
    out.append(Paragraph('<b>The Later bracket</b> — good ideas, wrong time. Here they may wait without occupying you:', s['body']))
    out += lines(5)
    out.append(Spacer(1, 10))
    out.append(step_label(3, 'Three Strategic Goals', s))
    out.append(Paragraph("From the remaining YESes you choose three. Not four. Phrase each so that an outsider could check whether you've reached it — concrete, with a time horizon.", s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>STRATEGIC GOAL {i}:</b>', ParagraphStyle('sz', fontName='Lora', fontSize=10.5, textColor=CR, spaceBefore=12, spaceAfter=4)))
        out += lines(2)
        out.append(Paragraph('How it contributes to my vision:', ParagraphStyle('sz2', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceAfter=2)))
        out += lines(2)
    out.append(PageBreak())
    out.append(step_label(4, 'Der Verzichts-Vertrag', s))
    out.append(Paragraph('The most important step — and the most uncomfortable. What do you deliberately NOT do in the next 90 days so your three goals have room? At least three concrete sacrifices:', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'<b>I give up:</b>', ParagraphStyle('vz', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=12, spaceAfter=4)))
        out += lines(2)
    out.append(hint("Werner's experience: Whoever skips the sacrifice contract has ten open fronts again in 90 days. Often it's just a few small levers — but they have to be thrown.", s))
    out.append(Spacer(1, 8))
    out.append(Paragraph('Date: ____________  ·  Signature: ____________________', ParagraphStyle('vzd', fontName='Lora', fontSize=10, textColor=CH)))
    out.append(PageBreak())
    out += ws_head('DEEP DIVE · PART IV', 'Eisenhower in practice', "Important is what contributes to your goals. Urgent is what's loud. The matrix separates the two — and your calendar decides whether you mean it.", s)
    cell_st = ParagraphStyle('eh_c', fontName='Lora', fontSize=9, leading=13, textColor=CH)
    head_st = ParagraphStyle('eh_h', fontName='Lora', fontSize=9.5, textColor=white, alignment=TA_CENTER)
    q = lambda title, desc: [Paragraph(f'<b>{title}</b>', ParagraphStyle('eh_q', fontName='Lora', fontSize=10, textColor=NV, spaceAfter=3)), Paragraph(desc, cell_st)]
    data = [['', Paragraph('<b>URGENT</b>', head_st), Paragraph('<b>NOT URGENT</b>', head_st)], [Paragraph('<b>IMPORTANT</b>', ParagraphStyle('eh_l', fontName='Lora', fontSize=8, textColor=white, alignment=TA_CENTER)), q('I — Do it now yourself', 'Crises, deadlines, real emergencies. This is where you live if you never plan.'), q('II — Schedule & protect', 'Vision, strategy, relationships, health, learning. This is where your future is built. You defend Quadrant II like an appointment with the notary.')], [Paragraph('<b>NOT<br/>IMPORTANT</b>', ParagraphStyle('eh_l2', fontName='Lora', fontSize=8, textColor=white, alignment=TA_CENTER)), q('III — Delegate, automate, outsource', "Other people's urgency: many emails, meetings, interruptions. Feels like work, but it's noise."), q('IV — Eliminate', "Time-wasters with no value. Don't reduce — eliminate.")]]
    t = Table(data, colWidths=[68, (TW - 68) / 2, (TW - 68) / 2], rowHeights=[24, None, None])
    t.setStyle(TableStyle([('BACKGROUND', (1, 0), (-1, 0), NV), ('BACKGROUND', (0, 1), (0, -1), NV), ('BACKGROUND', (1, 1), (-1, -1), CW), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('VALIGN', (1, 1), (-1, -1), 'TOP'), ('GRID', (0, 0), (-1, -1), 0.7, white), ('TOPPADDING', (1, 1), (-1, -1), 9), ('BOTTOMPADDING', (1, 1), (-1, -1), 9), ('LEFTPADDING', (0, 0), (-1, -1), 8), ('RIGHTPADDING', (0, 0), (-1, -1), 8)]))
    out.append(t)
    out.append(Spacer(1, 14))
    out.append(Paragraph('<b>Exercise — Your week through the matrix:</b> Take your last work week and sort the ten biggest time blocks into the quadrants:', s['body']))
    out.append(Spacer(1, 4))
    qt = Table([[Paragraph('<b>Quadrant I</b>', cell_st), Paragraph('<b>Quadrant II</b>', cell_st)], ['\n\n\n\n\n', '\n\n\n\n\n'], [Paragraph('<b>Quadrant III</b>', cell_st), Paragraph('<b>Quadrant IV</b>', cell_st)], ['\n\n\n\n\n', '\n\n\n\n\n']], colWidths=[TW / 2, TW / 2])
    qt.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 0.4, RU), ('TOPPADDING', (0, 0), (-1, -1), 6), ('BOTTOMPADDING', (0, 0), (-1, -1), 6), ('LEFTPADDING', (0, 0), (-1, -1), 8)]))
    out.append(qt)
    out.append(hint('Honest assessment: What percentage of your week lives in Quadrant II? Under 20 percent means: your future gets the leftovers.', s))
    out.append(PageBreak())
    out += ws_head('TOOL · PART IV', 'Your 90-day plan', 'Three months is the best planning horizon: long enough for real results, short enough to stay concrete. One sheet per strategic goal.', s)
    for zi in range(1, 4):
        if zi > 1:
            out.append(PageBreak())
            out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(f'90-DAY SHEET · GOAL {zi}', ParagraphStyle('p90k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph('The goal in one sentence:', ParagraphStyle('p90a', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=6, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('How I will measure progress in 90 days:', ParagraphStyle('p90b', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=8, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('The three most important task blocks:', ParagraphStyle('p90c', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=8, spaceAfter=2)))
        for blk in ['Month 1:', 'Month 2:', 'Month 3:']:
            out.append(Paragraph(blk, ParagraphStyle('p90m', fontName='Lora-It', fontSize=9.3, textColor=SL, spaceBefore=8, spaceAfter=2)))
            out += lines(2)
        out.append(Paragraph('The biggest obstacle — and how I handle it:', ParagraphStyle('p90d', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=8, spaceAfter=2)))
        out += lines(2)
        out.append(Paragraph('The first step — with a date:', ParagraphStyle('p90e', fontName='Lora', fontSize=10, textColor=CR, spaceBefore=8, spaceAfter=2)))
        out += lines(2)
    out.append(PageBreak())
    return out

def werkstatt_energie(s):
    out = ws_head('TOOL · PART V', 'The Energy Log', 'For one week you observe what carries you and what costs you. No change — only observation. The change comes on its own once you see the patterns.', s)
    cell = ParagraphStyle('en_c', fontName='Lora', fontSize=8.5, textColor=CH)
    head = ParagraphStyle('en_h', fontName='Lora', fontSize=8.5, textColor=white, alignment=TA_CENTER)
    for half in [(1, 4), (5, 8)]:
        data = [[Paragraph('<b>Day</b>', head), Paragraph('<b>What gave me energy today</b>', head), Paragraph('<b>What cost me energy</b>', head), Paragraph('<b>Level<br/>1–10</b>', head)]]
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        rng = days[:4] if half[0] == 1 else days[4:]
        for d_ in rng:
            data.append([Paragraph(f'<b>{d_}</b>', cell), '\n\n\n\n', '\n\n\n\n', ''])
        t = Table(data, colWidths=[34, (TW - 84) / 2, (TW - 84) / 2, 50])
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), NV), ('GRID', (0, 0), (-1, -1), 0.4, RU), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 6), ('BOTTOMPADDING', (0, 0), (-1, -1), 6), ('LEFTPADDING', (0, 0), (-1, -1), 6)]))
        out.append(t)
        if half[0] == 1:
            out.append(PageBreak())
            out.append(Spacer(1, 0.3 * cm))
    out.append(Spacer(1, 12))
    out.append(Paragraph('<b>Assessment after seven days:</b> Which three sources keep coming up? Which two cost centers can you reduce, delegate or cut?', s['body']))
    out += lines(6)
    out.append(PageBreak())
    return out
PROFILE = [dict(name='Julia, 34 — lawyer on her way to her own firm', situation='Eight years at a large firm. Excellent professionally, empty inside. Julia realizes: she defends contracts, but no longer her own time. The thought of her own firm has been there for three years — and postponed for three years.', vision='I am a lawyer with my own practice — people come to me because I listen before I advise. I work on cases I have chosen myself, at a pace I set myself. My clients leave my office wiser than they came.', vision_note='Note: not a word about revenue or firm size. The vision describes impact and a way of living — the numbers belong in the strategy.', werte=[('Self-determination', 'she traded eight years for security — now she reverses the weighting'), ('Reliability', 'her anchor with clients — and its shadow side: she says no too rarely'), ('Clarity', 'her strength in advising, long her blind spot toward herself')], konflikt='Self-determination versus reliability: as a solo lawyer Julia can no longer take every case — and every refusal feels like letting someone down. Her solution: reliability belongs to the cases she takes on — not to every request. Whoever takes on everything is, in the end, reliable for no one.', ziele=['Founded her firm within 12 months with five paying regular clients', 'Built and made visible a specialization in employment law for founders', 'Saved a six-month financial buffer — before resigning'], verzicht='No second specialty in the first year. No pro bono cases until the base is solid. No perfecting the website beyond version 1.', schritt="A Friday, firmly blocked in the calendar: setting up the firm software and writing to the first three desired clients. Three weeks later Julia issues her first invoice — €1,840. Small, concrete, scheduled — that's how firms begin."), dict(name='Marc, 43 — founder between growth and exhaustion', situation='His software company is doing well: twelve employees, stable customers. But Marc works 70 hours, decides everything himself and realizes he has become the bottleneck of his own company. Growth is stalling — not because of the market, because of him.', vision="I am an entrepreneur, not a long-distance runner. My company grows because I let people grow. I work on the company, not in the company — and in the evening I'm a father with energy, not a founder running on a dead battery.", vision_note="Marc's first draft read “I want a company with 50 employees”. A number is a goal — not a way of living. The final version describes who he is as an entrepreneur.", werte=[('Creating', 'his drive since founding — for a long time he confused it with control'), ('Responsibility', 'truly lived for his team — the shadow side: he takes responsibility away from others instead of giving it'), ('Closeness', 'lived in the family — top of every value list, bottom of the calendar: the most honest insight of his Values Workshop')], konflikt="Creating versus closeness: every new project is stolen family time. Marc's integration: creating gets the working hours — but the working hours get a hard limit. From 6 pm the family has the last word, no discussion.", ziele=['Built a leadership level: two division heads who decide without him', 'Own working hours in 9 months from 70 to 45 — measured, not estimated', 'Established a strategy day per week: one day without operational business'], verzicht='No longer attending operational meetings below division-head level. No new product this year. No client appointments on Friday — that belongs to strategy.', schritt="Monday, 9 am: meeting with both senior developers — the conversation about the division leadership he's been postponing for four months."), dict(name='Sandra, 48 — executive facing the question of meaning', situation="Division head in a corporation, 120 employees, respected and well paid. And yet: since the last restructuring Sandra asks herself what she actually leads for. The next promotion doesn't tempt her — that frightens her more than any crisis.", situation_extra='', vision='I am a leader people straighten up around. In my division people dare to admit mistakes and try new things. What I leave behind are not org charts — they are people who can lead, because I let them grow.', vision_note="Sandra's turning point: the realization that her vision needs no new position. It describes a way of leading — valid at every level. Sometimes the vision is not a departure but a deepening.", werte=[('Impact', 'long confused with advancement — what she really means: leaving a mark in people'), ('Honesty', 'her reputation in the company — the shadow side: harshness when the dose is off'), ('Learning', 'her quiet engine — withered in routine meetings, alive in every mentoring')], konflikt="Honesty versus impact: the unfiltered truth doesn't always reach people. Sandra's integration: honesty about the what, care about the how. The truth stays — the packaging decides whether it lands.", ziele=['Built a mentoring program for eight junior staff — with measurable development steps', 'A culture around mistakes in the division: established monthly “Lessons Learned” sessions without blame', 'Sharpened her own role: cleared 30 percent of her time for developing people — in the calendar, not in her head'], verzicht='No application for the next hierarchy level this year — consciously decided instead of quietly avoided. No detail control of documents her team leaders are responsible for.', schritt='This week: scheduling the first mentoring conversation — with the junior in whom she recognizes herself 20 years ago.'), dict(name='Tim, 26 — career starter with too many options', situation="Master's in business, second year on the job, three evenings of training a week, four project ideas, a podcast plan. Tim doesn't have a motivation problem — he has a selection problem. Everything seems possible, nothing gets finished.", vision='I am someone who finishes things. I choose few paths and go deep rather than wide. People associate my name with reliability and substance — not with ten projects half begun.', vision_note="Tim's vision is deliberately a character vision, not a career vision. At 26 no one needs to know which profession it will be in 20 years. But who you want to be along the way — that carries through every stage.", werte=[('Curiosity', 'his gift and his risk — it opens doors and prevents arriving'), ('Substance', 'his antidote: better to master one thing than to start five'), ('Friendship', 'his corrective — the people who ground him when the next “big thing” beckons')], konflikt="Curiosity versus substance: every new idea feels more important than the current project. Tim's integration: curiosity gets a budget — four hours a week, no more. Substance gets the rest. New ideas go into the Later bracket.", ziele=['Brought one project — the podcast — to ten published episodes in 6 months', 'Claimed a topic at work: established as the first point of contact for data analysis in the team', 'Reduced training to one — completed instead of three begun'], verzicht="No new projects until the podcast reaches episode ten. At most one training course in parallel. Social media consumption to 30 minutes a day — other people's ideas are his biggest channel of distraction.", schritt='Sunday, 5 pm: record episode 1. Not perfect — published. Substance begins with finishing.')]

def berufsprofile(s):
    out = []
    intro = ws_head('ROLE MODELS FROM PRACTICE', 'Three paths through this book', 'Four people, four starting points — and four fully worked-through VWS profiles. No idealized pictures: you also see the wrong turns, the discarded drafts, the value conflicts. Find the path closest to yours — and compare with your own pages.', s)
    out += intro
    out.append(PageBreak())
    lbl = lambda txt: Paragraph(txt, ParagraphStyle('pf_l', fontName='Lora', fontSize=8.5, textColor=GD, spaceBefore=14, spaceAfter=4, tracking=2))
    body = ParagraphStyle('pf_b', fontName='Lora', fontSize=10, leading=16, textColor=CH, spaceAfter=6)
    vision_st = ParagraphStyle('pf_v', fontName='Lora-It', fontSize=10.5, leading=17, textColor=NV, spaceAfter=6, leftIndent=12, rightIndent=12)
    for p in PROFILE:
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph('PROFILE', ParagraphStyle('pf_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph(p['name'], ParagraphStyle('pf_n', fontName='Lora', fontSize=16, leading=21, textColor=NV, spaceAfter=4)))
        out.append(rule('14%', 2, CR, 10, 12, align='LEFT'))
        out.append(lbl('THE STARTING POINT'))
        out.append(Paragraph(p['situation'], body))
        out.append(lbl('THE VISION'))
        out.append(Paragraph('“' + p['vision'] + '”', vision_st))
        out.append(Paragraph(p['vision_note'], ParagraphStyle('pf_vn', fontName='Lora-It', fontSize=9, leading=14, textColor=SL, spaceAfter=6, leftIndent=12)))
        out.append(lbl('THE CORE VALUES'))
        for w_, note_ in p['werte']:
            out.append(Paragraph(f'<font color="#8E1429"><b>{w_}</b></font> — {note_}', ParagraphStyle('pf_w', fontName='Lora', fontSize=9.7, leading=15, textColor=CH, spaceAfter=5, leftIndent=6)))
        out.append(PageBreak())
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(p['name'].split(' — ')[0] + ' — continued', ParagraphStyle('pf_n2', fontName='Lora', fontSize=11, textColor=DG, spaceAfter=8)))
        out.append(lbl('THE VALUE CONFLICT — AND ITS INTEGRATION'))
        out.append(Paragraph(p['konflikt'], body))
        out.append(lbl('THE THREE STRATEGIC GOALS'))
        for i, z_ in enumerate(p['ziele'], 1):
            out.append(Paragraph(f'<font color="#8E1429"><b>{i}.</b></font> {z_}', ParagraphStyle('pf_z', fontName='Lora', fontSize=9.8, leading=15, textColor=CH, spaceAfter=5, leftIndent=6)))
        out.append(lbl('THE SACRIFICE CONTRACT'))
        out.append(Paragraph(p['verzicht'], body))
        out.append(lbl('THE FIRST STEP'))
        out.append(Paragraph(p['schritt'], ParagraphStyle('pf_s', fontName='Lora', fontSize=10, leading=16, textColor=NV, spaceAfter=10)))
        out.append(Paragraph('And you? What would be your counterpart to this first step?', ParagraphStyle('pf_q', fontName='Lora-It', fontSize=9.5, textColor=CR, spaceBefore=6, spaceAfter=4)))
        out += lines(3)
        out.append(PageBreak())
    return out
WEEKS = [dict(num=1, titel='Foundation', fokus='Taking stock — honest, not presentable', intro="This week is not about change. It's about truth: Where do you really stand? Which roles do you play — and who are you underneath? Read Chapters 1 and 2, take the self-assessment in Part I.", aufgaben=['Work through Chapters 1 and 2 — with all exercises', 'Fill in and score the self-assessment “Where do you really stand?”', 'The roles exercise: name three roles you play — and what they cost you'], frage='Which expectation of others shaped a decision of mine this week?'), dict(num=2, titel='Vision', fokus='Describe your state — as if it were already here', intro='The most important week of the program. You work through the entire Vision Workshop — all four steps. Plan three fixed appointments with yourself: collecting, condensing and formulating need distance from each other.', aufgaben=['Read Chapter 3 + Vision Workshop steps 1 and 2', "Two days' break — then step 3: write three drafts", 'Step 4: test the vision against three real decisions'], frage='Is my vision in the present tense — or is there still an “I want” hiding in it?'), dict(num=3, titel='Values', fokus='Finding the real ones — not the presentable ones', intro='Sixty values, in the end three to six remain. The measure is uncomfortable: a value that has never cost you anything is a preference. This week separates lived values from named ones.', aufgaben=['Read Chapter 4 + Values Workshop steps 1 to 3', 'Name the shadow side for each core value', 'Conflict matrix: work out your two strongest value tensions'], frage='Which of my values came under pressure this week — and did it hold?'), dict(num=4, titel='Strategy', fokus='Three goals — and a clear no to the rest', intro='Strategy is sacrifice. This week you take inventory of all your open fronts, filter them through your vision and decide on three strategic goals. The sacrifice contract at the end is the most important part.', aufgaben=['Read Chapter 5 + complete Strategy Workshop', 'Sign the sacrifice contract — with a date', 'Fill in the 90-day sheet for Goal 1'], frage='What did I deliberately NOT do this week — and what became possible because of it?'), dict(num=5, titel='Energy & Execution', fokus='Know the tank before you plan the distance', intro="Performance follows recovery — not the other way around. This week you keep the energy log and sort your week through the Eisenhower matrix. You'll see where your strength actually flows.", aufgaben=['Read Chapters 6 and 8', 'Energy log: fill in daily for seven days', 'Eisenhower exercise: sort your last week into the quadrants — and schedule a fixed Quadrant II appointment'], frage='What percentage of my week lived in Quadrant II?'), dict(num=6, titel='Impact & Staying With It', fokus='From Program to Habit', intro='The last program week builds the bridge into your everyday life: your legacy sentence, your rituals, your review rhythm. At the end stands the ritual on the final page of the book — your promise to yourself.', aufgaben=['Read Chapters 7 and 9', 'Choose three rituals from Part VIII and anchor them in the calendar', 'The ritual at the end of the book: write your sentence, date it, sign it'], frage='Which ritual survives even a stressful week — and which one needs protection?')]

def wochenprogramm(s):
    out = part_page('VII', 'The 6-Week Program', 'Structure for everyone who wants a rhythm', 'Six weeks, six focal points. Each week: one focus, three core tasks, daily check-ins, one weekly review. You need about three to four hours a week — spread across fixed appointments with yourself. Enter them now, before everyday life devours them.', s)
    cell = ParagraphStyle('wp_c', fontName='Lora', fontSize=8.5, textColor=CH)
    head = ParagraphStyle('wp_h', fontName='Lora', fontSize=8.5, textColor=white, alignment=TA_CENTER)
    for wk in WEEKS:
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(f'WEEK {wk['num']} OF 6', ParagraphStyle('wk_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph(wk['titel'], ParagraphStyle('wk_t', fontName='Lora', fontSize=19, leading=25, textColor=NV, spaceAfter=2)))
        out.append(Paragraph(wk['fokus'], ParagraphStyle('wk_f', fontName='Lora-It', fontSize=11, textColor=SL, spaceAfter=10)))
        out.append(rule('14%', 2, CR, 10, 12, align='LEFT'))
        out.append(Paragraph(wk['intro'], s['body']))
        out.append(Paragraph('<b>Your three core tasks:</b>', s['body']))
        for a_ in wk['aufgaben']:
            out.append(checkbox(a_, s, indent=6))
        out.append(Spacer(1, 8))
        out.append(Paragraph('<b>My fixed appointments with myself this week:</b>', s['body']))
        out.append(Paragraph('Appointment 1: ____________________  ·  Appointment 2: ____________________  ·  Appointment 3: ____________________', ParagraphStyle('wk_term', fontName='Lora', fontSize=9.5, textColor=CH, spaceAfter=4)))
        out.append(PageBreak())
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(f'WEEK {wk['num']} · DAILY CHECK-IN', ParagraphStyle('ci_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph('Two minutes every evening. No more — but no less.', ParagraphStyle('ci_i', fontName='Lora-It', fontSize=9.5, textColor=SL, spaceAfter=10)))
        data = [[Paragraph('<b>Day</b>', head), Paragraph('<b>Contributed to my goal today</b>', head), Paragraph('<b>Learned / noticed today</b>', head), Paragraph('<b>Energy<br/>1–10</b>', head)]]
        for d_ in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']:
            data.append([Paragraph(f'<b>{d_}</b>', cell), '\n\n\n', '\n\n\n', ''])
        t = Table(data, colWidths=[32, (TW - 78) / 2, (TW - 78) / 2, 46])
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), NV), ('GRID', (0, 0), (-1, -1), 0.4, RU), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5), ('LEFTPADDING', (0, 0), (-1, -1), 5)]))
        out.append(t)
        out.append(PageBreak())
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(f'WEEK {wk['num']} · WEEKLY REVIEW', ParagraphStyle('wr_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph('At the end of the week — 15 minutes, honestly.', ParagraphStyle('wr_i', fontName='Lora-It', fontSize=9.5, textColor=SL, spaceAfter=12)))
        for q_ in ['What went well this week — concretely?', 'What did I avoid — and why, probably?', wk['frage'], 'What do I take into next week — one thing, not five?']:
            out.append(Paragraph(q_, ParagraphStyle('wr_q', fontName='Lora', fontSize=10, leading=15, textColor=NV, spaceBefore=10, spaceAfter=2)))
            out += lines(3)
        out.append(PageBreak())
        out += wochen_schreibseite(wk['num'], wk['titel'], s)
    return out

def dranbleiben(s):
    out = part_page('VIII', 'Staying With It', 'Rituals, reviews and dealing with setbacks', "Most programs don't fail in week one — they fail in week seven, when everyday life returns. This part builds the structures that let your work survive: rituals, fixed reviews and an honest way of dealing with setbacks.", s)
    out += ws_head('DRANBLEIBEN · 1', 'Rituals that hold', 'Discipline is overrated — structure is underrated. A ritual is a decision you make only once and then never have to make again. Choose at most three of the following six. Three kept beat six broken.', s)
    rituale = [('The week start (Monday, 15 min.)', 'Three questions before the first email: What is truly important this week? Which Quadrant II block is in the calendar? What do I deliberately leave undone?'), ('The vision glance (daily, 1 min.)', "Your vision where you'll see it: edge of the mirror, phone case, desk drawer. Read it once a day. Don't analyze it — just read it."), ('The evening check (daily, 2 min.)', 'Two questions: Did I contribute to one of my three goals today? What gave me energy today? Keywords are enough.'), ('The Values Moment (at every hard decision)', 'Before you decide: Which of my core values is affected here — and what would it advise? 30 seconds that spare you years of detours.'), ('The monthly review (last Sunday, 30 min.)', 'With the sheet on the next pages: progress on the three goals, energy balance, one adjustment for the coming month.'), ('The quarterly compass (every 90 days, 2 hrs.)', 'The big picture: review the 90-day sheets, confirm or adjust goals, write a new 90-day plan. Best done away from home — different place, different view.')]
    for t_, x_ in rituale:
        out.append(checkbox(f'<b>{t_}</b> — {x_}', s))
    out.append(Spacer(1, 12))
    out.append(Paragraph('<b>My three rituals — with a fixed place in the calendar:</b>', s['body']))
    for i in range(1, 4):
        out.append(Paragraph(f'{i}. Ritual: ______________________________  ·  When: ____________________', ParagraphStyle('rit', fontName='Lora', fontSize=10, textColor=CH, spaceBefore=10)))
    out.append(PageBreak())
    out += ws_head('DRANBLEIBEN · 2', 'Setbacks and beliefs', "You'll have weeks when nothing works. That's no sign your plan is wrong — it's a sign you're alive. What matters is not the setback. What matters is the story you tell yourself afterward.", s)
    out.append(Paragraph("<b>Recognize the pattern:</b> After a setback an old belief usually speaks up — “I never stick with anything anyway”, “I knew it”, “it's easier for others”. These sentences feel like truth. They are habits.", s['body']))
    out.append(Paragraph("<b>The exercise:</b> Get the sentence out of your head onto paper — there it loses power. Then examine it like a lawyer: What speaks for it? What against it? And what would be a sentence that's more honest?", s['body']))
    for blk in [('My recurring sentence after setbacks:', 2), ('Three facts that speak against this sentence:', 3), ('The more honest sentence — not sugarcoated, but fair:', 2)]:
        out.append(Paragraph('<b>' + blk[0] + '</b>', ParagraphStyle('gs', fontName='Lora', fontSize=10, textColor=NV, spaceBefore=12, spaceAfter=2)))
        out += lines(blk[1])
    out.append(hint("Away from the problems, toward the solutions doesn't mean denying problems. It means not handing them the steering wheel.", s))
    out.append(PageBreak())
    for m in range(1, 7):
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph(f'MONATSREVIEW · MONAT {m}', ParagraphStyle('mr_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
        out.append(Paragraph('30 minutes on the last Sunday of the month.', ParagraphStyle('mr_i', fontName='Lora-It', fontSize=9.5, textColor=SL, spaceAfter=12)))
        for q_, n_ in [('Progress on Goal 1 / 2 / 3 — in one sentence each:', 4), ('My best moment this month — and what it says about me:', 3), ('Where I deviated from the plan — and whether the deviation was wise:', 3), ('Energy balance: What do I take with me, what do I leave behind?', 3), ('One adjustment for the next month — one, not five:', 2)]:
            out.append(Paragraph(q_, ParagraphStyle('mr_q', fontName='Lora', fontSize=10, leading=15, textColor=NV, spaceBefore=8, spaceAfter=2)))
            out += lines(n_)
        out.append(PageBreak())
    out.append(Spacer(1, 0.2 * cm))
    out.append(Paragraph('THE 90-DAY REVIEW', ParagraphStyle('r90_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
    out.append(Paragraph('The big look back — and forward', ParagraphStyle('r90_t', fontName='Lora', fontSize=17, textColor=NV, spaceAfter=4)))
    out.append(rule('14%', 2, CR, 10, 14, align='LEFT'))
    out.append(Paragraph("After 90 days you decide anew: Which goals do you confirm, which do you adjust, which have become obsolete? A strategy that never adjusts is not a strategy — it's stubbornness.", s['body']))
    for q_, n_ in [('Goal 1 — achieved / adjusted / dropped? Reason:', 3), ('Goal 2 — achieved / adjusted / dropped? Reason:', 3), ('Goal 3 — achieved / adjusted / dropped? Reason:', 3), ('What I learned about myself — the one most important insight:', 3), ('Has my vision proven itself? Where did it make decisions easier — where was it too soft?', 4), ('My three goals for the next 90 days:', 4)]:
        out.append(Paragraph(q_, ParagraphStyle('r90_q', fontName='Lora', fontSize=10, leading=15, textColor=NV, spaceBefore=10, spaceAfter=2)))
        out += lines(n_)
    out.append(PageBreak())
    out.append(Spacer(1, 0.2 * cm))
    out.append(Paragraph('THE YEARLY COMPASS', ParagraphStyle('jk_k', fontName='Lora', fontSize=9, textColor=GD, spaceAfter=4, tracking=2)))
    out.append(Paragraph('Once a year — the view of the whole', ParagraphStyle('jk_t', fontName='Lora', fontSize=17, textColor=NV, spaceAfter=4)))
    out.append(rule('14%', 2, CR, 10, 14, align='LEFT'))
    out.append(Paragraph('Take half a day, ideally between the years or on your birthday. Different place, no phone. Four questions — no more is needed.', s['body']))
    for q_, n_ in [('What am I truly proud of this year — including the quiet things?', 4), ('Does my vision still hold — literally, sentence by sentence? What has shifted?', 4), ('Did my values hold when things got hard? Where yes, where no?', 4), ('The leitmotif for my next year — one word or one sentence:', 3)]:
        out.append(Paragraph(q_, ParagraphStyle('jk_q', fontName='Lora', fontSize=10, leading=15, textColor=NV, spaceBefore=10, spaceAfter=2)))
        out += lines(n_)
    out.append(PageBreak())
    return out

def notizen_seiten(s, n=6):
    out = []
    for i in range(n):
        out.append(Spacer(1, 0.2 * cm))
        out.append(Paragraph('NOTES', ParagraphStyle('nt_k', fontName='Lora', fontSize=8.5, textColor=GD, spaceAfter=10, tracking=2)))
        out += lines(20, gap=27)
        out.append(PageBreak())
    return out
KAPITEL_FRAGEN = {1: [('Which role do you play most convincingly — and what does it cost you?', 'Describe the role concretely: Where do you wear it, since when, for whom? And then honestly: What do you get for it — and what do you pay?'), ('Who would you be without the expectations of the three most important people in your life?', 'Not a question of loyalty — a thought exercise. What would you decide, say, leave undone differently? What of that do you want to reclaim?')], 2: [('Which conviction has steered you for as long as you can think — and does it still hold true?', "Sentences like “I have to manage on my own” or “without hard work I'm worth nothing” form early and rule long. Bring your sentence to light — and examine it with today's eyes."), ('What would you do if no one were watching?', 'No audience, no evaluation, no résumé. What would remain — and what does that tell you about your iceberg below the waterline?')], 3: [('Your day in three years — from morning to night', 'Describe it in the present tense, as if it were today: Where do you wake up, what are you working on, who do you talk to, how does the day end? Concrete images — not concepts.')], 4: [('The situation in which you last acted against one of your own values', 'Tell it without glossing over: What was the moment, what did you do, what would you have wanted? And the most important question: What did the betrayal teach you — about the value and about yourself?')], 5: [('What would you end today if ending cost nothing?', 'A project, a habit, a commitment, perhaps a role. Write down what you would end — and then: What does ending really cost? Often less than continuing.')], 6: [('Your most energetic phase — what was different back then?', 'Go back to a time when you felt carried instead of exhausted. What was different: people, tasks, rhythm, sleep, movement? Which two of those ingredients can you reclaim?')], 7: [('The speech at your 80th birthday', 'The person who knows you best gives it. What should they say — about your impact, not your achievements? Write the three core sentences of that speech. And then: Are you already living toward it?')], 8: [('What does real recovery look like for you — and when did you last have it?', 'Not rest on the side — real recovery, after which you think differently. Describe it concretely. And plan the next one: When, where, how long, what must be canceled for it?')], 9: [('Your role model — and the one principle you adopt', 'Historical or living, famous or private: Who truly inspires you? Describe what sets this person apart — and which of their principles you translate into your own life from now on.')]}

def kapitel_schreibraum(num, s):
    out = []
    for title, prompt in KAPITEL_FRAGEN.get(num, []):
        out += writing_page(title, prompt, 13, s, f'DEEP DIVE · CHAPTER {num}')
    return out

def wochen_schreibseite(num, titel, s):
    return writing_page(f'Space for week {num} — {titel}', 'Thoughts, resistances, interim results of this week. Unsorted is allowed — the main thing is honest.', 14, s, f'WEEK {num} · FREE SPACE')