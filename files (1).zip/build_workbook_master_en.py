"""VWS Coaching Workbook — Premium Edition with branding & graphics"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white, black, Color
from reportlab.platypus import KeepTogether, NextPageTemplate, Paragraph, Spacer, PageBreak, HRFlowable, Table, TableStyle, Image, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Circle, Rect, Line, String, Path, Polygon
from reportlab.graphics import renderPDF
import os
import wb_ext_en as wb_ext
pdfmetrics.registerFont(TTFont('Lora', '/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'))
pdfmetrics.registerFont(TTFont('Lora-It', '/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('Chorus', '/home/claude/Chorus.ttf'))
_lib = '/usr/share/fonts/truetype/liberation/'
pdfmetrics.registerFont(TTFont('Helvetica', _lib + 'LiberationSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Helvetica-Bold', _lib + 'LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('Helvetica-Oblique', _lib + 'LiberationSans-Italic.ttf'))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('Helvetica', normal='Helvetica', bold='Helvetica-Bold', italic='Helvetica-Oblique')
pdfmetrics.registerFont(TTFont('Times-Roman', _lib + 'LiberationSerif-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Times-Bold', _lib + 'LiberationSerif-Bold.ttf'))
pdfmetrics.registerFont(TTFont('Times-Italic', _lib + 'LiberationSerif-Italic.ttf'))
registerFontFamily('Times-Roman', normal='Times-Roman', bold='Times-Bold', italic='Times-Italic')
from reportlab.lib.fonts import addMapping
addMapping('Chorus', 0, 0, 'Chorus')
addMapping('Chorus', 0, 1, 'Chorus')
addMapping('Chorus', 1, 0, 'Chorus')
CR = HexColor('#8E1429')
SL = HexColor('#5F7FA8')
WW = HexColor('#F0EEE8')
NV = HexColor('#1A2744')
GD = HexColor('#C0A84A')
CH = HexColor('#3A3A3A')
DG = HexColor('#888888')
RU = HexColor('#D8D3CB')
CB = HexColor('#EBF0F5')
CW = HexColor('#FAF7EE')
W, H = A4
BX, BY = (0, 0)
ML = 3.2 * cm
MR = 3.2 * cm
MT = 3.5 * cm
MB = 3 * cm
TW = W - ML - MR

def chapter_badge(num_str, theme_color=CR):
    """Circular chapter number badge"""
    d = Drawing(48, 48)
    d.add(Circle(24, 24, 22, fillColor=theme_color, strokeColor=None))
    d.add(String(24, 16, num_str, fontName='Lora', fontSize=18, fillColor=white, textAnchor='middle'))
    return d

def chapter_graphic(chapter_num):
    """PNG icon-based chapter header"""
    from reportlab.graphics.shapes import Drawing, Rect, String, Line
    from reportlab.platypus import Image as RLImage
    import os
    icon_files = {1: '/home/claude/icons_png/01_identity.png', 2: '/home/claude/icons_png/02_tree.png', 3: '/home/claude/icons_png/03_compass.png', 4: '/home/claude/icons_png/04_scale.png', 5: '/home/claude/icons_png/05_strategy.png', 6: '/home/claude/icons_png/06_bolt.png', 7: '/home/claude/icons_png/07_ripple.png', 8: '/home/claude/icons_png/08_stars.png'}
    captions = {1: 'THE ROLE VS. THE SELF', 2: 'THE VISIBLE VS. THE DRIVE', 3: 'YOUR DECISION FILTER', 4: 'LIVED VS. NAMED', 5: 'FOCUS THROUGH SACRIFICE', 6: 'GIVES VS. COSTS', 7: 'YOUR IMPACT', 8: 'PERFORMANCE THROUGH RECOVERY', 9: 'VISION · VALUES · STRATEGY IN ACTION'}
    d = Drawing(TW, 80)
    d.add(Rect(0, 0, TW, 80, fillColor=CW, strokeColor=RU, strokeWidth=0.5))
    d.add(Rect(0, 0, 4, 80, fillColor=CR, strokeColor=None))
    txt_x = 100
    cap = captions.get(chapter_num, '')
    d.add(Line(txt_x, 44, TW - 24, 44, strokeColor=RU, strokeWidth=0.4))
    d.add(Line(txt_x, 36, TW - 40, 36, strokeColor=RU, strokeWidth=0.3))
    d.add(String(txt_x + 6, 47, cap, fontName='Helvetica', fontSize=7, fillColor=DG, textAnchor='start', letterSpacing=1.0))
    return d

def chapter_symbol(chapter_num):
    """Large Unicode symbol for each chapter — rendered in Lora"""
    symbols = {1: ('◎', CR), 2: ('△', CR), 3: ('✦', CR), 4: ('⚖', CR), 5: ('◈', CR), 6: ('⚡', CR), 7: ('◉', CR), 8: ('⚡', CR), 9: ('✧', CR)}
    return symbols.get(chapter_num, ('◉', CR))

def quote_page(quote_text, author, s):
    """Half-page quote break between chapters — large crimson quote"""
    from reportlab.lib.styles import ParagraphStyle
    big_q = ParagraphStyle('bigq', fontName='Lora-It', fontSize=18, leading=28, textColor=CR, spaceAfter=16, spaceBefore=0, leftIndent=0, rightIndent=0, alignment=TA_LEFT)
    attr_s = ParagraphStyle('attr', fontName='Lora-It', fontSize=12.5, leading=17, textColor=SL, spaceAfter=0, letterSpacing=0.6)
    return [Spacer(1, 2.5 * cm), HRFlowable(width='15%', thickness=2, color=CR, spaceBefore=0, spaceAfter=28), Paragraph(f'“{quote_text}”', big_q), Spacer(1, 0.3 * cm), Paragraph(f'—  {author}', attr_s), Spacer(1, 2.5 * cm), HRFlowable(width='100%', thickness=0.3, color=RU, spaceBefore=0, spaceAfter=0), PageBreak()]

def divider_ornament():
    """Small crimson ornament divider"""
    d = Drawing(TW, 16)
    cx = TW / 2
    d.add(Line(0, 8, cx - 20, 8, strokeColor=RU, strokeWidth=0.4))
    d.add(Line(cx + 20, 8, TW, 8, strokeColor=RU, strokeWidth=0.4))
    d.add(Circle(cx, 8, 3, fillColor=CR, strokeColor=None))
    d.add(Circle(cx - 12, 8, 1.5, fillColor=SL, strokeColor=None))
    d.add(Circle(cx + 12, 8, 1.5, fillColor=SL, strokeColor=None))
    return d

def werner_portrait():
    """Werner's portrait circle — only if the file actually exists, else None (no circle)"""
    p = '/home/claude/werner_placeholder.png'
    if not os.path.exists(p):
        return None
    try:
        return Image(p, width=44, height=44)
    except Exception:
        return None

def logo_img(width=100):
    """Kentaur logo"""
    return Image('/home/claude/kentaur_logo.png', width=width, height=width * (335 / 987))

def mk():
    s = {}
    s['body'] = ParagraphStyle('body', fontName='Helvetica', fontSize=10.5, leading=18, textColor=CH, spaceAfter=10, alignment=TA_JUSTIFY)
    s['body_l'] = ParagraphStyle('body_l', fontName='Helvetica', fontSize=10.5, leading=17, textColor=CH, spaceAfter=7)
    s['cover_hero'] = ParagraphStyle('chero', fontName='Lora', fontSize=44, leading=52, textColor=NV, spaceAfter=8)
    s['cover_method'] = ParagraphStyle('cmethod', fontName='Lora-It', fontSize=24, leading=30, textColor=CR, spaceAfter=2)
    s['sect_hero'] = ParagraphStyle('shero', fontName='Lora', fontSize=30, leading=38, textColor=NV, spaceAfter=8)
    s['cover_sub'] = ParagraphStyle('csub', fontName='Lora-It', fontSize=15, leading=23, textColor=SL, spaceAfter=18)
    s['cover_body'] = ParagraphStyle('cbody', fontName='Helvetica', fontSize=10, leading=16, textColor=CH, spaceAfter=6)
    s['kap_num'] = ParagraphStyle('knum', fontName='Helvetica', fontSize=9, leading=14, textColor=CR, spaceAfter=3, letterSpacing=2)
    s['kap_title'] = ParagraphStyle('ktit', fontName='Lora', fontSize=30, leading=36, textColor=NV, spaceAfter=8)
    s['kap_sub'] = ParagraphStyle('ksub', fontName='Lora-It', fontSize=13, leading=20, textColor=SL, spaceAfter=0)
    s['h2'] = ParagraphStyle('h2', fontName='Lora', fontSize=14, leading=20, textColor=NV, spaceAfter=6, spaceBefore=16)
    s['label'] = ParagraphStyle('lbl', fontName='Helvetica-Bold', fontSize=8, leading=12, textColor=SL, spaceAfter=4, letterSpacing=1.5)
    s['label_cr'] = ParagraphStyle('lcr', fontName='Helvetica-Bold', fontSize=8, leading=12, textColor=CR, spaceAfter=4, letterSpacing=1.5)
    s['quote'] = ParagraphStyle('qt', fontName='Lora-It', fontSize=12.5, leading=21, textColor=NV, spaceAfter=4, spaceBefore=8, leftIndent=56)
    s['quote_attr'] = ParagraphStyle('qa', fontName='Helvetica', fontSize=8, leading=13, textColor=SL, spaceAfter=12, leftIndent=56)
    s['small'] = ParagraphStyle('sm', fontName='Helvetica', fontSize=8, leading=13, textColor=DG, spaceAfter=3)
    s['small_nv'] = ParagraphStyle('smnv', fontName='Helvetica', fontSize=8, leading=13, textColor=NV, spaceAfter=3)
    s['toc_num'] = ParagraphStyle('tn', fontName='Lora', fontSize=14, leading=20, textColor=CR)
    s['toc_title'] = ParagraphStyle('tt', fontName='Lora', fontSize=13, leading=20, textColor=NV)
    s['toc_sub'] = ParagraphStyle('ts', fontName='Helvetica', fontSize=9, leading=14, textColor=DG)
    s['commitment'] = ParagraphStyle('cmt', fontName='Helvetica', fontSize=10.5, leading=17, textColor=NV, spaceAfter=8, leftIndent=16)
    s['quiz_q'] = ParagraphStyle('qq', fontName='Lora', fontSize=12, leading=18, textColor=NV, spaceAfter=8)
    s['quiz_opt'] = ParagraphStyle('qo', fontName='Helvetica', fontSize=10.5, leading=17, textColor=CH, spaceAfter=5, leftIndent=12)
    s['chapter_it'] = ParagraphStyle('chit', fontName='Lora-It', fontSize=11, leading=19, textColor=CH, spaceAfter=10, spaceBefore=4)
    s['brief_salut'] = ParagraphStyle('bsal', fontName='Lora', fontSize=16, leading=24, textColor=NV, spaceAfter=16, spaceBefore=8)
    s['sign'] = ParagraphStyle('sign', fontName='Chorus', fontSize=32, leading=36, textColor=NV, spaceAfter=10)
    s['ritual_body'] = ParagraphStyle('rit', fontName='Lora-It', fontSize=13, leading=22, textColor=NV, spaceAfter=12)
    return s
ch_store = ['']
logo_path = '/home/claude/kentaur_logo_alpha.png'

def on_cover(c, doc):
    c.saveState()
    c.setFillColor(WW)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(SL)
    c.rect(0, 0, W, 1.6 * cm + BY, fill=1, stroke=0)
    c.setFillColor(CR)
    c.rect(0, H - 12 * mm - BY, W, 12 * mm + BY, fill=1, stroke=0)
    c.setFillColor(SL)
    c.rect(0, H - 14 * mm - BY, W, 2 * mm, fill=1, stroke=0)
    c.setStrokeColor(WW)
    c.setLineWidth(0.5)
    c.setStrokeAlpha(0.45)
    _fy = (1.5, 1.16, 0.74) if BY else (1.32, 0.92, 0.42)
    c.line(W / 2 - 1.4 * cm, _fy[0] * cm + BY, W / 2 + 1.4 * cm, _fy[0] * cm + BY)
    c.setStrokeAlpha(1)
    c.setFillColor(WW)
    c.setFillAlpha(0.85)
    t1 = c.beginText()
    t1.setFont('Helvetica', 6.8)
    t1.setCharSpace(0.6)
    s1 = 'wo@vonderbeyconsulting.com   ·   +49 152 57 66 05 01'
    w1 = c.stringWidth(s1, 'Helvetica', 6.8) + 0.6 * (len(s1) - 1)
    t1.setTextOrigin(W / 2 - w1 / 2, _fy[1] * cm + BY)
    t1.textOut(s1)
    c.drawText(t1)
    c.setFillAlpha(1)
    t2 = c.beginText()
    t2.setFont('Helvetica-Bold', 8)
    t2.setCharSpace(1.8)
    s2 = 'WWW.VONDERBEYCONSULTING.COM'
    w2 = c.stringWidth(s2, 'Helvetica-Bold', 8) + 1.8 * (len(s2) - 1)
    t2.setTextOrigin(W / 2 - w2 / 2, _fy[2] * cm + BY)
    t2.textOut(s2)
    c.drawText(t2)
    c.restoreState()

def on_normal(c, doc):
    c.saveState()
    c.setFillColor(WW)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(CR)
    c.rect(0, H - 3 * mm - BY, W, 3 * mm + BY, fill=1, stroke=0)
    c.setStrokeColor(RU)
    c.setLineWidth(0.4)
    c.line(ML, 2.2 * cm + BY, W - MR, 2.2 * cm + BY)
    c.setFont('Helvetica', 8)
    c.setFillColor(DG)
    c.drawCentredString(W / 2, 1.05 * cm + BY, str(doc.page))
    if ch_store[0]:
        c.setFillColor(SL)
        c.setFont('Helvetica', 7.5)
        c.drawString(ML, 1.05 * cm + BY, ch_store[0].upper())
    try:
        logo_w = 100
        logo_h = logo_w * (335 / 987)
        if BY:
            logo_y = H - BY - 10.7 * mm - logo_h   # Oberkante ~0.42" unter Trim
            logo_x = W - BX - 12.7 * mm - logo_w    # rechte Kante 0.5" vom Trim
        else:
            logo_y = H - MT + (MT - 3 * mm - logo_h) / 2
            logo_x = W - logo_w - 6 * mm
        c.drawImage(logo_path, logo_x, logo_y, width=logo_w, height=logo_h, mask='auto')
    except:
        pass
    c.restoreState()

def rule(w='100%', thick=0.4, col=RU, before=6, after=10, align='CENTER'):
    return HRFlowable(width=w, thickness=thick, color=col, spaceBefore=before, spaceAfter=after, hAlign=align)

def write_area(lines=3):
    out = []
    for _ in range(lines):
        out += [HRFlowable(width='100%', thickness=0.4, color=RU, spaceAfter=30, spaceBefore=4)]
    return out

def werner_box(text, s):
    portrait = werner_portrait()
    items = [rule('100%', 0.3, RU, 8, 10)]
    if portrait:
        data = [[portrait, [Paragraph(f'“{text}”', s['quote']), Paragraph('Dr. Werner von der Bey', s['quote_attr'])]]]
        t = Table(data, colWidths=[52, TW - 52])
        t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 0)]))
        items.append(t)
    else:
        items += [Paragraph(f'“{text}”', s['quote']), Paragraph('Dr. Werner von der Bey', s['quote_attr'])]
    items.append(rule('100%', 0.3, RU, 0, 14))
    return items

def story_box(label, text, s):
    return [KeepTogether([Paragraph(label, s['label_cr']), Paragraph(text, s['body'])]), Spacer(1, 8)]

def exercise_box(title, text, s, lines=3):
    return [Spacer(1, 6), Paragraph(title, s['label']), Paragraph(text, s['body_l']), Spacer(1, 8)] + write_area(lines) + [Spacer(1, 8)]

def quiz_box(question, options, s):
    return [Paragraph('REFLECTION', s['label']), Paragraph(question, s['quiz_q'])] + [Paragraph(f'○   {o}', s['quiz_opt']) for o in options] + [Spacer(1, 10)]

def commitment(text, s):
    return [rule('18%', 2, CR, 18, 10), Paragraph('MY COMMITMENT', s['label_cr']), Paragraph(text, s['commitment']), Spacer(1, 8)]

def chapter_intro_page(num, title, subtitle, s, chapter_num_int=1):
    """Full opening page with large symbol + title"""
    sym, col = chapter_symbol(chapter_num_int)
    sym_style = ParagraphStyle('sym', fontName='DejaVu', fontSize=72, leading=80, textColor=col, spaceAfter=0, alignment=TA_LEFT)
    kap_lbl = ParagraphStyle('klbl', fontName='Helvetica', fontSize=9, textColor=CR, leading=14, spaceAfter=8, letterSpacing=2)
    return [Spacer(1, 1.6 * cm), Paragraph(f'CHAPTER {num:02d}', kap_lbl), Spacer(1, 0.3 * cm), Paragraph(sym, sym_style), Spacer(1, 0.4 * cm), Paragraph(title, s['kap_title']), rule('22%', 2, CR, 4, 14), Paragraph(subtitle, s['kap_sub']), PageBreak()]

def thread(text, s):
    return [Spacer(1, 0.8 * cm), rule('100%', 0.4, RU, 0, 8), Paragraph(f'→  {text}', s['small']), PageBreak()]

def build(path, coachee_name='', target='digital'):
    global W, H, TW, BX, BY
    from reportlab.lib.units import inch
    cv_sp1, cv_sp2, cv_img = (0.6 * cm, 1.2 * cm, 160) if target != 'print' else (0.25 * cm, 0.6 * cm, 124)
    if target == 'print':
        BX, BY = (0.0625 * inch, 0.125 * inch)
        W, H = (7 * inch + 2 * BX, 10 * inch + 2 * BY)
        _ml, _mr = (1.9 * cm + BX, 1.6 * cm + BX)
        _mt, _mb = (2.4 * cm + BY, 2.6 * cm + BY)
    else:
        BX, BY = (0, 0)
        W, H = A4
        _ml, _mr, _mt, _mb = (ML, MR, MT, MB)
    TW = W - _ml - _mr
    s = mk()

    class Doc(BaseDocTemplate):
        pass
    doc = Doc(path, pagesize=(W, H), leftMargin=_ml, rightMargin=_mr, topMargin=_mt, bottomMargin=_mb, title='VWS Coaching Workbook — Dr. Werner von der Bey', author='Dr. Werner von der Bey, MBA')
    frame = Frame(_ml, _mb, TW, H - _mt - _mb, id='main')
    doc.addPageTemplates([PageTemplate(id='cover', frames=[frame], onPage=on_cover), PageTemplate(id='normal', frames=[frame], onPage=on_normal)])
    story = []
    story += [Spacer(1, 4.0 * cm), Paragraph('Vision Values Strategy', s['cover_method']), Paragraph('Workbook', s['cover_hero']), rule('20%', 2.5, CR, 4, 22), Paragraph('9 Chapters · 4 Workshops · 6-Week Coaching Program', s['cover_sub']), Paragraph('Not a questionnaire. Not a gimmick.<br/>A mirror. Sometimes uncomfortable. Always honest.', s['cover_body']), Paragraph(f'Created for: {coachee_name}' if coachee_name else '', s['cover_body']), Spacer(1, cv_sp2), Image('/home/claude/kentaur_only_alpha.png', width=cv_img, height=int(cv_img * (246 / 189)), hAlign='CENTER'), NextPageTemplate('normal'), PageBreak()]
    ch_store[0] = 'Letter from Werner'
    story += [Spacer(1, 3.4 * cm), Paragraph(f'Dear {coachee_name},' if coachee_name else 'Dear Coachee,', s['brief_salut']), Paragraph("In 20 years of coaching I have learned one thing: most people know what they want. They just don't know why they aren't getting it.", s['body']), Paragraph("The answer rarely lies in missing skills. It lies in unanswered questions. Who am I really? What do I stand for when things get hard? Where do I want to go, if I'm brave enough to say it out loud?", s['body']), Paragraph("This workbook guides you through these questions. I won't tell you what to answer. I'll tell you which questions truly matter — and then let you find your own answers.", s['body']), Spacer(1, 1.2 * cm), Paragraph('Werner', s['sign']), Paragraph('Dr. Werner von der Bey, MBA', s['small']), Paragraph('Coach · <i>Vision, Values, Strategy</i>', s['small']), PageBreak()]
    ch_store[0] = 'How you work'
    story += wb_ext.howto_pages(s)
    ch_store[0] = 'Inhalt'
    story += [Spacer(1, 0.6 * cm), Paragraph('CONTENTS', s['kap_num']), Paragraph('Your Mirror', s['sect_hero']), rule('20%', 2.5, CR, 4, 28)]
    chapters_list = [(1, 'The Identity Trap', "Who you really are — and who you're playing"), (2, 'The Iceberg Principle', 'What truly drives you beneath the surface'), (3, 'Visions that work', 'The difference between a wish and a compass'), (4, 'Values Under Pressure', 'What you truly prioritize — when things get hard'), (5, 'Strategy is sacrifice', 'Less, but the right things'), (6, 'Energy is your resource', 'What carries you — and what costs you'), (7, 'Leaving an Impact', "What you stand for when you're no longer there"), (8, 'Why Olympians Train Less', 'Performance through recovery, not through exhaustion'), (9, 'Visionaries, Strategists, Champions of Values', 'What historical figures teach us')]
    for num, title, sub in chapters_list:
        badge = chapter_badge(str(num).zfill(2))
        badge.width = 36
        badge.height = 36
        data = [[renderPDF.GraphicsFlowable(badge), [Paragraph(title, s['toc_title']), Paragraph(sub, s['toc_sub'])]]]
        t = Table(data, colWidths=[52, TW - 52])
        t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 0), ('LEFTPADDING', (1, 0), (1, -1), 12), ('BOTTOMPADDING', (0, 0), (-1, -1), 14), ('TOPPADDING', (0, 0), (-1, -1), 4), ('LINEBELOW', (0, 0), (-1, -1), 0.3, RU)]))
        story.append(t)
    story.append(PageBreak())
    chapter_data = [(1, 'The Identity Trap', "Who you really are — and who you're playing", 'Most people have never decided who they are. They have surrendered — to expectations, roles, habits. This is not an accusation. It is an invitation.', 'THE STORY', 'Paul, 41, management consultant. Successful, well paid, empty inside. His core value: freedom. Then we look together at his last three years. Every major decision has narrowed his freedom. Paul is silent for a long time. Then: “I never really lived freedom. I only dreamed of it.”', 'What this has to do with you', 'Identity is what remains when you set aside all your roles. Not manager, not parent — but you. Psychologists call this narrative identity: the story we tell ourselves about ourselves. The gap between who you are and who you play is your most important field of growth.', 'EXERCISE — 3 MINUTES', 'Write down who you are. No roles, no titles. What is true about me when no one is watching? When were you last truly yourself — specifically, with a date?', 5, 'Of your decisions over the last 12 months: how many truly reflect your values?', ['Almost all — I live what I say', 'Half — sometimes yes, sometimes no', 'Few — I often act against my convictions', "Honestly, I don't know"], "Tonight: tell someone close to you about a moment from the past week when you weren't yourself.", 'Before we talk about vision, we need to understand what drives us beneath the surface. Continue in Chapter 2.'), (2, 'The Iceberg Principle', 'What truly drives you beneath the surface', "What you see is the result. What you don't see is everything else. I'm interested in the everything else.", 'THE STORY', "Two surgeons, same training, same clinic. After 20 years: one is still on fire, the other has quietly checked out. The difference? Not the work. It's the story they tell themselves about it.", 'The Four Levels', "Write down what you do professionally. Then: Why do I do this? Why does it matter? Why does it really matter? Four levels deeper you'll find your true drive. Viktor Frankl called it meaning. And that is exactly what we're looking for here.", 'EXERCISE — FOUR LEVELS', 'Level 1: What do I do?\nLevel 2: Why do I do it?\nLevel 3: Why does it matter?\nLevel 4: Why does it really matter?', 8, 'What truly keeps you from reaching your full potential?', ['Missing skills or knowledge', 'Unfavorable circumstances', 'My own inner brake — doubt, fear, beliefs', "I'm already where I want to be"], "Choose one limiting belief. Write it down. Then: What if it isn't true?", 'You now know what drives you. Now we build a vision that matches that drive. Chapter 3.'), (3, 'Visions that work', 'The difference between a wish and a compass', "I've heard hundreds of visions. Most of them sound good. Few of them work. The difference lies in the precision of the picture.", 'THE COMPARISON', "Vision A: “I want to build a successful company that creates real value for people.”\n\nVision B: “I run an agency that breaks with convention and gives young brands a voice of their own — and in the evening I still have energy for my own life and the people who matter to me.”\n\nVision A sounds good — and says nothing. Future tense, interchangeable, no help with any decision. Vision B is in the present, holds a stance that is yours alone, and draws a clear line between work and life. Only one is a compass. Which one helps you say yes or no to a job offer?", 'The five tests', 'Present tense: “I am” — not “I want to be.” · Decision filter: it lets you clearly say yes or no. · Distinctiveness: only you could have written this sentence. · Embodiment: you feel something when you read it. · Legacy: still true in 20 years.', 'YOUR VISION — FIRST DRAFT', 'First person. Present tense. Distinctive and timeless. Raw, but real.', 5, 'What happens when you read your vision out loud?', ['I feel energy and direction', "It sounds good but I don't quite believe it yet", "It doesn't feel like me yet", "I don't have one yet — this exercise shows me why"], 'Read your vision out loud every morning for a week. Note daily: What changed because of it?', 'A vision without values is like a compass without a magnet. Chapter 4.'), (4, 'Values Under Pressure', 'What you truly prioritize — when things get hard', 'Values show up in what you sacrifice — not in what you write down on a list.', 'THE STORY', 'Elena, 38, executive. Her most important value: closeness — lived through her family. Then the offer of a lifetime — 80% travel, double the salary. “When did you last truly live this value — specifically, with consequence?” She is silent for three minutes.', 'The Shadow Sides', 'Every value has a shadow side. Loyalty can be submission. Excellence can be perfectionism. Freedom can be fear of commitment. This is not a weakness — it is information.', 'EXERCISE — SHADOW SIDES', 'For each of your top 3 values: write down its shadow side. When did you last play it out?', 8, 'An offer that goes against your most important value — but provides financial security. What do you do?', ['I accept it — security comes first', 'I decline — values are non-negotiable', 'I negotiate different terms', "I'm not sure"], '“In the past week I violated my value [X], because [...].” No self-reproach. Just clarity.', 'You know your values. How do you build a strategy from them? Chapter 5.'), (5, 'Strategy is sacrifice', 'Less, but the right things', "The biggest strategic problem: too many ideas. Strategy doesn't mean doing more — it means deciding more clearly.", 'THE STORY', "Steve Jobs returns to Apple in 1997 and immediately cuts 70% of its products. Not because they're bad — but because focus matters more than completeness. In the years that follow, Apple becomes the most valuable company in the world.", 'The List of Noes', "The most powerful strategic exercise is not a list of goals. It's a list of noes. What will you deliberately not do in the next 6 months?", 'YOUR LIST OF NOES', "10 things you will NOT do in the next 6 months. “Less Netflix” doesn't count — “Netflix after 11 pm” counts.", 10, 'Of your current projects: how many truly bring you closer to your vision?', ["Almost all — I'm very focused", 'Half', "Few — I'm too scattered", "I don't yet have a vision as a filter"], 'Today, say no to a request you would previously have agreed to out of a sense of duty.', 'Strategy without energy is just a plan. Chapter 6.'), (6, 'Energy is your resource', 'What carries you — and what costs you', 'Time is fixed. Energy is renewable. But only if you know where you lose it — and where you gain it.', 'THE DISCOVERY', "Olympic athletes don't train harder than you think. The secret is the quality of recovery, not the intensity of training. Those who succeed sustainably know when they need to withdraw — and do it without guilt.", 'Your Energy System', "There are three kinds of energy thieves: people who drain you, tasks that make no sense, environments that don't suit you. You can't eliminate them all — but you can stop overlooking all three every day.", 'EXERCISE — ENERGY BALANCE', '5 things that give me energy.\n5 things that take my energy.\nWhat if I cut one thing from the second list this week?', 10, 'When are you in your element — when time disappears and energy rises?', ['When working with people', 'When thinking and planning strategically', 'When creating and shaping something', "When I'm alone and can think deeply"], 'This week, protect one hour that gives you energy like an important meeting.', 'You have energy, focus and values. Continue in Chapter 7 — and then Chapter 8.'), (7, 'Leaving an Impact', "What you stand for when you're no longer there", "This is the question I most love to ask. Not because it's hard. But because it's honest.", 'THE LEGACY TEST', 'Three people, all successful. Who will still be remembered in 20 years? Not the one with the best LinkedIn profile. The one who touched people — and left behind something greater than themselves.', 'The Gap', 'What would five people who truly know you say about you if you were gone tomorrow? Write it down. Then write down what you wish they would say. The gap between the two texts is your development task.', 'THE TWO TEXTS', 'Text 1: What would people say about me today?\n\n\n\nText 2: What do I want to hear in 10 years?', 8, "What is your greatest gift to the world that you haven't yet unfolded?", ['My ability to connect and lead people', 'Passing on my knowledge and experience', 'Creating something that outlives me', 'Staying true to myself and modeling that for others'], 'Today, write a message to someone whose life you have shaped. Be specific. Today.', '')]
    _chapter_quotes = {1: ('The greatest discovery of my generation is that human beings can alter their lives by altering their attitudes of mind.', 'William James'), 2: ('Man is not free from conditions. But he is free to take a stand toward them.', 'Viktor E. Frankl'), 3: ('The ones who are crazy enough to think they can change the world are the ones who do.', 'Steve Jobs, “Think Different” campaign'), 4: ('I learned that courage was not the absence of fear, but the triumph over it.', 'Nelson Mandela, “Long Walk to Freedom”'), 5: ('Non refert quam multos libros habeas. It is not how much you have that matters — but how deeply you understand it.', 'Seneca'), 6: ('Soon you will have forgotten everything — and soon everyone will have forgotten you.', 'Marcus Aurelius, Meditations'), 7: ('People forget what you said. They forget what you did. But they never forget how you made them feel.', 'Maya Angelou')}
    for num, title, sub, quote, story_lbl, story_txt, h2_txt, theory, ex_lbl, ex_txt, ex_lines, quiz_q, quiz_opts, commit_txt, thread_txt in chapter_data:
        ch_store[0] = f'Chapter {num} — {title}'
        story += chapter_intro_page(num, title, sub, s, num)
        story += werner_box(quote, s)
        story += story_box(story_lbl, story_txt, s)
        story.append(Paragraph(h2_txt, s['h2']))
        story.append(Paragraph(theory, s['body']))
        story += exercise_box(ex_lbl, ex_txt, s, ex_lines)
        story.append(renderPDF.GraphicsFlowable(divider_ornament()))
        story += quiz_box(quiz_q, quiz_opts, s)
        story += commitment(commit_txt, s)
        if thread_txt:
            story += thread(thread_txt, s)
        _q = _chapter_quotes.get(num)
        if _q:
            story += quote_page(_q[0], _q[1], s)
        story += wb_ext.kapitel_schreibraum(num, s)
        if num == 2:
            ch_store[0] = 'Self-Assessment — Foundation'
            story += wb_ext.selftest_fundament(s)
        elif num == 3:
            ch_store[0] = 'Vision Workshop'
            story += wb_ext.werkstatt_vision(s)
            ch_store[0] = 'Self-Assessment — Vision'
            story += wb_ext.selftest_vision(s)
        elif num == 4:
            ch_store[0] = 'Values Workshop'
            story += wb_ext.werkstatt_werte(s)
            ch_store[0] = 'Self-Assessment — Values'
            story += wb_ext.selftest_werte(s)
        elif num == 5:
            ch_store[0] = 'Strategy Workshop'
            story += wb_ext.werkstatt_strategie(s)
            ch_store[0] = 'Self-Assessment — Strategy'
            story += wb_ext.selftest_strategie(s)
    ch_store[0] = 'Chapter 8 — Why Olympians Train Less'
    story += chapter_intro_page(8, 'Why Olympians Train Less', 'Performance through recovery, not through exhaustion', s, 8)
    story += werner_box('Most people think peak performance comes from more effort. The opposite is true. The best perform more because they rest more wisely.', s)
    story += story_box('THE DISCOVERY', "Michael Phelps, 23-time Olympic champion, sleeps 10 to 12 hours a night. Roger Federer 11 to 12. LeBron James invests 1.5 million dollars a year in sleep, recovery and body care — not in training. Norwegian cross-country skiers, who revolutionized endurance training, do 80% of their training at low intensity. Only 20% is high performance. It's called the 80/20 rule — and it doesn't only apply in sport.", s)
    story.append(KeepTogether([Paragraph('What this means', s['h2']), Spacer(1, 4)]))
    story.append(Paragraph("Sleep researcher Matthew Walker has shown: someone awake for 17 hours reacts as impaired as someone at 0.5 per mille blood alcohol — that's the research, not a gut feeling. Decision quality, creativity, emotional intelligence — all of it collapses. No coffee makes up for it. No act of will. The body is not an enemy of performance. It is its foundation.", s['body']))
    story.append(KeepTogether([Paragraph('Five strategies of the best', s['h2']), Spacer(1, 4)]))
    strategies = [('The 80/20 Rule', 'Eighty percent of your work at a pace that feels sustainable. Twenty percent at full intensity. Not the other way around. Most leaders live permanently in 100-percent mode — and wonder why their creativity fades.'), ('Periodization', 'Olympians plan peak phases and low phases in weekly and monthly rhythms. Not every week is a competition week. Deliberately plan recovery weeks too — weeks with fewer appointments, less output, more thinking.'), ('Sleep as non-negotiable', 'Seven to nine hours. Not as a luxury — as a prerequisite. Those who sleep less make worse decisions, learn more slowly and react more emotionally. These are not recommendations. They are measurements.'), ('Active Recovery', 'Complete rest is often worse than light movement. A 20-minute walk after intense work speeds up recovery more than sitting. Your body recovers better when it keeps moving.'), ('Protect flow', "Identify your two to three hours each day when you are sharpest. Protect that time above all else. No meetings. No emails. Only your most important work. That's performance optimization without a single extra hour of work.")]
    for title_s, desc_s in strategies:
        story.append(KeepTogether([Paragraph(title_s, s['label_cr']), Paragraph(desc_s, s['body']), Spacer(1, 4)]))
    story.append(KeepTogether([Paragraph('Your personal performance rhythm', s['h2']), Spacer(1, 4)]))
    story.append(Paragraph("Every person has a biologically determined rhythm. Lark or owl, morning type or evening type — that's not a question of character but of genetics. The question is not when you should, but when you are at your best.", s['body']))
    story += exercise_box('EXERCISE — YOUR ENERGY CALENDAR', 'Map out a typical work week. Mark: When are you at your peak? (high phase) When are you running on reserve? (low phase) When do you deliberately recover? Compare this with your actual calendar. What stands out?', s, lines=6)
    story += exercise_box('EXERCISE — THE RECOVERY LOG', "This week: keep a log of your energy. Morning (before work), midday and evening — one number from 1 to 10 each. After seven days you'll see your rhythm. No tool needed — a sheet of paper is enough.", s, lines=7)
    story += quiz_box('How many hours do you sleep on average per night?', ['Under 6 hours — I manage with it', '6 to 7 hours — could be more', '7 to 8 hours — I pay attention to it', '8 hours or more — sleep matters to me'], s)
    story += commitment('This week: protect a 90-minute recovery phase each day just like an important meeting. No screen. Movement, sleep or deliberate stillness. Put it in your calendar now.', s)
    story += thread('Energy, focus, values — and now role models. What can we learn from the greatest visionaries in history? Chapter 9.', s)
    story += wb_ext.kapitel_schreibraum(8, s)
    story += quote_page('You cannot consistently deliver what you cannot consistently recharge.', 'Jim Loehr & Tony Schwartz, “The Power of Full Engagement”', s)
    ch_store[0] = 'Chapter 9 — Visionaries, Strategists, Champions of Values'
    story += chapter_intro_page(9, 'Visionaries, Strategists, Champions of Values', 'What historical figures teach us', s, 9)
    story += werner_box('The best teachers are not the loudest. They are the ones who risked something and did it anyway.', s)
    story.append(KeepTogether([Paragraph('Vision', s['h2']), Spacer(1, 2)]))
    story += story_box('NELSON MANDELA — THE VISION THAT OUTLASTED 27 YEARS', 'Mandela spends 27 years in prison. His vision: a free, democratic South Africa without apartheid. So precise and so deeply anchored that it needs no external conditions. When he is released in 1990 he does not say: what have I lost. He says: now the real work begins. What I learned from this: a vision that only holds under good conditions is not a compass. It is a wish.', s)
    story += story_box('LEONARDO DA VINCI — THE VISION OF THE WHOLE PERSON', "Da Vinci doesn't only paint. He designs machines, studies anatomy, composes music, writes on hydrodynamics. His vision: to understand humanity and nature completely. Not as a specialist, but as an observer of the whole. What I learned from this: the strongest visions don't describe a profession. They describe a way of being.", s)
    story.append(KeepTogether([Paragraph('Values', s['h2']), Spacer(1, 2)]))
    story += story_box('MARCUS AURELIUS — VALUES UNDER PRESSURE', 'Emperor Marcus Aurelius rules the most powerful empire in the world and could have anything. Yet every evening he writes in his journal an account of his own values: justice, temperance, courage, wisdom. Not for the public. For himself. What I learned from this: values that no one sees are the only real ones. Test them silently against your actions every evening.', s)
    story += story_box('ROSA PARKS — ONE VALUE, ONE MOMENT, ONE MOVEMENT', "Montgomery 1955. Rosa Parks refuses to give up her seat on the bus. No long plan. No calculation. Just a value that in that moment is stronger than the consequence. What I learned from this: values don't show up in speeches. They show up in the one moment when it truly matters.", s)
    story.append(KeepTogether([Paragraph('Strategy', s['h2']), Spacer(1, 2)]))
    story += story_box('SENECA — STRATEGY THROUGH FOCUS', "Seneca writes: Non refert quam multos libros habeas. It does not matter how many books you have. His core idea is radically simple: Less. Deeper. More consistently. What I learned from this: strategy is not the summing up of possibilities. It is the cutting of everything that doesn't count.", s)
    story += story_box('FLORENCE NIGHTINGALE — DATA AS STRATEGY', 'Nightingale saves thousands of lives in the Crimean War not with courage alone but with strategy. She invents the statistical graphic as a tool of communication and convinces the British military with data instead of emotion. What I learned from this: the most effective strategy combines conviction with method. Values say why. Strategy says how.', s)
    story.append(KeepTogether([Paragraph('What they have in common', s['h2']), Spacer(1, 4)]))
    story.append(Paragraph('None of these people had perfect conditions. None of them waited for permission. All of them had a clear picture of who they were, and let it guide them when things got hard. This is not a question of history. It is a question of decision.', s['body']))
    story += exercise_box('YOUR INSPIRATION', 'Who speaks to you most? What exactly moves you about them? And: what of that is also in you, still unfolded?', s, lines=5)
    story += commitment('Name a historical figure you want to get to know more deeply over the next 30 days. Their biography. Their decisions. What would they do in your current situation?', s)
    story += wb_ext.kapitel_schreibraum(9, s)
    story.append(PageBreak())
    ch_store[0] = 'Energy Log'
    story += wb_ext.werkstatt_energie(s)
    ch_store[0] = 'Role models from practice'
    story += wb_ext.berufsprofile(s)
    ch_store[0] = 'The 6-Week Program'
    story += wb_ext.wochenprogramm(s)
    ch_store[0] = 'Staying With It'
    story += wb_ext.dranbleiben(s)
    ch_store[0] = 'Werners Empfehlungen'
    story += [Spacer(1, 0.6 * cm), Paragraph("WERNER'S RECOMMENDATIONS", s['kap_num']), Paragraph('What I have used myself', s['sect_hero']), rule('20%', 2.5, CR, 4, 24)]
    story.append(KeepTogether([Paragraph('Books', s['h2']), Spacer(1, 4)]))
    books = [('The Courage to Be Disliked', 'Ichiro Kishimi & Fumitake Koga', "Adler's psychology as a dialogue between a philosopher and a young man. Freed from the judgment of others — more radical than the title sounds."), ('Man’s Search for Meaning', 'Viktor E. Frankl', 'Frankl finds meaning in a concentration camp. If that is possible, anything is possible. The foundation of everything in Chapter 2.'), ('Thinking, Fast and Slow', 'Daniel Kahneman', 'How we really decide — and why we so often get it wrong. Very useful for anyone who wants to think strategically.'), ('Thus Spoke Zarathustra', 'Friedrich Nietzsche', 'Not light reading, not a how-to guide. But anyone seeking their own path will find here the toughest sparring partner in literature.'), ('Principles', 'Ray Dalio', 'Dalio makes decisions repeatable: principles instead of gut feeling. The chapter on radical transparency alone is worth the book.'), ('Hagakure', 'Yamamoto Tsunetomo', 'The samurai code, three hundred years old. On bearing when no one is watching — and clarity in the face of consequence.')]
    for title_b, author_b, desc_b in books:
        story.append(Paragraph(f'<b>{title_b}</b> — {author_b}', ParagraphStyle('bk', fontName='Helvetica', fontSize=10.5, leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_b, ParagraphStyle('bkd', fontName='Helvetica', fontSize=9.5, leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))
    story.append(KeepTogether([Paragraph('Audiobooks', s['h2']), Spacer(1, 4)]))
    audiobooks = [('Ikigai', 'Héctor García & Francesc Miralles', 'Why the people of Okinawa live to a hundred — and what your reason is to get up in the morning. Easy to listen to, stays with you long after.'), ('What Life Should Mean to You', 'Alfred Adler', "The 1933 original behind today's literature on meaning. Adler is in my coaching more often than you'd think."), ('Start with No', 'Jim Camp', 'Negotiating without win-win platitudes: the no as the strongest starting point. A toolbox for every hard conversation.')]
    for title_a, author_a, desc_a in audiobooks:
        story.append(Paragraph(f'<b>{title_a}</b> — {author_a}', ParagraphStyle('ab', fontName='Helvetica', fontSize=10.5, leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_a, ParagraphStyle('abd', fontName='Helvetica', fontSize=9.5, leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))
    story.append(KeepTogether([Paragraph('Documentaries & Series', s['h2']), Spacer(1, 4)]))
    series = [('The Last Dance', 'Netflix', 'Michael Jordan and the road to the top. Leadership, values under pressure, strategy in real time. More coaching than sport.'), ('The Crown', 'Netflix', 'Half a century between the person and the office: what it costs to stay true to a role. And, in passing, the best study of power within institutions.'), ('Built In Birmingham: Brady & The Blues', 'Prime Video', 'Tom Brady takes over a traditional English club. Vision against reality, week by week — strategy to watch unfold.'), ('Be Water — The Bruce Lee Story', 'Disney+', 'Bruce Lee in his own words and rare archive footage. Adaptability as strategy: Be formless. Be water.')]
    for title_s, platform_s, desc_s in series:
        story.append(Paragraph(f'<b>{title_s}</b> — {platform_s}', ParagraphStyle('sr', fontName='Helvetica', fontSize=10.5, leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_s, ParagraphStyle('srd', fontName='Helvetica', fontSize=9.5, leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))
    story.append(KeepTogether([Paragraph('Exercises', s['h2']), Spacer(1, 4)]))
    exercises = [('The Evening Journal', "Five minutes before sleep. Three questions: What was good today? What would I have done differently? What do I take into tomorrow? No more. No less. After 30 days you'll see patterns you didn't see before."), ('The Sunday Question', 'Every Sunday a single question: Was I this week the person I want to be? Yes or no. No excuse. No comment. This one question has changed more for my clients than any technique I know.'), ('Box breathing — a breathing exercise for clear decisions', 'Breathe in for 4 seconds. Hold for 4. Breathe out for 4. Hold for 4. Four rounds. Two minutes. I do this before important conversations and before any decision I want to make with a clear head. It makes your thoughts crystal clear.'), ('The five-minute power — a body exercise with no excuses', "5 push-ups. 10 squats. 15 seconds of plank. Repeat three times — that's eight minutes. Not for the muscles. But because you show your mind that you do what you set out to do. Discipline in the small carries over to the big."), ('The 20-Minute Walk — endurance as a thinking tool', 'Twenty minutes on foot every day. No phone. No headphones. Just you and your pace. Most of my best ideas came while walking. Movement clears mental blocks faster than coffee and brainstorming combined.'), ('The pre-mortem — practicing strategic thinking', "Before every important decision: imagine it's a year later and the decision has gone thoroughly wrong. What happened? Write it down. Then ask: What could I have seen beforehand? This exercise has spared me more bad decisions than all the strategy frameworks I know.")]
    for title_e, desc_e in exercises:
        story.append(Paragraph(f'<b>{title_e}</b>', ParagraphStyle('ex', fontName='Helvetica', fontSize=10.5, leading=16, textColor=NV, spaceAfter=2)))
        story.append(Paragraph(desc_e, ParagraphStyle('exd', fontName='Helvetica', fontSize=9.5, leading=15, textColor=CH, spaceAfter=10, leftIndent=12)))
    story += werner_box("Six exercises, four routines in this book — no one does them all, and you don't have to. If you take only one thing: the Sunday question. One Sunday, one question, one honest yes or no. Everything else is expansion.", s)
    story.append(PageBreak())
    ch_store[0] = 'Strategic Masterstrokes'
    story += [Spacer(1, 0.6 * cm), Paragraph('STRATEGIC MASTERSTROKES', s['kap_num']), Paragraph('What history teaches about strategy', s['sect_hero']), rule('20%', 2.5, CR, 4, 24), Paragraph('The great strategists of history had one thing in common: they chose the essential and consistently let go of everything else. Here are five lessons that still hold today.', s['body'])]
    achievements = [('ALEXANDER THE GREAT — SPEED AS STRATEGY', 'Alexander defeats the Persian Empire not through superior numbers. His army is smaller. At Gaugamela in 331 BC he deliberately leaves a gap in his line to draw the enemy in. What I learned from this: the fast decision often beats the best one. Perfection is the enemy of action.', 'Vision: I will cross the boundaries of the known world.'), ('NAPOLEON BONAPARTE — CONCENTRATION OF FORCES', "Napoleon's genius rests on one principle: never divide your forces when you can concentrate them. At Austerlitz in 1805 his right wing deliberately appears weak in order to break through the center. What I learned from this: focus beats breadth. Always.", 'Strategy: Divide the enemy — concentrate yourself.'), ('WINSTON CHURCHILL — VISION IN THE DARKEST HOUR', "1940. France falls. Churchill's cabinet debates peace negotiations. Churchill refuses. Not because he is sure of winning — but because his vision of a free Europe allows no option to negotiate. What I learned from this: a true vision is not a luxury for good times.", 'Vision: We will never surrender.'), ('HANNIBAL BARCA — THE DETOUR AS THE DIRECT PATH', 'Hannibal crosses the Alps with elephants — the route Rome thinks impossible. At Cannae in 216 BC he defeats a Roman army nearly twice the size. His strategy: not to attack head-on, but to envelop. What I learned from this: those who know only the direct path become predictable.', 'Strategy: Do the unexpected — consistently.'), ('MAHATMA GANDHI — VALUES AS A WEAPON', 'Gandhi defeats the British Empire not with force but with Satyagraha — the force of truth. He strips the empire of its moral legitimacy. What I learned from this: values are not a weakness. They are the strongest strategic resource you have.', 'Values: Be the change you want to see in the world.')]
    for title_h, text_h, lens_h in achievements:
        story.append(Paragraph(title_h, s['label_cr']))
        story.append(Paragraph(text_h, s['body']))
        story.append(Paragraph(lens_h, ParagraphStyle('lens', fontName='Lora-It', fontSize=10, leading=16, textColor=SL, spaceAfter=16, leftIndent=16)))
    story.append(PageBreak())
    ch_store[0] = 'Abschlussportrait — Tupac Shakur'
    story += [PageBreak(), Spacer(1, 0.6 * cm), Paragraph('CLOSING PORTRAIT', s['kap_num']), Paragraph('Tupac Shakur', s['sect_hero']), rule('20%', 2.5, CR, 4, 14), Paragraph('A man with vision, values and strategy', s['kap_sub']), Spacer(1, 0.5 * cm), Paragraph("Tupac Amaru Shakur, born 1971 in New York, shot dead 1996 in Las Vegas. 25 years old. Poet, rapper, actor — and to this day one of the most listened-to voices in the world, with over 75 million albums sold. He stands at the end of this chapter because he shows something that can't be learned in any boardroom: vision, values and strategy are not a privilege of the educated and established. They are a concept for any life — even one that begins in poverty and runs against all odds.", s['body']), Spacer(1, 0.3 * cm), Paragraph('VISION — THE VOICE OF THE VOICELESS', s['label_cr']), Paragraph("His mother Afeni Shakur was a civil rights activist; he carried his name after a leader of the uprising against colonial rule in Peru. Tupac's vision was larger than his career from the start: he wanted to give a voice to those who had none — the overlooked of America's big cities. Not someday, but in every song, every interview, every role. His vision was a state, not a plan:", s['body']), Paragraph('“I will spark the brain that will change the world.”', s['quote']), Paragraph("I'm going to spark the brain that will change the world. — MTV interview, 1994", s['quote_attr']), Spacer(1, 0.2 * cm), Paragraph('VALUES — TRUTHFULNESS, LOYALTY, DIGNITY', s['label_cr']), Paragraph('Tupac said what he thought — even when it cost him record deals, goodwill and, in the end, perhaps his life. His loyalty belonged to his origins and to his mother, to whom he publicly expressed his gratitude at the height of his success. His measure was authenticity: better to clash than to bend. His favorite line, loosely after Shakespeare, was his value compass in a single sentence:', s['body']), Paragraph('“A coward dies a thousand deaths. A soldier dies but once.”', s['quote']), Paragraph('A coward dies a thousand deaths. A soldier dies but once. — loosely after Shakespeare, Julius Caesar', s['quote_attr']), PageBreak(), Spacer(1, 0.6 * cm), Paragraph('STRATEGY — A BODY OF WORK THAT OUTLASTS THE PERSON', s['label_cr']), Paragraph('The most underestimated thing about Tupac was his strategy. He read Machiavelli and Sun Tzu in prison — and afterward called himself Makaveli. In just a few years he recorded hundreds of songs, far more than he could release: a deliberately built reserve. He built a second career as an actor in parallel — a second pillar in case the music ended. He thought ahead instead of reacting: he knew the fragility of his life and built a body of work that would outlast him. More albums appeared after his death than during his lifetime — no accident, but anticipation. That is strategy in its purest form: milestones that serve the vision, not the moment.', s['body']), Spacer(1, 0.4 * cm)]
    story += werner_box("You don't have to like Tupac's music to learn from him. A vision that grows out of one's own pain. Values that aren't negotiated even under pressure. A strategy that thinks beyond one's own life. Vision, values, strategy — this is not a concept for boardrooms. It is a concept for a life. For yours too.", s)
    story += commitment('What trace do you want to leave — and what of it will you begin this very week?', s)
    story.append(PageBreak())
    ch_store[0] = 'The Ritual'
    story += [rule('100%', 0.4, RU, 24, 20), Paragraph('THE RITUAL', s['kap_num']), Spacer(1, 0.3 * cm), Paragraph('Your promise to yourself', s['sect_hero']), rule('20%', 2.5, CR, 6, 20), Paragraph("You've worked through nine chapters. You've answered questions you rarely ask yourself. Now one last step.", s['body']), Paragraph('Write a single sentence that describes who you will be in three years. Not what you will have — who you will be.', s['ritual_body']), Spacer(1, 1.8 * cm)]
    for lbl in ['My sentence:', 'Date:', 'Signature:']:
        story.append(Paragraph(lbl, s['small_nv']))
        story.append(HRFlowable(width='58%', thickness=0.4, color=RU, spaceBefore=4, spaceAfter=28))
    story += [Spacer(1, 1.2 * cm), Paragraph('Fold this page. Put it away. Open it in three years.', s['small']), PageBreak()]
    ch_store[0] = 'Notizen'
    story += wb_ext.notizen_seiten(s, 8)
    ch_store[0] = 'Imprint'
    imp_h = ParagraphStyle('imph', parent=s['h2'], fontSize=13)
    imp_t = ParagraphStyle('impt', fontName='Helvetica', fontSize=9, leading=15, textColor=CH, spaceAfter=10)
    imp_l = ParagraphStyle('impl', fontName='Helvetica', fontSize=7.5, leading=12, textColor=HexColor('#888888'), spaceAfter=8)
    story += [PageBreak(), Spacer(1, 0.8 * cm), Paragraph('Imprint', imp_h), rule('12%', 1.5, CR, 6, 18), Paragraph('<b>© 2026 Dr. Werner von der Bey, MBA</b><br/>All rights reserved. 1st edition 2026.', imp_t), Paragraph('von der Bey Consulting<br/>Dr. Werner von der Bey<br/>von-Rauhenbergstr. 2<br/>86424 Dinkelscherben, Germany', imp_t), Paragraph('wo@vonderbeyconsulting.com<br/>+49 152 57 66 05 01<br/>www.vonderbeyconsulting.com', imp_t), Spacer(1, 0.4 * cm), Paragraph('<b>Notes</b>', imp_t), Paragraph('The case studies in this book are fictional. Any resemblance to real persons would be coincidental and unintended.', imp_l), Paragraph('This book offers coaching impulses and prompts for self-reflection. It does not replace medical, psychotherapeutic or legal advice. You carry out the exercises described on your own responsibility.', imp_l), Paragraph('Quotes have been checked to the best of our knowledge and attributed to their authors. Brands and titles named are the property of their respective owners; they are mentioned editorially.', imp_l), Paragraph('Design and typesetting: von der Bey Consulting.', imp_l)]
    ch_store[0] = ''
    bp_name = ParagraphStyle('bpn', parent=s['h2'], alignment=1)
    bp_role = ParagraphStyle('bpr', parent=s['kap_sub'], alignment=1)
    bp_body = ParagraphStyle('bpb', parent=s['body'], alignment=1)
    bp_mail = ParagraphStyle('bpm', parent=s['small'], alignment=1, textColor=NV, fontSize=10, leading=16)
    bp_web = ParagraphStyle('bpw', parent=s['small'], alignment=1, textColor=CR, fontSize=10.5, leading=16)
    story += [Spacer(1, 2.2 * cm), Paragraph('Dr. Werner von der Bey, MBA', bp_name), Paragraph('Coach · <i>Vision, Values, Strategy</i>', bp_role), Spacer(1, 0.7 * cm), rule('12%', 1.5, CR, 0, 18), Paragraph('The answers belong to you. Not to me.', bp_body), Spacer(1, 1.4 * cm), rule('30%', 0.6, '#D8D4CC', 0, 14), Paragraph('wo@vonderbeyconsulting.com', bp_mail), Paragraph('+49 152 57 66 05 01', bp_mail), Spacer(1, 0.25 * cm), Paragraph('www.vonderbeyconsulting.com', bp_web)]
    # Aufeinanderfolgende PageBreaks (ggf. nur durch Spacer getrennt) zu einem zusammenfassen → keine Leerseiten
    _cleaned = []
    _pending_break = False
    for _fl in story:
        _is_pb = isinstance(_fl, PageBreak)
        _is_spacer = _fl.__class__.__name__ == 'Spacer'
        if _is_pb:
            if _pending_break:
                continue  # zweiten Break verwerfen
            _pending_break = True
            _cleaned.append(_fl)
        else:
            if not _is_spacer:
                _pending_break = False
            _cleaned.append(_fl)
    story = _cleaned
    doc.build(story, canvasmaker=rl_canvas.Canvas)
    size = os.path.getsize(path)
    print(f'✅ Premium Workbook: {path}')
    print(f'   {size:,} bytes ({size // 1024} KB)')
if __name__ == '__main__':
    import sys
    name = sys.argv[1] if len(sys.argv) > 1 else ''
    build('/mnt/user-data/outputs/VWS_Workbook_Master.pdf', coachee_name=name)